import{r as ie,F as $a,R as Oa}from"./monaco-editor-XNG1n5iZ.js";(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const l of document.querySelectorAll('link[rel="modulepreload"]'))r(l);new MutationObserver(l=>{for(const o of l)if(o.type==="childList")for(const i of o.addedNodes)i.tagName==="LINK"&&i.rel==="modulepreload"&&r(i)}).observe(document,{childList:!0,subtree:!0});function n(l){const o={};return l.integrity&&(o.integrity=l.integrity),l.referrerPolicy&&(o.referrerPolicy=l.referrerPolicy),l.crossOrigin==="use-credentials"?o.credentials="include":l.crossOrigin==="anonymous"?o.credentials="omit":o.credentials="same-origin",o}function r(l){if(l.ep)return;l.ep=!0;const o=n(l);fetch(l.href,o)}})();var zu={exports:{}},Zr={};/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var La=ie,Ma=Symbol.for("react.element"),Ua=Symbol.for("react.fragment"),Wa=Object.prototype.hasOwnProperty,Fa=La.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,Ba={key:!0,ref:!0,__self:!0,__source:!0};function Iu(e,t,n){var r,l={},o=null,i=null;n!==void 0&&(o=""+n),t.key!==void 0&&(o=""+t.key),t.ref!==void 0&&(i=t.ref);for(r in t)Wa.call(t,r)&&!Ba.hasOwnProperty(r)&&(l[r]=t[r]);if(e&&e.defaultProps)for(r in t=e.defaultProps,t)l[r]===void 0&&(l[r]=t[r]);return{$$typeof:Ma,type:e,key:o,ref:i,props:l,_owner:Fa.current}}Zr.Fragment=Ua;Zr.jsx=Iu;Zr.jsxs=Iu;zu.exports=Zr;var y=zu.exports,Ul={},ju={exports:{}},we={},Du={exports:{}},$u={};/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */(function(e){function t(C,T){var z=C.length;C.push(T);e:for(;0<z;){var G=z-1>>>1,X=C[G];if(0<l(X,T))C[G]=T,C[z]=X,z=G;else break e}}function n(C){return C.length===0?null:C[0]}function r(C){if(C.length===0)return null;var T=C[0],z=C.pop();if(z!==T){C[0]=z;e:for(var G=0,X=C.length,Jn=X>>>1;G<Jn;){var vt=2*(G+1)-1,pl=C[vt],gt=vt+1,qn=C[gt];if(0>l(pl,z))gt<X&&0>l(qn,pl)?(C[G]=qn,C[gt]=z,G=gt):(C[G]=pl,C[vt]=z,G=vt);else if(gt<X&&0>l(qn,z))C[G]=qn,C[gt]=z,G=gt;else break e}}return T}function l(C,T){var z=C.sortIndex-T.sortIndex;return z!==0?z:C.id-T.id}if(typeof performance=="object"&&typeof performance.now=="function"){var o=performance;e.unstable_now=function(){return o.now()}}else{var i=Date,u=i.now();e.unstable_now=function(){return i.now()-u}}var s=[],f=[],h=1,m=null,p=3,w=!1,E=!1,S=!1,D=typeof setTimeout=="function"?setTimeout:null,c=typeof clearTimeout=="function"?clearTimeout:null,a=typeof setImmediate<"u"?setImmediate:null;typeof navigator<"u"&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function d(C){for(var T=n(f);T!==null;){if(T.callback===null)r(f);else if(T.startTime<=C)r(f),T.sortIndex=T.expirationTime,t(s,T);else break;T=n(f)}}function v(C){if(S=!1,d(C),!E)if(n(s)!==null)E=!0,dl(_);else{var T=n(f);T!==null&&fl(v,T.startTime-C)}}function _(C,T){E=!1,S&&(S=!1,c(R),R=-1),w=!0;var z=p;try{for(d(T),m=n(s);m!==null&&(!(m.expirationTime>T)||C&&!k());){var G=m.callback;if(typeof G=="function"){m.callback=null,p=m.priorityLevel;var X=G(m.expirationTime<=T);T=e.unstable_now(),typeof X=="function"?m.callback=X:m===n(s)&&r(s),d(T)}else r(s);m=n(s)}if(m!==null)var Jn=!0;else{var vt=n(f);vt!==null&&fl(v,vt.startTime-T),Jn=!1}return Jn}finally{m=null,p=z,w=!1}}var N=!1,A=null,R=-1,U=5,P=-1;function k(){return!(e.unstable_now()-P<U)}function V(){if(A!==null){var C=e.unstable_now();P=C;var T=!0;try{T=A(!0,C)}finally{T?Ae():(N=!1,A=null)}}else N=!1}var Ae;if(typeof a=="function")Ae=function(){a(V)};else if(typeof MessageChannel<"u"){var Xn=new MessageChannel,Da=Xn.port2;Xn.port1.onmessage=V,Ae=function(){Da.postMessage(null)}}else Ae=function(){D(V,0)};function dl(C){A=C,N||(N=!0,Ae())}function fl(C,T){R=D(function(){C(e.unstable_now())},T)}e.unstable_IdlePriority=5,e.unstable_ImmediatePriority=1,e.unstable_LowPriority=4,e.unstable_NormalPriority=3,e.unstable_Profiling=null,e.unstable_UserBlockingPriority=2,e.unstable_cancelCallback=function(C){C.callback=null},e.unstable_continueExecution=function(){E||w||(E=!0,dl(_))},e.unstable_forceFrameRate=function(C){0>C||125<C?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):U=0<C?Math.floor(1e3/C):5},e.unstable_getCurrentPriorityLevel=function(){return p},e.unstable_getFirstCallbackNode=function(){return n(s)},e.unstable_next=function(C){switch(p){case 1:case 2:case 3:var T=3;break;default:T=p}var z=p;p=T;try{return C()}finally{p=z}},e.unstable_pauseExecution=function(){},e.unstable_requestPaint=function(){},e.unstable_runWithPriority=function(C,T){switch(C){case 1:case 2:case 3:case 4:case 5:break;default:C=3}var z=p;p=C;try{return T()}finally{p=z}},e.unstable_scheduleCallback=function(C,T,z){var G=e.unstable_now();switch(typeof z=="object"&&z!==null?(z=z.delay,z=typeof z=="number"&&0<z?G+z:G):z=G,C){case 1:var X=-1;break;case 2:X=250;break;case 5:X=1073741823;break;case 4:X=1e4;break;default:X=5e3}return X=z+X,C={id:h++,callback:T,priorityLevel:C,startTime:z,expirationTime:X,sortIndex:-1},z>G?(C.sortIndex=z,t(f,C),n(s)===null&&C===n(f)&&(S?(c(R),R=-1):S=!0,fl(v,z-G))):(C.sortIndex=X,t(s,C),E||w||(E=!0,dl(_))),C},e.unstable_shouldYield=k,e.unstable_wrapCallback=function(C){var T=p;return function(){var z=p;p=T;try{return C.apply(this,arguments)}finally{p=z}}}})($u);Du.exports=$u;var Ha=Du.exports;/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Ga=ie,ye=Ha;function g(e){for(var t="https://reactjs.org/docs/error-decoder.html?invariant="+e,n=1;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n]);return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var Ou=new Set,Tn={};function Pt(e,t){qt(e,t),qt(e+"Capture",t)}function qt(e,t){for(Tn[e]=t,e=0;e<t.length;e++)Ou.add(t[e])}var Ye=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Wl=Object.prototype.hasOwnProperty,Ya=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,xi={},Ci={};function Ka(e){return Wl.call(Ci,e)?!0:Wl.call(xi,e)?!1:Ya.test(e)?Ci[e]=!0:(xi[e]=!0,!1)}function Va(e,t,n,r){if(n!==null&&n.type===0)return!1;switch(typeof t){case"function":case"symbol":return!0;case"boolean":return r?!1:n!==null?!n.acceptsBooleans:(e=e.toLowerCase().slice(0,5),e!=="data-"&&e!=="aria-");default:return!1}}function Qa(e,t,n,r){if(t===null||typeof t>"u"||Va(e,t,n,r))return!0;if(r)return!1;if(n!==null)switch(n.type){case 3:return!t;case 4:return t===!1;case 5:return isNaN(t);case 6:return isNaN(t)||1>t}return!1}function ae(e,t,n,r,l,o,i){this.acceptsBooleans=t===2||t===3||t===4,this.attributeName=r,this.attributeNamespace=l,this.mustUseProperty=n,this.propertyName=e,this.type=t,this.sanitizeURL=o,this.removeEmptyString=i}var te={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e){te[e]=new ae(e,0,!1,e,null,!1,!1)});[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(e){var t=e[0];te[t]=new ae(t,1,!1,e[1],null,!1,!1)});["contentEditable","draggable","spellCheck","value"].forEach(function(e){te[e]=new ae(e,2,!1,e.toLowerCase(),null,!1,!1)});["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(e){te[e]=new ae(e,2,!1,e,null,!1,!1)});"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e){te[e]=new ae(e,3,!1,e.toLowerCase(),null,!1,!1)});["checked","multiple","muted","selected"].forEach(function(e){te[e]=new ae(e,3,!0,e,null,!1,!1)});["capture","download"].forEach(function(e){te[e]=new ae(e,4,!1,e,null,!1,!1)});["cols","rows","size","span"].forEach(function(e){te[e]=new ae(e,6,!1,e,null,!1,!1)});["rowSpan","start"].forEach(function(e){te[e]=new ae(e,5,!1,e.toLowerCase(),null,!1,!1)});var jo=/[\-:]([a-z])/g;function Do(e){return e[1].toUpperCase()}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e){var t=e.replace(jo,Do);te[t]=new ae(t,1,!1,e,null,!1,!1)});"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e){var t=e.replace(jo,Do);te[t]=new ae(t,1,!1,e,"http://www.w3.org/1999/xlink",!1,!1)});["xml:base","xml:lang","xml:space"].forEach(function(e){var t=e.replace(jo,Do);te[t]=new ae(t,1,!1,e,"http://www.w3.org/XML/1998/namespace",!1,!1)});["tabIndex","crossOrigin"].forEach(function(e){te[e]=new ae(e,1,!1,e.toLowerCase(),null,!1,!1)});te.xlinkHref=new ae("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1);["src","href","action","formAction"].forEach(function(e){te[e]=new ae(e,1,!1,e.toLowerCase(),null,!0,!0)});function $o(e,t,n,r){var l=te.hasOwnProperty(t)?te[t]:null;(l!==null?l.type!==0:r||!(2<t.length)||t[0]!=="o"&&t[0]!=="O"||t[1]!=="n"&&t[1]!=="N")&&(Qa(t,n,l,r)&&(n=null),r||l===null?Ka(t)&&(n===null?e.removeAttribute(t):e.setAttribute(t,""+n)):l.mustUseProperty?e[l.propertyName]=n===null?l.type===3?!1:"":n:(t=l.attributeName,r=l.attributeNamespace,n===null?e.removeAttribute(t):(l=l.type,n=l===3||l===4&&n===!0?"":""+n,r?e.setAttributeNS(r,t,n):e.setAttribute(t,n))))}var Ze=Ga.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,bn=Symbol.for("react.element"),jt=Symbol.for("react.portal"),Dt=Symbol.for("react.fragment"),Oo=Symbol.for("react.strict_mode"),Fl=Symbol.for("react.profiler"),Lu=Symbol.for("react.provider"),Mu=Symbol.for("react.context"),Lo=Symbol.for("react.forward_ref"),Bl=Symbol.for("react.suspense"),Hl=Symbol.for("react.suspense_list"),Mo=Symbol.for("react.memo"),Je=Symbol.for("react.lazy"),Uu=Symbol.for("react.offscreen"),Ni=Symbol.iterator;function sn(e){return e===null||typeof e!="object"?null:(e=Ni&&e[Ni]||e["@@iterator"],typeof e=="function"?e:null)}var B=Object.assign,ml;function vn(e){if(ml===void 0)try{throw Error()}catch(n){var t=n.stack.trim().match(/\n( *(at )?)/);ml=t&&t[1]||""}return`
`+ml+e}var hl=!1;function vl(e,t){if(!e||hl)return"";hl=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(t)if(t=function(){throw Error()},Object.defineProperty(t.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(t,[])}catch(f){var r=f}Reflect.construct(e,[],t)}else{try{t.call()}catch(f){r=f}e.call(t.prototype)}else{try{throw Error()}catch(f){r=f}e()}}catch(f){if(f&&r&&typeof f.stack=="string"){for(var l=f.stack.split(`
`),o=r.stack.split(`
`),i=l.length-1,u=o.length-1;1<=i&&0<=u&&l[i]!==o[u];)u--;for(;1<=i&&0<=u;i--,u--)if(l[i]!==o[u]){if(i!==1||u!==1)do if(i--,u--,0>u||l[i]!==o[u]){var s=`
`+l[i].replace(" at new "," at ");return e.displayName&&s.includes("<anonymous>")&&(s=s.replace("<anonymous>",e.displayName)),s}while(1<=i&&0<=u);break}}}finally{hl=!1,Error.prepareStackTrace=n}return(e=e?e.displayName||e.name:"")?vn(e):""}function Za(e){switch(e.tag){case 5:return vn(e.type);case 16:return vn("Lazy");case 13:return vn("Suspense");case 19:return vn("SuspenseList");case 0:case 2:case 15:return e=vl(e.type,!1),e;case 11:return e=vl(e.type.render,!1),e;case 1:return e=vl(e.type,!0),e;default:return""}}function Gl(e){if(e==null)return null;if(typeof e=="function")return e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case Dt:return"Fragment";case jt:return"Portal";case Fl:return"Profiler";case Oo:return"StrictMode";case Bl:return"Suspense";case Hl:return"SuspenseList"}if(typeof e=="object")switch(e.$$typeof){case Mu:return(e.displayName||"Context")+".Consumer";case Lu:return(e._context.displayName||"Context")+".Provider";case Lo:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case Mo:return t=e.displayName||null,t!==null?t:Gl(e.type)||"Memo";case Je:t=e._payload,e=e._init;try{return Gl(e(t))}catch{}}return null}function Xa(e){var t=e.type;switch(e.tag){case 24:return"Cache";case 9:return(t.displayName||"Context")+".Consumer";case 10:return(t._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return e=t.render,e=e.displayName||e.name||"",t.displayName||(e!==""?"ForwardRef("+e+")":"ForwardRef");case 7:return"Fragment";case 5:return t;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return Gl(t);case 8:return t===Oo?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if(typeof t=="function")return t.displayName||t.name||null;if(typeof t=="string")return t}return null}function dt(e){switch(typeof e){case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function Wu(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function Ja(e){var t=Wu(e)?"checked":"value",n=Object.getOwnPropertyDescriptor(e.constructor.prototype,t),r=""+e[t];if(!e.hasOwnProperty(t)&&typeof n<"u"&&typeof n.get=="function"&&typeof n.set=="function"){var l=n.get,o=n.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return l.call(this)},set:function(i){r=""+i,o.call(this,i)}}),Object.defineProperty(e,t,{enumerable:n.enumerable}),{getValue:function(){return r},setValue:function(i){r=""+i},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function er(e){e._valueTracker||(e._valueTracker=Ja(e))}function Fu(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),r="";return e&&(r=Wu(e)?e.checked?"true":"false":e.value),e=r,e!==n?(t.setValue(e),!0):!1}function Cr(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}function Yl(e,t){var n=t.checked;return B({},t,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:n??e._wrapperState.initialChecked})}function Ai(e,t){var n=t.defaultValue==null?"":t.defaultValue,r=t.checked!=null?t.checked:t.defaultChecked;n=dt(t.value!=null?t.value:n),e._wrapperState={initialChecked:r,initialValue:n,controlled:t.type==="checkbox"||t.type==="radio"?t.checked!=null:t.value!=null}}function Bu(e,t){t=t.checked,t!=null&&$o(e,"checked",t,!1)}function Kl(e,t){Bu(e,t);var n=dt(t.value),r=t.type;if(n!=null)r==="number"?(n===0&&e.value===""||e.value!=n)&&(e.value=""+n):e.value!==""+n&&(e.value=""+n);else if(r==="submit"||r==="reset"){e.removeAttribute("value");return}t.hasOwnProperty("value")?Vl(e,t.type,n):t.hasOwnProperty("defaultValue")&&Vl(e,t.type,dt(t.defaultValue)),t.checked==null&&t.defaultChecked!=null&&(e.defaultChecked=!!t.defaultChecked)}function Ri(e,t,n){if(t.hasOwnProperty("value")||t.hasOwnProperty("defaultValue")){var r=t.type;if(!(r!=="submit"&&r!=="reset"||t.value!==void 0&&t.value!==null))return;t=""+e._wrapperState.initialValue,n||t===e.value||(e.value=t),e.defaultValue=t}n=e.name,n!==""&&(e.name=""),e.defaultChecked=!!e._wrapperState.initialChecked,n!==""&&(e.name=n)}function Vl(e,t,n){(t!=="number"||Cr(e.ownerDocument)!==e)&&(n==null?e.defaultValue=""+e._wrapperState.initialValue:e.defaultValue!==""+n&&(e.defaultValue=""+n))}var gn=Array.isArray;function Yt(e,t,n,r){if(e=e.options,t){t={};for(var l=0;l<n.length;l++)t["$"+n[l]]=!0;for(n=0;n<e.length;n++)l=t.hasOwnProperty("$"+e[n].value),e[n].selected!==l&&(e[n].selected=l),l&&r&&(e[n].defaultSelected=!0)}else{for(n=""+dt(n),t=null,l=0;l<e.length;l++){if(e[l].value===n){e[l].selected=!0,r&&(e[l].defaultSelected=!0);return}t!==null||e[l].disabled||(t=e[l])}t!==null&&(t.selected=!0)}}function Ql(e,t){if(t.dangerouslySetInnerHTML!=null)throw Error(g(91));return B({},t,{value:void 0,defaultValue:void 0,children:""+e._wrapperState.initialValue})}function Ti(e,t){var n=t.value;if(n==null){if(n=t.children,t=t.defaultValue,n!=null){if(t!=null)throw Error(g(92));if(gn(n)){if(1<n.length)throw Error(g(93));n=n[0]}t=n}t==null&&(t=""),n=t}e._wrapperState={initialValue:dt(n)}}function Hu(e,t){var n=dt(t.value),r=dt(t.defaultValue);n!=null&&(n=""+n,n!==e.value&&(e.value=n),t.defaultValue==null&&e.defaultValue!==n&&(e.defaultValue=n)),r!=null&&(e.defaultValue=""+r)}function Pi(e){var t=e.textContent;t===e._wrapperState.initialValue&&t!==""&&t!==null&&(e.value=t)}function Gu(e){switch(e){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function Zl(e,t){return e==null||e==="http://www.w3.org/1999/xhtml"?Gu(t):e==="http://www.w3.org/2000/svg"&&t==="foreignObject"?"http://www.w3.org/1999/xhtml":e}var tr,Yu=function(e){return typeof MSApp<"u"&&MSApp.execUnsafeLocalFunction?function(t,n,r,l){MSApp.execUnsafeLocalFunction(function(){return e(t,n,r,l)})}:e}(function(e,t){if(e.namespaceURI!=="http://www.w3.org/2000/svg"||"innerHTML"in e)e.innerHTML=t;else{for(tr=tr||document.createElement("div"),tr.innerHTML="<svg>"+t.valueOf().toString()+"</svg>",t=tr.firstChild;e.firstChild;)e.removeChild(e.firstChild);for(;t.firstChild;)e.appendChild(t.firstChild)}});function Pn(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var En={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},qa=["Webkit","ms","Moz","O"];Object.keys(En).forEach(function(e){qa.forEach(function(t){t=t+e.charAt(0).toUpperCase()+e.substring(1),En[t]=En[e]})});function Ku(e,t,n){return t==null||typeof t=="boolean"||t===""?"":n||typeof t!="number"||t===0||En.hasOwnProperty(e)&&En[e]?(""+t).trim():t+"px"}function Vu(e,t){e=e.style;for(var n in t)if(t.hasOwnProperty(n)){var r=n.indexOf("--")===0,l=Ku(n,t[n],r);n==="float"&&(n="cssFloat"),r?e.setProperty(n,l):e[n]=l}}var ba=B({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function Xl(e,t){if(t){if(ba[e]&&(t.children!=null||t.dangerouslySetInnerHTML!=null))throw Error(g(137,e));if(t.dangerouslySetInnerHTML!=null){if(t.children!=null)throw Error(g(60));if(typeof t.dangerouslySetInnerHTML!="object"||!("__html"in t.dangerouslySetInnerHTML))throw Error(g(61))}if(t.style!=null&&typeof t.style!="object")throw Error(g(62))}}function Jl(e,t){if(e.indexOf("-")===-1)return typeof t.is=="string";switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var ql=null;function Uo(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var bl=null,Kt=null,Vt=null;function zi(e){if(e=Qn(e)){if(typeof bl!="function")throw Error(g(280));var t=e.stateNode;t&&(t=el(t),bl(e.stateNode,e.type,t))}}function Qu(e){Kt?Vt?Vt.push(e):Vt=[e]:Kt=e}function Zu(){if(Kt){var e=Kt,t=Vt;if(Vt=Kt=null,zi(e),t)for(e=0;e<t.length;e++)zi(t[e])}}function Xu(e,t){return e(t)}function Ju(){}var gl=!1;function qu(e,t,n){if(gl)return e(t,n);gl=!0;try{return Xu(e,t,n)}finally{gl=!1,(Kt!==null||Vt!==null)&&(Ju(),Zu())}}function zn(e,t){var n=e.stateNode;if(n===null)return null;var r=el(n);if(r===null)return null;n=r[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(r=!r.disabled)||(e=e.type,r=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!r;break e;default:e=!1}if(e)return null;if(n&&typeof n!="function")throw Error(g(231,t,typeof n));return n}var eo=!1;if(Ye)try{var an={};Object.defineProperty(an,"passive",{get:function(){eo=!0}}),window.addEventListener("test",an,an),window.removeEventListener("test",an,an)}catch{eo=!1}function ec(e,t,n,r,l,o,i,u,s){var f=Array.prototype.slice.call(arguments,3);try{t.apply(n,f)}catch(h){this.onError(h)}}var Sn=!1,Nr=null,Ar=!1,to=null,tc={onError:function(e){Sn=!0,Nr=e}};function nc(e,t,n,r,l,o,i,u,s){Sn=!1,Nr=null,ec.apply(tc,arguments)}function rc(e,t,n,r,l,o,i,u,s){if(nc.apply(this,arguments),Sn){if(Sn){var f=Nr;Sn=!1,Nr=null}else throw Error(g(198));Ar||(Ar=!0,to=f)}}function zt(e){var t=e,n=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,t.flags&4098&&(n=t.return),e=t.return;while(e)}return t.tag===3?n:null}function bu(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function Ii(e){if(zt(e)!==e)throw Error(g(188))}function lc(e){var t=e.alternate;if(!t){if(t=zt(e),t===null)throw Error(g(188));return t!==e?null:e}for(var n=e,r=t;;){var l=n.return;if(l===null)break;var o=l.alternate;if(o===null){if(r=l.return,r!==null){n=r;continue}break}if(l.child===o.child){for(o=l.child;o;){if(o===n)return Ii(l),e;if(o===r)return Ii(l),t;o=o.sibling}throw Error(g(188))}if(n.return!==r.return)n=l,r=o;else{for(var i=!1,u=l.child;u;){if(u===n){i=!0,n=l,r=o;break}if(u===r){i=!0,r=l,n=o;break}u=u.sibling}if(!i){for(u=o.child;u;){if(u===n){i=!0,n=o,r=l;break}if(u===r){i=!0,r=o,n=l;break}u=u.sibling}if(!i)throw Error(g(189))}}if(n.alternate!==r)throw Error(g(190))}if(n.tag!==3)throw Error(g(188));return n.stateNode.current===n?e:t}function es(e){return e=lc(e),e!==null?ts(e):null}function ts(e){if(e.tag===5||e.tag===6)return e;for(e=e.child;e!==null;){var t=ts(e);if(t!==null)return t;e=e.sibling}return null}var ns=ye.unstable_scheduleCallback,ji=ye.unstable_cancelCallback,oc=ye.unstable_shouldYield,ic=ye.unstable_requestPaint,Y=ye.unstable_now,uc=ye.unstable_getCurrentPriorityLevel,Wo=ye.unstable_ImmediatePriority,rs=ye.unstable_UserBlockingPriority,Rr=ye.unstable_NormalPriority,sc=ye.unstable_LowPriority,ls=ye.unstable_IdlePriority,Xr=null,Me=null;function ac(e){if(Me&&typeof Me.onCommitFiberRoot=="function")try{Me.onCommitFiberRoot(Xr,e,void 0,(e.current.flags&128)===128)}catch{}}var Ie=Math.clz32?Math.clz32:fc,cc=Math.log,dc=Math.LN2;function fc(e){return e>>>=0,e===0?32:31-(cc(e)/dc|0)|0}var nr=64,rr=4194304;function yn(e){switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return e&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return e&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return e}}function Tr(e,t){var n=e.pendingLanes;if(n===0)return 0;var r=0,l=e.suspendedLanes,o=e.pingedLanes,i=n&268435455;if(i!==0){var u=i&~l;u!==0?r=yn(u):(o&=i,o!==0&&(r=yn(o)))}else i=n&~l,i!==0?r=yn(i):o!==0&&(r=yn(o));if(r===0)return 0;if(t!==0&&t!==r&&!(t&l)&&(l=r&-r,o=t&-t,l>=o||l===16&&(o&4194240)!==0))return t;if(r&4&&(r|=n&16),t=e.entangledLanes,t!==0)for(e=e.entanglements,t&=r;0<t;)n=31-Ie(t),l=1<<n,r|=e[n],t&=~l;return r}function pc(e,t){switch(e){case 1:case 2:case 4:return t+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function mc(e,t){for(var n=e.suspendedLanes,r=e.pingedLanes,l=e.expirationTimes,o=e.pendingLanes;0<o;){var i=31-Ie(o),u=1<<i,s=l[i];s===-1?(!(u&n)||u&r)&&(l[i]=pc(u,t)):s<=t&&(e.expiredLanes|=u),o&=~u}}function no(e){return e=e.pendingLanes&-1073741825,e!==0?e:e&1073741824?1073741824:0}function os(){var e=nr;return nr<<=1,!(nr&4194240)&&(nr=64),e}function yl(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function Kn(e,t,n){e.pendingLanes|=t,t!==536870912&&(e.suspendedLanes=0,e.pingedLanes=0),e=e.eventTimes,t=31-Ie(t),e[t]=n}function hc(e,t){var n=e.pendingLanes&~t;e.pendingLanes=t,e.suspendedLanes=0,e.pingedLanes=0,e.expiredLanes&=t,e.mutableReadLanes&=t,e.entangledLanes&=t,t=e.entanglements;var r=e.eventTimes;for(e=e.expirationTimes;0<n;){var l=31-Ie(n),o=1<<l;t[l]=0,r[l]=-1,e[l]=-1,n&=~o}}function Fo(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var r=31-Ie(n),l=1<<r;l&t|e[r]&t&&(e[r]|=t),n&=~l}}var j=0;function is(e){return e&=-e,1<e?4<e?e&268435455?16:536870912:4:1}var us,Bo,ss,as,cs,ro=!1,lr=[],rt=null,lt=null,ot=null,In=new Map,jn=new Map,be=[],vc="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function Di(e,t){switch(e){case"focusin":case"focusout":rt=null;break;case"dragenter":case"dragleave":lt=null;break;case"mouseover":case"mouseout":ot=null;break;case"pointerover":case"pointerout":In.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":jn.delete(t.pointerId)}}function cn(e,t,n,r,l,o){return e===null||e.nativeEvent!==o?(e={blockedOn:t,domEventName:n,eventSystemFlags:r,nativeEvent:o,targetContainers:[l]},t!==null&&(t=Qn(t),t!==null&&Bo(t)),e):(e.eventSystemFlags|=r,t=e.targetContainers,l!==null&&t.indexOf(l)===-1&&t.push(l),e)}function gc(e,t,n,r,l){switch(t){case"focusin":return rt=cn(rt,e,t,n,r,l),!0;case"dragenter":return lt=cn(lt,e,t,n,r,l),!0;case"mouseover":return ot=cn(ot,e,t,n,r,l),!0;case"pointerover":var o=l.pointerId;return In.set(o,cn(In.get(o)||null,e,t,n,r,l)),!0;case"gotpointercapture":return o=l.pointerId,jn.set(o,cn(jn.get(o)||null,e,t,n,r,l)),!0}return!1}function ds(e){var t=Et(e.target);if(t!==null){var n=zt(t);if(n!==null){if(t=n.tag,t===13){if(t=bu(n),t!==null){e.blockedOn=t,cs(e.priority,function(){ss(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function hr(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=lo(e.domEventName,e.eventSystemFlags,t[0],e.nativeEvent);if(n===null){n=e.nativeEvent;var r=new n.constructor(n.type,n);ql=r,n.target.dispatchEvent(r),ql=null}else return t=Qn(n),t!==null&&Bo(t),e.blockedOn=n,!1;t.shift()}return!0}function $i(e,t,n){hr(e)&&n.delete(t)}function yc(){ro=!1,rt!==null&&hr(rt)&&(rt=null),lt!==null&&hr(lt)&&(lt=null),ot!==null&&hr(ot)&&(ot=null),In.forEach($i),jn.forEach($i)}function dn(e,t){e.blockedOn===t&&(e.blockedOn=null,ro||(ro=!0,ye.unstable_scheduleCallback(ye.unstable_NormalPriority,yc)))}function Dn(e){function t(l){return dn(l,e)}if(0<lr.length){dn(lr[0],e);for(var n=1;n<lr.length;n++){var r=lr[n];r.blockedOn===e&&(r.blockedOn=null)}}for(rt!==null&&dn(rt,e),lt!==null&&dn(lt,e),ot!==null&&dn(ot,e),In.forEach(t),jn.forEach(t),n=0;n<be.length;n++)r=be[n],r.blockedOn===e&&(r.blockedOn=null);for(;0<be.length&&(n=be[0],n.blockedOn===null);)ds(n),n.blockedOn===null&&be.shift()}var Qt=Ze.ReactCurrentBatchConfig,Pr=!0;function wc(e,t,n,r){var l=j,o=Qt.transition;Qt.transition=null;try{j=1,Ho(e,t,n,r)}finally{j=l,Qt.transition=o}}function Ec(e,t,n,r){var l=j,o=Qt.transition;Qt.transition=null;try{j=4,Ho(e,t,n,r)}finally{j=l,Qt.transition=o}}function Ho(e,t,n,r){if(Pr){var l=lo(e,t,n,r);if(l===null)Rl(e,t,r,zr,n),Di(e,r);else if(gc(l,e,t,n,r))r.stopPropagation();else if(Di(e,r),t&4&&-1<vc.indexOf(e)){for(;l!==null;){var o=Qn(l);if(o!==null&&us(o),o=lo(e,t,n,r),o===null&&Rl(e,t,r,zr,n),o===l)break;l=o}l!==null&&r.stopPropagation()}else Rl(e,t,r,null,n)}}var zr=null;function lo(e,t,n,r){if(zr=null,e=Uo(r),e=Et(e),e!==null)if(t=zt(e),t===null)e=null;else if(n=t.tag,n===13){if(e=bu(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null);return zr=e,null}function fs(e){switch(e){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch(uc()){case Wo:return 1;case rs:return 4;case Rr:case sc:return 16;case ls:return 536870912;default:return 16}default:return 16}}var tt=null,Go=null,vr=null;function ps(){if(vr)return vr;var e,t=Go,n=t.length,r,l="value"in tt?tt.value:tt.textContent,o=l.length;for(e=0;e<n&&t[e]===l[e];e++);var i=n-e;for(r=1;r<=i&&t[n-r]===l[o-r];r++);return vr=l.slice(e,1<r?1-r:void 0)}function gr(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function or(){return!0}function Oi(){return!1}function Ee(e){function t(n,r,l,o,i){this._reactName=n,this._targetInst=l,this.type=r,this.nativeEvent=o,this.target=i,this.currentTarget=null;for(var u in e)e.hasOwnProperty(u)&&(n=e[u],this[u]=n?n(o):o[u]);return this.isDefaultPrevented=(o.defaultPrevented!=null?o.defaultPrevented:o.returnValue===!1)?or:Oi,this.isPropagationStopped=Oi,this}return B(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var n=this.nativeEvent;n&&(n.preventDefault?n.preventDefault():typeof n.returnValue!="unknown"&&(n.returnValue=!1),this.isDefaultPrevented=or)},stopPropagation:function(){var n=this.nativeEvent;n&&(n.stopPropagation?n.stopPropagation():typeof n.cancelBubble!="unknown"&&(n.cancelBubble=!0),this.isPropagationStopped=or)},persist:function(){},isPersistent:or}),t}var on={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Yo=Ee(on),Vn=B({},on,{view:0,detail:0}),Sc=Ee(Vn),wl,El,fn,Jr=B({},Vn,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:Ko,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==fn&&(fn&&e.type==="mousemove"?(wl=e.screenX-fn.screenX,El=e.screenY-fn.screenY):El=wl=0,fn=e),wl)},movementY:function(e){return"movementY"in e?e.movementY:El}}),Li=Ee(Jr),kc=B({},Jr,{dataTransfer:0}),_c=Ee(kc),xc=B({},Vn,{relatedTarget:0}),Sl=Ee(xc),Cc=B({},on,{animationName:0,elapsedTime:0,pseudoElement:0}),Nc=Ee(Cc),Ac=B({},on,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),Rc=Ee(Ac),Tc=B({},on,{data:0}),Mi=Ee(Tc),Pc={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},zc={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Ic={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function jc(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=Ic[e])?!!t[e]:!1}function Ko(){return jc}var Dc=B({},Vn,{key:function(e){if(e.key){var t=Pc[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=gr(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?zc[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:Ko,charCode:function(e){return e.type==="keypress"?gr(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?gr(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),$c=Ee(Dc),Oc=B({},Jr,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Ui=Ee(Oc),Lc=B({},Vn,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:Ko}),Mc=Ee(Lc),Uc=B({},on,{propertyName:0,elapsedTime:0,pseudoElement:0}),Wc=Ee(Uc),Fc=B({},Jr,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),Bc=Ee(Fc),Hc=[9,13,27,32],Vo=Ye&&"CompositionEvent"in window,kn=null;Ye&&"documentMode"in document&&(kn=document.documentMode);var Gc=Ye&&"TextEvent"in window&&!kn,ms=Ye&&(!Vo||kn&&8<kn&&11>=kn),Wi=" ",Fi=!1;function hs(e,t){switch(e){case"keyup":return Hc.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function vs(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var $t=!1;function Yc(e,t){switch(e){case"compositionend":return vs(t);case"keypress":return t.which!==32?null:(Fi=!0,Wi);case"textInput":return e=t.data,e===Wi&&Fi?null:e;default:return null}}function Kc(e,t){if($t)return e==="compositionend"||!Vo&&hs(e,t)?(e=ps(),vr=Go=tt=null,$t=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return ms&&t.locale!=="ko"?null:t.data;default:return null}}var Vc={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Bi(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!Vc[e.type]:t==="textarea"}function gs(e,t,n,r){Qu(r),t=Ir(t,"onChange"),0<t.length&&(n=new Yo("onChange","change",null,n,r),e.push({event:n,listeners:t}))}var _n=null,$n=null;function Qc(e){Rs(e,0)}function qr(e){var t=Mt(e);if(Fu(t))return e}function Zc(e,t){if(e==="change")return t}var ys=!1;if(Ye){var kl;if(Ye){var _l="oninput"in document;if(!_l){var Hi=document.createElement("div");Hi.setAttribute("oninput","return;"),_l=typeof Hi.oninput=="function"}kl=_l}else kl=!1;ys=kl&&(!document.documentMode||9<document.documentMode)}function Gi(){_n&&(_n.detachEvent("onpropertychange",ws),$n=_n=null)}function ws(e){if(e.propertyName==="value"&&qr($n)){var t=[];gs(t,$n,e,Uo(e)),qu(Qc,t)}}function Xc(e,t,n){e==="focusin"?(Gi(),_n=t,$n=n,_n.attachEvent("onpropertychange",ws)):e==="focusout"&&Gi()}function Jc(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return qr($n)}function qc(e,t){if(e==="click")return qr(t)}function bc(e,t){if(e==="input"||e==="change")return qr(t)}function ed(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var De=typeof Object.is=="function"?Object.is:ed;function On(e,t){if(De(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++){var l=n[r];if(!Wl.call(t,l)||!De(e[l],t[l]))return!1}return!0}function Yi(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Ki(e,t){var n=Yi(e);e=0;for(var r;n;){if(n.nodeType===3){if(r=e+n.textContent.length,e<=t&&r>=t)return{node:n,offset:t-e};e=r}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=Yi(n)}}function Es(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?Es(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function Ss(){for(var e=window,t=Cr();t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href=="string"}catch{n=!1}if(n)e=t.contentWindow;else break;t=Cr(e.document)}return t}function Qo(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}function td(e){var t=Ss(),n=e.focusedElem,r=e.selectionRange;if(t!==n&&n&&n.ownerDocument&&Es(n.ownerDocument.documentElement,n)){if(r!==null&&Qo(n)){if(t=r.start,e=r.end,e===void 0&&(e=t),"selectionStart"in n)n.selectionStart=t,n.selectionEnd=Math.min(e,n.value.length);else if(e=(t=n.ownerDocument||document)&&t.defaultView||window,e.getSelection){e=e.getSelection();var l=n.textContent.length,o=Math.min(r.start,l);r=r.end===void 0?o:Math.min(r.end,l),!e.extend&&o>r&&(l=r,r=o,o=l),l=Ki(n,o);var i=Ki(n,r);l&&i&&(e.rangeCount!==1||e.anchorNode!==l.node||e.anchorOffset!==l.offset||e.focusNode!==i.node||e.focusOffset!==i.offset)&&(t=t.createRange(),t.setStart(l.node,l.offset),e.removeAllRanges(),o>r?(e.addRange(t),e.extend(i.node,i.offset)):(t.setEnd(i.node,i.offset),e.addRange(t)))}}for(t=[],e=n;e=e.parentNode;)e.nodeType===1&&t.push({element:e,left:e.scrollLeft,top:e.scrollTop});for(typeof n.focus=="function"&&n.focus(),n=0;n<t.length;n++)e=t[n],e.element.scrollLeft=e.left,e.element.scrollTop=e.top}}var nd=Ye&&"documentMode"in document&&11>=document.documentMode,Ot=null,oo=null,xn=null,io=!1;function Vi(e,t,n){var r=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;io||Ot==null||Ot!==Cr(r)||(r=Ot,"selectionStart"in r&&Qo(r)?r={start:r.selectionStart,end:r.selectionEnd}:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection(),r={anchorNode:r.anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset}),xn&&On(xn,r)||(xn=r,r=Ir(oo,"onSelect"),0<r.length&&(t=new Yo("onSelect","select",null,t,n),e.push({event:t,listeners:r}),t.target=Ot)))}function ir(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n["Webkit"+e]="webkit"+t,n["Moz"+e]="moz"+t,n}var Lt={animationend:ir("Animation","AnimationEnd"),animationiteration:ir("Animation","AnimationIteration"),animationstart:ir("Animation","AnimationStart"),transitionend:ir("Transition","TransitionEnd")},xl={},ks={};Ye&&(ks=document.createElement("div").style,"AnimationEvent"in window||(delete Lt.animationend.animation,delete Lt.animationiteration.animation,delete Lt.animationstart.animation),"TransitionEvent"in window||delete Lt.transitionend.transition);function br(e){if(xl[e])return xl[e];if(!Lt[e])return e;var t=Lt[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in ks)return xl[e]=t[n];return e}var _s=br("animationend"),xs=br("animationiteration"),Cs=br("animationstart"),Ns=br("transitionend"),As=new Map,Qi="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function pt(e,t){As.set(e,t),Pt(t,[e])}for(var Cl=0;Cl<Qi.length;Cl++){var Nl=Qi[Cl],rd=Nl.toLowerCase(),ld=Nl[0].toUpperCase()+Nl.slice(1);pt(rd,"on"+ld)}pt(_s,"onAnimationEnd");pt(xs,"onAnimationIteration");pt(Cs,"onAnimationStart");pt("dblclick","onDoubleClick");pt("focusin","onFocus");pt("focusout","onBlur");pt(Ns,"onTransitionEnd");qt("onMouseEnter",["mouseout","mouseover"]);qt("onMouseLeave",["mouseout","mouseover"]);qt("onPointerEnter",["pointerout","pointerover"]);qt("onPointerLeave",["pointerout","pointerover"]);Pt("onChange","change click focusin focusout input keydown keyup selectionchange".split(" "));Pt("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));Pt("onBeforeInput",["compositionend","keypress","textInput","paste"]);Pt("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" "));Pt("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" "));Pt("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var wn="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),od=new Set("cancel close invalid load scroll toggle".split(" ").concat(wn));function Zi(e,t,n){var r=e.type||"unknown-event";e.currentTarget=n,rc(r,t,void 0,e),e.currentTarget=null}function Rs(e,t){t=(t&4)!==0;for(var n=0;n<e.length;n++){var r=e[n],l=r.event;r=r.listeners;e:{var o=void 0;if(t)for(var i=r.length-1;0<=i;i--){var u=r[i],s=u.instance,f=u.currentTarget;if(u=u.listener,s!==o&&l.isPropagationStopped())break e;Zi(l,u,f),o=s}else for(i=0;i<r.length;i++){if(u=r[i],s=u.instance,f=u.currentTarget,u=u.listener,s!==o&&l.isPropagationStopped())break e;Zi(l,u,f),o=s}}}if(Ar)throw e=to,Ar=!1,to=null,e}function O(e,t){var n=t[fo];n===void 0&&(n=t[fo]=new Set);var r=e+"__bubble";n.has(r)||(Ts(t,e,2,!1),n.add(r))}function Al(e,t,n){var r=0;t&&(r|=4),Ts(n,e,r,t)}var ur="_reactListening"+Math.random().toString(36).slice(2);function Ln(e){if(!e[ur]){e[ur]=!0,Ou.forEach(function(n){n!=="selectionchange"&&(od.has(n)||Al(n,!1,e),Al(n,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[ur]||(t[ur]=!0,Al("selectionchange",!1,t))}}function Ts(e,t,n,r){switch(fs(t)){case 1:var l=wc;break;case 4:l=Ec;break;default:l=Ho}n=l.bind(null,t,n,e),l=void 0,!eo||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(l=!0),r?l!==void 0?e.addEventListener(t,n,{capture:!0,passive:l}):e.addEventListener(t,n,!0):l!==void 0?e.addEventListener(t,n,{passive:l}):e.addEventListener(t,n,!1)}function Rl(e,t,n,r,l){var o=r;if(!(t&1)&&!(t&2)&&r!==null)e:for(;;){if(r===null)return;var i=r.tag;if(i===3||i===4){var u=r.stateNode.containerInfo;if(u===l||u.nodeType===8&&u.parentNode===l)break;if(i===4)for(i=r.return;i!==null;){var s=i.tag;if((s===3||s===4)&&(s=i.stateNode.containerInfo,s===l||s.nodeType===8&&s.parentNode===l))return;i=i.return}for(;u!==null;){if(i=Et(u),i===null)return;if(s=i.tag,s===5||s===6){r=o=i;continue e}u=u.parentNode}}r=r.return}qu(function(){var f=o,h=Uo(n),m=[];e:{var p=As.get(e);if(p!==void 0){var w=Yo,E=e;switch(e){case"keypress":if(gr(n)===0)break e;case"keydown":case"keyup":w=$c;break;case"focusin":E="focus",w=Sl;break;case"focusout":E="blur",w=Sl;break;case"beforeblur":case"afterblur":w=Sl;break;case"click":if(n.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":w=Li;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":w=_c;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":w=Mc;break;case _s:case xs:case Cs:w=Nc;break;case Ns:w=Wc;break;case"scroll":w=Sc;break;case"wheel":w=Bc;break;case"copy":case"cut":case"paste":w=Rc;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":w=Ui}var S=(t&4)!==0,D=!S&&e==="scroll",c=S?p!==null?p+"Capture":null:p;S=[];for(var a=f,d;a!==null;){d=a;var v=d.stateNode;if(d.tag===5&&v!==null&&(d=v,c!==null&&(v=zn(a,c),v!=null&&S.push(Mn(a,v,d)))),D)break;a=a.return}0<S.length&&(p=new w(p,E,null,n,h),m.push({event:p,listeners:S}))}}if(!(t&7)){e:{if(p=e==="mouseover"||e==="pointerover",w=e==="mouseout"||e==="pointerout",p&&n!==ql&&(E=n.relatedTarget||n.fromElement)&&(Et(E)||E[Ke]))break e;if((w||p)&&(p=h.window===h?h:(p=h.ownerDocument)?p.defaultView||p.parentWindow:window,w?(E=n.relatedTarget||n.toElement,w=f,E=E?Et(E):null,E!==null&&(D=zt(E),E!==D||E.tag!==5&&E.tag!==6)&&(E=null)):(w=null,E=f),w!==E)){if(S=Li,v="onMouseLeave",c="onMouseEnter",a="mouse",(e==="pointerout"||e==="pointerover")&&(S=Ui,v="onPointerLeave",c="onPointerEnter",a="pointer"),D=w==null?p:Mt(w),d=E==null?p:Mt(E),p=new S(v,a+"leave",w,n,h),p.target=D,p.relatedTarget=d,v=null,Et(h)===f&&(S=new S(c,a+"enter",E,n,h),S.target=d,S.relatedTarget=D,v=S),D=v,w&&E)t:{for(S=w,c=E,a=0,d=S;d;d=It(d))a++;for(d=0,v=c;v;v=It(v))d++;for(;0<a-d;)S=It(S),a--;for(;0<d-a;)c=It(c),d--;for(;a--;){if(S===c||c!==null&&S===c.alternate)break t;S=It(S),c=It(c)}S=null}else S=null;w!==null&&Xi(m,p,w,S,!1),E!==null&&D!==null&&Xi(m,D,E,S,!0)}}e:{if(p=f?Mt(f):window,w=p.nodeName&&p.nodeName.toLowerCase(),w==="select"||w==="input"&&p.type==="file")var _=Zc;else if(Bi(p))if(ys)_=bc;else{_=Jc;var N=Xc}else(w=p.nodeName)&&w.toLowerCase()==="input"&&(p.type==="checkbox"||p.type==="radio")&&(_=qc);if(_&&(_=_(e,f))){gs(m,_,n,h);break e}N&&N(e,p,f),e==="focusout"&&(N=p._wrapperState)&&N.controlled&&p.type==="number"&&Vl(p,"number",p.value)}switch(N=f?Mt(f):window,e){case"focusin":(Bi(N)||N.contentEditable==="true")&&(Ot=N,oo=f,xn=null);break;case"focusout":xn=oo=Ot=null;break;case"mousedown":io=!0;break;case"contextmenu":case"mouseup":case"dragend":io=!1,Vi(m,n,h);break;case"selectionchange":if(nd)break;case"keydown":case"keyup":Vi(m,n,h)}var A;if(Vo)e:{switch(e){case"compositionstart":var R="onCompositionStart";break e;case"compositionend":R="onCompositionEnd";break e;case"compositionupdate":R="onCompositionUpdate";break e}R=void 0}else $t?hs(e,n)&&(R="onCompositionEnd"):e==="keydown"&&n.keyCode===229&&(R="onCompositionStart");R&&(ms&&n.locale!=="ko"&&($t||R!=="onCompositionStart"?R==="onCompositionEnd"&&$t&&(A=ps()):(tt=h,Go="value"in tt?tt.value:tt.textContent,$t=!0)),N=Ir(f,R),0<N.length&&(R=new Mi(R,e,null,n,h),m.push({event:R,listeners:N}),A?R.data=A:(A=vs(n),A!==null&&(R.data=A)))),(A=Gc?Yc(e,n):Kc(e,n))&&(f=Ir(f,"onBeforeInput"),0<f.length&&(h=new Mi("onBeforeInput","beforeinput",null,n,h),m.push({event:h,listeners:f}),h.data=A))}Rs(m,t)})}function Mn(e,t,n){return{instance:e,listener:t,currentTarget:n}}function Ir(e,t){for(var n=t+"Capture",r=[];e!==null;){var l=e,o=l.stateNode;l.tag===5&&o!==null&&(l=o,o=zn(e,n),o!=null&&r.unshift(Mn(e,o,l)),o=zn(e,t),o!=null&&r.push(Mn(e,o,l))),e=e.return}return r}function It(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5);return e||null}function Xi(e,t,n,r,l){for(var o=t._reactName,i=[];n!==null&&n!==r;){var u=n,s=u.alternate,f=u.stateNode;if(s!==null&&s===r)break;u.tag===5&&f!==null&&(u=f,l?(s=zn(n,o),s!=null&&i.unshift(Mn(n,s,u))):l||(s=zn(n,o),s!=null&&i.push(Mn(n,s,u)))),n=n.return}i.length!==0&&e.push({event:t,listeners:i})}var id=/\r\n?/g,ud=/\u0000|\uFFFD/g;function Ji(e){return(typeof e=="string"?e:""+e).replace(id,`
`).replace(ud,"")}function sr(e,t,n){if(t=Ji(t),Ji(e)!==t&&n)throw Error(g(425))}function jr(){}var uo=null,so=null;function ao(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var co=typeof setTimeout=="function"?setTimeout:void 0,sd=typeof clearTimeout=="function"?clearTimeout:void 0,qi=typeof Promise=="function"?Promise:void 0,ad=typeof queueMicrotask=="function"?queueMicrotask:typeof qi<"u"?function(e){return qi.resolve(null).then(e).catch(cd)}:co;function cd(e){setTimeout(function(){throw e})}function Tl(e,t){var n=t,r=0;do{var l=n.nextSibling;if(e.removeChild(n),l&&l.nodeType===8)if(n=l.data,n==="/$"){if(r===0){e.removeChild(l),Dn(t);return}r--}else n!=="$"&&n!=="$?"&&n!=="$!"||r++;n=l}while(n);Dn(t)}function it(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?")break;if(t==="/$")return null}}return e}function bi(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="$"||n==="$!"||n==="$?"){if(t===0)return e;t--}else n==="/$"&&t++}e=e.previousSibling}return null}var un=Math.random().toString(36).slice(2),Le="__reactFiber$"+un,Un="__reactProps$"+un,Ke="__reactContainer$"+un,fo="__reactEvents$"+un,dd="__reactListeners$"+un,fd="__reactHandles$"+un;function Et(e){var t=e[Le];if(t)return t;for(var n=e.parentNode;n;){if(t=n[Ke]||n[Le]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=bi(e);e!==null;){if(n=e[Le])return n;e=bi(e)}return t}e=n,n=e.parentNode}return null}function Qn(e){return e=e[Le]||e[Ke],!e||e.tag!==5&&e.tag!==6&&e.tag!==13&&e.tag!==3?null:e}function Mt(e){if(e.tag===5||e.tag===6)return e.stateNode;throw Error(g(33))}function el(e){return e[Un]||null}var po=[],Ut=-1;function mt(e){return{current:e}}function L(e){0>Ut||(e.current=po[Ut],po[Ut]=null,Ut--)}function $(e,t){Ut++,po[Ut]=e.current,e.current=t}var ft={},oe=mt(ft),fe=mt(!1),Ct=ft;function bt(e,t){var n=e.type.contextTypes;if(!n)return ft;var r=e.stateNode;if(r&&r.__reactInternalMemoizedUnmaskedChildContext===t)return r.__reactInternalMemoizedMaskedChildContext;var l={},o;for(o in n)l[o]=t[o];return r&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=t,e.__reactInternalMemoizedMaskedChildContext=l),l}function pe(e){return e=e.childContextTypes,e!=null}function Dr(){L(fe),L(oe)}function eu(e,t,n){if(oe.current!==ft)throw Error(g(168));$(oe,t),$(fe,n)}function Ps(e,t,n){var r=e.stateNode;if(t=t.childContextTypes,typeof r.getChildContext!="function")return n;r=r.getChildContext();for(var l in r)if(!(l in t))throw Error(g(108,Xa(e)||"Unknown",l));return B({},n,r)}function $r(e){return e=(e=e.stateNode)&&e.__reactInternalMemoizedMergedChildContext||ft,Ct=oe.current,$(oe,e),$(fe,fe.current),!0}function tu(e,t,n){var r=e.stateNode;if(!r)throw Error(g(169));n?(e=Ps(e,t,Ct),r.__reactInternalMemoizedMergedChildContext=e,L(fe),L(oe),$(oe,e)):L(fe),$(fe,n)}var Fe=null,tl=!1,Pl=!1;function zs(e){Fe===null?Fe=[e]:Fe.push(e)}function pd(e){tl=!0,zs(e)}function ht(){if(!Pl&&Fe!==null){Pl=!0;var e=0,t=j;try{var n=Fe;for(j=1;e<n.length;e++){var r=n[e];do r=r(!0);while(r!==null)}Fe=null,tl=!1}catch(l){throw Fe!==null&&(Fe=Fe.slice(e+1)),ns(Wo,ht),l}finally{j=t,Pl=!1}}return null}var Wt=[],Ft=0,Or=null,Lr=0,Se=[],ke=0,Nt=null,Be=1,He="";function yt(e,t){Wt[Ft++]=Lr,Wt[Ft++]=Or,Or=e,Lr=t}function Is(e,t,n){Se[ke++]=Be,Se[ke++]=He,Se[ke++]=Nt,Nt=e;var r=Be;e=He;var l=32-Ie(r)-1;r&=~(1<<l),n+=1;var o=32-Ie(t)+l;if(30<o){var i=l-l%5;o=(r&(1<<i)-1).toString(32),r>>=i,l-=i,Be=1<<32-Ie(t)+l|n<<l|r,He=o+e}else Be=1<<o|n<<l|r,He=e}function Zo(e){e.return!==null&&(yt(e,1),Is(e,1,0))}function Xo(e){for(;e===Or;)Or=Wt[--Ft],Wt[Ft]=null,Lr=Wt[--Ft],Wt[Ft]=null;for(;e===Nt;)Nt=Se[--ke],Se[ke]=null,He=Se[--ke],Se[ke]=null,Be=Se[--ke],Se[ke]=null}var ge=null,ve=null,M=!1,ze=null;function js(e,t){var n=_e(5,null,null,0);n.elementType="DELETED",n.stateNode=t,n.return=e,t=e.deletions,t===null?(e.deletions=[n],e.flags|=16):t.push(n)}function nu(e,t){switch(e.tag){case 5:var n=e.type;return t=t.nodeType!==1||n.toLowerCase()!==t.nodeName.toLowerCase()?null:t,t!==null?(e.stateNode=t,ge=e,ve=it(t.firstChild),!0):!1;case 6:return t=e.pendingProps===""||t.nodeType!==3?null:t,t!==null?(e.stateNode=t,ge=e,ve=null,!0):!1;case 13:return t=t.nodeType!==8?null:t,t!==null?(n=Nt!==null?{id:Be,overflow:He}:null,e.memoizedState={dehydrated:t,treeContext:n,retryLane:1073741824},n=_e(18,null,null,0),n.stateNode=t,n.return=e,e.child=n,ge=e,ve=null,!0):!1;default:return!1}}function mo(e){return(e.mode&1)!==0&&(e.flags&128)===0}function ho(e){if(M){var t=ve;if(t){var n=t;if(!nu(e,t)){if(mo(e))throw Error(g(418));t=it(n.nextSibling);var r=ge;t&&nu(e,t)?js(r,n):(e.flags=e.flags&-4097|2,M=!1,ge=e)}}else{if(mo(e))throw Error(g(418));e.flags=e.flags&-4097|2,M=!1,ge=e}}}function ru(e){for(e=e.return;e!==null&&e.tag!==5&&e.tag!==3&&e.tag!==13;)e=e.return;ge=e}function ar(e){if(e!==ge)return!1;if(!M)return ru(e),M=!0,!1;var t;if((t=e.tag!==3)&&!(t=e.tag!==5)&&(t=e.type,t=t!=="head"&&t!=="body"&&!ao(e.type,e.memoizedProps)),t&&(t=ve)){if(mo(e))throw Ds(),Error(g(418));for(;t;)js(e,t),t=it(t.nextSibling)}if(ru(e),e.tag===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(g(317));e:{for(e=e.nextSibling,t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="/$"){if(t===0){ve=it(e.nextSibling);break e}t--}else n!=="$"&&n!=="$!"&&n!=="$?"||t++}e=e.nextSibling}ve=null}}else ve=ge?it(e.stateNode.nextSibling):null;return!0}function Ds(){for(var e=ve;e;)e=it(e.nextSibling)}function en(){ve=ge=null,M=!1}function Jo(e){ze===null?ze=[e]:ze.push(e)}var md=Ze.ReactCurrentBatchConfig;function pn(e,t,n){if(e=n.ref,e!==null&&typeof e!="function"&&typeof e!="object"){if(n._owner){if(n=n._owner,n){if(n.tag!==1)throw Error(g(309));var r=n.stateNode}if(!r)throw Error(g(147,e));var l=r,o=""+e;return t!==null&&t.ref!==null&&typeof t.ref=="function"&&t.ref._stringRef===o?t.ref:(t=function(i){var u=l.refs;i===null?delete u[o]:u[o]=i},t._stringRef=o,t)}if(typeof e!="string")throw Error(g(284));if(!n._owner)throw Error(g(290,e))}return e}function cr(e,t){throw e=Object.prototype.toString.call(t),Error(g(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e))}function lu(e){var t=e._init;return t(e._payload)}function $s(e){function t(c,a){if(e){var d=c.deletions;d===null?(c.deletions=[a],c.flags|=16):d.push(a)}}function n(c,a){if(!e)return null;for(;a!==null;)t(c,a),a=a.sibling;return null}function r(c,a){for(c=new Map;a!==null;)a.key!==null?c.set(a.key,a):c.set(a.index,a),a=a.sibling;return c}function l(c,a){return c=ct(c,a),c.index=0,c.sibling=null,c}function o(c,a,d){return c.index=d,e?(d=c.alternate,d!==null?(d=d.index,d<a?(c.flags|=2,a):d):(c.flags|=2,a)):(c.flags|=1048576,a)}function i(c){return e&&c.alternate===null&&(c.flags|=2),c}function u(c,a,d,v){return a===null||a.tag!==6?(a=Ll(d,c.mode,v),a.return=c,a):(a=l(a,d),a.return=c,a)}function s(c,a,d,v){var _=d.type;return _===Dt?h(c,a,d.props.children,v,d.key):a!==null&&(a.elementType===_||typeof _=="object"&&_!==null&&_.$$typeof===Je&&lu(_)===a.type)?(v=l(a,d.props),v.ref=pn(c,a,d),v.return=c,v):(v=xr(d.type,d.key,d.props,null,c.mode,v),v.ref=pn(c,a,d),v.return=c,v)}function f(c,a,d,v){return a===null||a.tag!==4||a.stateNode.containerInfo!==d.containerInfo||a.stateNode.implementation!==d.implementation?(a=Ml(d,c.mode,v),a.return=c,a):(a=l(a,d.children||[]),a.return=c,a)}function h(c,a,d,v,_){return a===null||a.tag!==7?(a=xt(d,c.mode,v,_),a.return=c,a):(a=l(a,d),a.return=c,a)}function m(c,a,d){if(typeof a=="string"&&a!==""||typeof a=="number")return a=Ll(""+a,c.mode,d),a.return=c,a;if(typeof a=="object"&&a!==null){switch(a.$$typeof){case bn:return d=xr(a.type,a.key,a.props,null,c.mode,d),d.ref=pn(c,null,a),d.return=c,d;case jt:return a=Ml(a,c.mode,d),a.return=c,a;case Je:var v=a._init;return m(c,v(a._payload),d)}if(gn(a)||sn(a))return a=xt(a,c.mode,d,null),a.return=c,a;cr(c,a)}return null}function p(c,a,d,v){var _=a!==null?a.key:null;if(typeof d=="string"&&d!==""||typeof d=="number")return _!==null?null:u(c,a,""+d,v);if(typeof d=="object"&&d!==null){switch(d.$$typeof){case bn:return d.key===_?s(c,a,d,v):null;case jt:return d.key===_?f(c,a,d,v):null;case Je:return _=d._init,p(c,a,_(d._payload),v)}if(gn(d)||sn(d))return _!==null?null:h(c,a,d,v,null);cr(c,d)}return null}function w(c,a,d,v,_){if(typeof v=="string"&&v!==""||typeof v=="number")return c=c.get(d)||null,u(a,c,""+v,_);if(typeof v=="object"&&v!==null){switch(v.$$typeof){case bn:return c=c.get(v.key===null?d:v.key)||null,s(a,c,v,_);case jt:return c=c.get(v.key===null?d:v.key)||null,f(a,c,v,_);case Je:var N=v._init;return w(c,a,d,N(v._payload),_)}if(gn(v)||sn(v))return c=c.get(d)||null,h(a,c,v,_,null);cr(a,v)}return null}function E(c,a,d,v){for(var _=null,N=null,A=a,R=a=0,U=null;A!==null&&R<d.length;R++){A.index>R?(U=A,A=null):U=A.sibling;var P=p(c,A,d[R],v);if(P===null){A===null&&(A=U);break}e&&A&&P.alternate===null&&t(c,A),a=o(P,a,R),N===null?_=P:N.sibling=P,N=P,A=U}if(R===d.length)return n(c,A),M&&yt(c,R),_;if(A===null){for(;R<d.length;R++)A=m(c,d[R],v),A!==null&&(a=o(A,a,R),N===null?_=A:N.sibling=A,N=A);return M&&yt(c,R),_}for(A=r(c,A);R<d.length;R++)U=w(A,c,R,d[R],v),U!==null&&(e&&U.alternate!==null&&A.delete(U.key===null?R:U.key),a=o(U,a,R),N===null?_=U:N.sibling=U,N=U);return e&&A.forEach(function(k){return t(c,k)}),M&&yt(c,R),_}function S(c,a,d,v){var _=sn(d);if(typeof _!="function")throw Error(g(150));if(d=_.call(d),d==null)throw Error(g(151));for(var N=_=null,A=a,R=a=0,U=null,P=d.next();A!==null&&!P.done;R++,P=d.next()){A.index>R?(U=A,A=null):U=A.sibling;var k=p(c,A,P.value,v);if(k===null){A===null&&(A=U);break}e&&A&&k.alternate===null&&t(c,A),a=o(k,a,R),N===null?_=k:N.sibling=k,N=k,A=U}if(P.done)return n(c,A),M&&yt(c,R),_;if(A===null){for(;!P.done;R++,P=d.next())P=m(c,P.value,v),P!==null&&(a=o(P,a,R),N===null?_=P:N.sibling=P,N=P);return M&&yt(c,R),_}for(A=r(c,A);!P.done;R++,P=d.next())P=w(A,c,R,P.value,v),P!==null&&(e&&P.alternate!==null&&A.delete(P.key===null?R:P.key),a=o(P,a,R),N===null?_=P:N.sibling=P,N=P);return e&&A.forEach(function(V){return t(c,V)}),M&&yt(c,R),_}function D(c,a,d,v){if(typeof d=="object"&&d!==null&&d.type===Dt&&d.key===null&&(d=d.props.children),typeof d=="object"&&d!==null){switch(d.$$typeof){case bn:e:{for(var _=d.key,N=a;N!==null;){if(N.key===_){if(_=d.type,_===Dt){if(N.tag===7){n(c,N.sibling),a=l(N,d.props.children),a.return=c,c=a;break e}}else if(N.elementType===_||typeof _=="object"&&_!==null&&_.$$typeof===Je&&lu(_)===N.type){n(c,N.sibling),a=l(N,d.props),a.ref=pn(c,N,d),a.return=c,c=a;break e}n(c,N);break}else t(c,N);N=N.sibling}d.type===Dt?(a=xt(d.props.children,c.mode,v,d.key),a.return=c,c=a):(v=xr(d.type,d.key,d.props,null,c.mode,v),v.ref=pn(c,a,d),v.return=c,c=v)}return i(c);case jt:e:{for(N=d.key;a!==null;){if(a.key===N)if(a.tag===4&&a.stateNode.containerInfo===d.containerInfo&&a.stateNode.implementation===d.implementation){n(c,a.sibling),a=l(a,d.children||[]),a.return=c,c=a;break e}else{n(c,a);break}else t(c,a);a=a.sibling}a=Ml(d,c.mode,v),a.return=c,c=a}return i(c);case Je:return N=d._init,D(c,a,N(d._payload),v)}if(gn(d))return E(c,a,d,v);if(sn(d))return S(c,a,d,v);cr(c,d)}return typeof d=="string"&&d!==""||typeof d=="number"?(d=""+d,a!==null&&a.tag===6?(n(c,a.sibling),a=l(a,d),a.return=c,c=a):(n(c,a),a=Ll(d,c.mode,v),a.return=c,c=a),i(c)):n(c,a)}return D}var tn=$s(!0),Os=$s(!1),Mr=mt(null),Ur=null,Bt=null,qo=null;function bo(){qo=Bt=Ur=null}function ei(e){var t=Mr.current;L(Mr),e._currentValue=t}function vo(e,t,n){for(;e!==null;){var r=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,r!==null&&(r.childLanes|=t)):r!==null&&(r.childLanes&t)!==t&&(r.childLanes|=t),e===n)break;e=e.return}}function Zt(e,t){Ur=e,qo=Bt=null,e=e.dependencies,e!==null&&e.firstContext!==null&&(e.lanes&t&&(de=!0),e.firstContext=null)}function Ce(e){var t=e._currentValue;if(qo!==e)if(e={context:e,memoizedValue:t,next:null},Bt===null){if(Ur===null)throw Error(g(308));Bt=e,Ur.dependencies={lanes:0,firstContext:e}}else Bt=Bt.next=e;return t}var St=null;function ti(e){St===null?St=[e]:St.push(e)}function Ls(e,t,n,r){var l=t.interleaved;return l===null?(n.next=n,ti(t)):(n.next=l.next,l.next=n),t.interleaved=n,Ve(e,r)}function Ve(e,t){e.lanes|=t;var n=e.alternate;for(n!==null&&(n.lanes|=t),n=e,e=e.return;e!==null;)e.childLanes|=t,n=e.alternate,n!==null&&(n.childLanes|=t),n=e,e=e.return;return n.tag===3?n.stateNode:null}var qe=!1;function ni(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function Ms(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,effects:e.effects})}function Ge(e,t){return{eventTime:e,lane:t,tag:0,payload:null,callback:null,next:null}}function ut(e,t,n){var r=e.updateQueue;if(r===null)return null;if(r=r.shared,I&2){var l=r.pending;return l===null?t.next=t:(t.next=l.next,l.next=t),r.pending=t,Ve(e,n)}return l=r.interleaved,l===null?(t.next=t,ti(r)):(t.next=l.next,l.next=t),r.interleaved=t,Ve(e,n)}function yr(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,(n&4194240)!==0)){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,Fo(e,n)}}function ou(e,t){var n=e.updateQueue,r=e.alternate;if(r!==null&&(r=r.updateQueue,n===r)){var l=null,o=null;if(n=n.firstBaseUpdate,n!==null){do{var i={eventTime:n.eventTime,lane:n.lane,tag:n.tag,payload:n.payload,callback:n.callback,next:null};o===null?l=o=i:o=o.next=i,n=n.next}while(n!==null);o===null?l=o=t:o=o.next=t}else l=o=t;n={baseState:r.baseState,firstBaseUpdate:l,lastBaseUpdate:o,shared:r.shared,effects:r.effects},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}function Wr(e,t,n,r){var l=e.updateQueue;qe=!1;var o=l.firstBaseUpdate,i=l.lastBaseUpdate,u=l.shared.pending;if(u!==null){l.shared.pending=null;var s=u,f=s.next;s.next=null,i===null?o=f:i.next=f,i=s;var h=e.alternate;h!==null&&(h=h.updateQueue,u=h.lastBaseUpdate,u!==i&&(u===null?h.firstBaseUpdate=f:u.next=f,h.lastBaseUpdate=s))}if(o!==null){var m=l.baseState;i=0,h=f=s=null,u=o;do{var p=u.lane,w=u.eventTime;if((r&p)===p){h!==null&&(h=h.next={eventTime:w,lane:0,tag:u.tag,payload:u.payload,callback:u.callback,next:null});e:{var E=e,S=u;switch(p=t,w=n,S.tag){case 1:if(E=S.payload,typeof E=="function"){m=E.call(w,m,p);break e}m=E;break e;case 3:E.flags=E.flags&-65537|128;case 0:if(E=S.payload,p=typeof E=="function"?E.call(w,m,p):E,p==null)break e;m=B({},m,p);break e;case 2:qe=!0}}u.callback!==null&&u.lane!==0&&(e.flags|=64,p=l.effects,p===null?l.effects=[u]:p.push(u))}else w={eventTime:w,lane:p,tag:u.tag,payload:u.payload,callback:u.callback,next:null},h===null?(f=h=w,s=m):h=h.next=w,i|=p;if(u=u.next,u===null){if(u=l.shared.pending,u===null)break;p=u,u=p.next,p.next=null,l.lastBaseUpdate=p,l.shared.pending=null}}while(!0);if(h===null&&(s=m),l.baseState=s,l.firstBaseUpdate=f,l.lastBaseUpdate=h,t=l.shared.interleaved,t!==null){l=t;do i|=l.lane,l=l.next;while(l!==t)}else o===null&&(l.shared.lanes=0);Rt|=i,e.lanes=i,e.memoizedState=m}}function iu(e,t,n){if(e=t.effects,t.effects=null,e!==null)for(t=0;t<e.length;t++){var r=e[t],l=r.callback;if(l!==null){if(r.callback=null,r=n,typeof l!="function")throw Error(g(191,l));l.call(r)}}}var Zn={},Ue=mt(Zn),Wn=mt(Zn),Fn=mt(Zn);function kt(e){if(e===Zn)throw Error(g(174));return e}function ri(e,t){switch($(Fn,t),$(Wn,e),$(Ue,Zn),e=t.nodeType,e){case 9:case 11:t=(t=t.documentElement)?t.namespaceURI:Zl(null,"");break;default:e=e===8?t.parentNode:t,t=e.namespaceURI||null,e=e.tagName,t=Zl(t,e)}L(Ue),$(Ue,t)}function nn(){L(Ue),L(Wn),L(Fn)}function Us(e){kt(Fn.current);var t=kt(Ue.current),n=Zl(t,e.type);t!==n&&($(Wn,e),$(Ue,n))}function li(e){Wn.current===e&&(L(Ue),L(Wn))}var W=mt(0);function Fr(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||n.data==="$?"||n.data==="$!"))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!==void 0){if(t.flags&128)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var zl=[];function oi(){for(var e=0;e<zl.length;e++)zl[e]._workInProgressVersionPrimary=null;zl.length=0}var wr=Ze.ReactCurrentDispatcher,Il=Ze.ReactCurrentBatchConfig,At=0,F=null,Q=null,J=null,Br=!1,Cn=!1,Bn=0,hd=0;function ne(){throw Error(g(321))}function ii(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!De(e[n],t[n]))return!1;return!0}function ui(e,t,n,r,l,o){if(At=o,F=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,wr.current=e===null||e.memoizedState===null?wd:Ed,e=n(r,l),Cn){o=0;do{if(Cn=!1,Bn=0,25<=o)throw Error(g(301));o+=1,J=Q=null,t.updateQueue=null,wr.current=Sd,e=n(r,l)}while(Cn)}if(wr.current=Hr,t=Q!==null&&Q.next!==null,At=0,J=Q=F=null,Br=!1,t)throw Error(g(300));return e}function si(){var e=Bn!==0;return Bn=0,e}function Oe(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return J===null?F.memoizedState=J=e:J=J.next=e,J}function Ne(){if(Q===null){var e=F.alternate;e=e!==null?e.memoizedState:null}else e=Q.next;var t=J===null?F.memoizedState:J.next;if(t!==null)J=t,Q=e;else{if(e===null)throw Error(g(310));Q=e,e={memoizedState:Q.memoizedState,baseState:Q.baseState,baseQueue:Q.baseQueue,queue:Q.queue,next:null},J===null?F.memoizedState=J=e:J=J.next=e}return J}function Hn(e,t){return typeof t=="function"?t(e):t}function jl(e){var t=Ne(),n=t.queue;if(n===null)throw Error(g(311));n.lastRenderedReducer=e;var r=Q,l=r.baseQueue,o=n.pending;if(o!==null){if(l!==null){var i=l.next;l.next=o.next,o.next=i}r.baseQueue=l=o,n.pending=null}if(l!==null){o=l.next,r=r.baseState;var u=i=null,s=null,f=o;do{var h=f.lane;if((At&h)===h)s!==null&&(s=s.next={lane:0,action:f.action,hasEagerState:f.hasEagerState,eagerState:f.eagerState,next:null}),r=f.hasEagerState?f.eagerState:e(r,f.action);else{var m={lane:h,action:f.action,hasEagerState:f.hasEagerState,eagerState:f.eagerState,next:null};s===null?(u=s=m,i=r):s=s.next=m,F.lanes|=h,Rt|=h}f=f.next}while(f!==null&&f!==o);s===null?i=r:s.next=u,De(r,t.memoizedState)||(de=!0),t.memoizedState=r,t.baseState=i,t.baseQueue=s,n.lastRenderedState=r}if(e=n.interleaved,e!==null){l=e;do o=l.lane,F.lanes|=o,Rt|=o,l=l.next;while(l!==e)}else l===null&&(n.lanes=0);return[t.memoizedState,n.dispatch]}function Dl(e){var t=Ne(),n=t.queue;if(n===null)throw Error(g(311));n.lastRenderedReducer=e;var r=n.dispatch,l=n.pending,o=t.memoizedState;if(l!==null){n.pending=null;var i=l=l.next;do o=e(o,i.action),i=i.next;while(i!==l);De(o,t.memoizedState)||(de=!0),t.memoizedState=o,t.baseQueue===null&&(t.baseState=o),n.lastRenderedState=o}return[o,r]}function Ws(){}function Fs(e,t){var n=F,r=Ne(),l=t(),o=!De(r.memoizedState,l);if(o&&(r.memoizedState=l,de=!0),r=r.queue,ai(Gs.bind(null,n,r,e),[e]),r.getSnapshot!==t||o||J!==null&&J.memoizedState.tag&1){if(n.flags|=2048,Gn(9,Hs.bind(null,n,r,l,t),void 0,null),q===null)throw Error(g(349));At&30||Bs(n,t,l)}return l}function Bs(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=F.updateQueue,t===null?(t={lastEffect:null,stores:null},F.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function Hs(e,t,n,r){t.value=n,t.getSnapshot=r,Ys(t)&&Ks(e)}function Gs(e,t,n){return n(function(){Ys(t)&&Ks(e)})}function Ys(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!De(e,n)}catch{return!0}}function Ks(e){var t=Ve(e,1);t!==null&&je(t,e,1,-1)}function uu(e){var t=Oe();return typeof e=="function"&&(e=e()),t.memoizedState=t.baseState=e,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:Hn,lastRenderedState:e},t.queue=e,e=e.dispatch=yd.bind(null,F,e),[t.memoizedState,e]}function Gn(e,t,n,r){return e={tag:e,create:t,destroy:n,deps:r,next:null},t=F.updateQueue,t===null?(t={lastEffect:null,stores:null},F.updateQueue=t,t.lastEffect=e.next=e):(n=t.lastEffect,n===null?t.lastEffect=e.next=e:(r=n.next,n.next=e,e.next=r,t.lastEffect=e)),e}function Vs(){return Ne().memoizedState}function Er(e,t,n,r){var l=Oe();F.flags|=e,l.memoizedState=Gn(1|t,n,void 0,r===void 0?null:r)}function nl(e,t,n,r){var l=Ne();r=r===void 0?null:r;var o=void 0;if(Q!==null){var i=Q.memoizedState;if(o=i.destroy,r!==null&&ii(r,i.deps)){l.memoizedState=Gn(t,n,o,r);return}}F.flags|=e,l.memoizedState=Gn(1|t,n,o,r)}function su(e,t){return Er(8390656,8,e,t)}function ai(e,t){return nl(2048,8,e,t)}function Qs(e,t){return nl(4,2,e,t)}function Zs(e,t){return nl(4,4,e,t)}function Xs(e,t){if(typeof t=="function")return e=e(),t(e),function(){t(null)};if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function Js(e,t,n){return n=n!=null?n.concat([e]):null,nl(4,4,Xs.bind(null,t,e),n)}function ci(){}function qs(e,t){var n=Ne();t=t===void 0?null:t;var r=n.memoizedState;return r!==null&&t!==null&&ii(t,r[1])?r[0]:(n.memoizedState=[e,t],e)}function bs(e,t){var n=Ne();t=t===void 0?null:t;var r=n.memoizedState;return r!==null&&t!==null&&ii(t,r[1])?r[0]:(e=e(),n.memoizedState=[e,t],e)}function ea(e,t,n){return At&21?(De(n,t)||(n=os(),F.lanes|=n,Rt|=n,e.baseState=!0),t):(e.baseState&&(e.baseState=!1,de=!0),e.memoizedState=n)}function vd(e,t){var n=j;j=n!==0&&4>n?n:4,e(!0);var r=Il.transition;Il.transition={};try{e(!1),t()}finally{j=n,Il.transition=r}}function ta(){return Ne().memoizedState}function gd(e,t,n){var r=at(e);if(n={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null},na(e))ra(t,n);else if(n=Ls(e,t,n,r),n!==null){var l=se();je(n,e,r,l),la(n,t,r)}}function yd(e,t,n){var r=at(e),l={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null};if(na(e))ra(t,l);else{var o=e.alternate;if(e.lanes===0&&(o===null||o.lanes===0)&&(o=t.lastRenderedReducer,o!==null))try{var i=t.lastRenderedState,u=o(i,n);if(l.hasEagerState=!0,l.eagerState=u,De(u,i)){var s=t.interleaved;s===null?(l.next=l,ti(t)):(l.next=s.next,s.next=l),t.interleaved=l;return}}catch{}finally{}n=Ls(e,t,l,r),n!==null&&(l=se(),je(n,e,r,l),la(n,t,r))}}function na(e){var t=e.alternate;return e===F||t!==null&&t===F}function ra(e,t){Cn=Br=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function la(e,t,n){if(n&4194240){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,Fo(e,n)}}var Hr={readContext:Ce,useCallback:ne,useContext:ne,useEffect:ne,useImperativeHandle:ne,useInsertionEffect:ne,useLayoutEffect:ne,useMemo:ne,useReducer:ne,useRef:ne,useState:ne,useDebugValue:ne,useDeferredValue:ne,useTransition:ne,useMutableSource:ne,useSyncExternalStore:ne,useId:ne,unstable_isNewReconciler:!1},wd={readContext:Ce,useCallback:function(e,t){return Oe().memoizedState=[e,t===void 0?null:t],e},useContext:Ce,useEffect:su,useImperativeHandle:function(e,t,n){return n=n!=null?n.concat([e]):null,Er(4194308,4,Xs.bind(null,t,e),n)},useLayoutEffect:function(e,t){return Er(4194308,4,e,t)},useInsertionEffect:function(e,t){return Er(4,2,e,t)},useMemo:function(e,t){var n=Oe();return t=t===void 0?null:t,e=e(),n.memoizedState=[e,t],e},useReducer:function(e,t,n){var r=Oe();return t=n!==void 0?n(t):t,r.memoizedState=r.baseState=t,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:t},r.queue=e,e=e.dispatch=gd.bind(null,F,e),[r.memoizedState,e]},useRef:function(e){var t=Oe();return e={current:e},t.memoizedState=e},useState:uu,useDebugValue:ci,useDeferredValue:function(e){return Oe().memoizedState=e},useTransition:function(){var e=uu(!1),t=e[0];return e=vd.bind(null,e[1]),Oe().memoizedState=e,[t,e]},useMutableSource:function(){},useSyncExternalStore:function(e,t,n){var r=F,l=Oe();if(M){if(n===void 0)throw Error(g(407));n=n()}else{if(n=t(),q===null)throw Error(g(349));At&30||Bs(r,t,n)}l.memoizedState=n;var o={value:n,getSnapshot:t};return l.queue=o,su(Gs.bind(null,r,o,e),[e]),r.flags|=2048,Gn(9,Hs.bind(null,r,o,n,t),void 0,null),n},useId:function(){var e=Oe(),t=q.identifierPrefix;if(M){var n=He,r=Be;n=(r&~(1<<32-Ie(r)-1)).toString(32)+n,t=":"+t+"R"+n,n=Bn++,0<n&&(t+="H"+n.toString(32)),t+=":"}else n=hd++,t=":"+t+"r"+n.toString(32)+":";return e.memoizedState=t},unstable_isNewReconciler:!1},Ed={readContext:Ce,useCallback:qs,useContext:Ce,useEffect:ai,useImperativeHandle:Js,useInsertionEffect:Qs,useLayoutEffect:Zs,useMemo:bs,useReducer:jl,useRef:Vs,useState:function(){return jl(Hn)},useDebugValue:ci,useDeferredValue:function(e){var t=Ne();return ea(t,Q.memoizedState,e)},useTransition:function(){var e=jl(Hn)[0],t=Ne().memoizedState;return[e,t]},useMutableSource:Ws,useSyncExternalStore:Fs,useId:ta,unstable_isNewReconciler:!1},Sd={readContext:Ce,useCallback:qs,useContext:Ce,useEffect:ai,useImperativeHandle:Js,useInsertionEffect:Qs,useLayoutEffect:Zs,useMemo:bs,useReducer:Dl,useRef:Vs,useState:function(){return Dl(Hn)},useDebugValue:ci,useDeferredValue:function(e){var t=Ne();return Q===null?t.memoizedState=e:ea(t,Q.memoizedState,e)},useTransition:function(){var e=Dl(Hn)[0],t=Ne().memoizedState;return[e,t]},useMutableSource:Ws,useSyncExternalStore:Fs,useId:ta,unstable_isNewReconciler:!1};function Te(e,t){if(e&&e.defaultProps){t=B({},t),e=e.defaultProps;for(var n in e)t[n]===void 0&&(t[n]=e[n]);return t}return t}function go(e,t,n,r){t=e.memoizedState,n=n(r,t),n=n==null?t:B({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var rl={isMounted:function(e){return(e=e._reactInternals)?zt(e)===e:!1},enqueueSetState:function(e,t,n){e=e._reactInternals;var r=se(),l=at(e),o=Ge(r,l);o.payload=t,n!=null&&(o.callback=n),t=ut(e,o,l),t!==null&&(je(t,e,l,r),yr(t,e,l))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var r=se(),l=at(e),o=Ge(r,l);o.tag=1,o.payload=t,n!=null&&(o.callback=n),t=ut(e,o,l),t!==null&&(je(t,e,l,r),yr(t,e,l))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=se(),r=at(e),l=Ge(n,r);l.tag=2,t!=null&&(l.callback=t),t=ut(e,l,r),t!==null&&(je(t,e,r,n),yr(t,e,r))}};function au(e,t,n,r,l,o,i){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(r,o,i):t.prototype&&t.prototype.isPureReactComponent?!On(n,r)||!On(l,o):!0}function oa(e,t,n){var r=!1,l=ft,o=t.contextType;return typeof o=="object"&&o!==null?o=Ce(o):(l=pe(t)?Ct:oe.current,r=t.contextTypes,o=(r=r!=null)?bt(e,l):ft),t=new t(n,o),e.memoizedState=t.state!==null&&t.state!==void 0?t.state:null,t.updater=rl,e.stateNode=t,t._reactInternals=e,r&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=l,e.__reactInternalMemoizedMaskedChildContext=o),t}function cu(e,t,n,r){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(n,r),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(n,r),t.state!==e&&rl.enqueueReplaceState(t,t.state,null)}function yo(e,t,n,r){var l=e.stateNode;l.props=n,l.state=e.memoizedState,l.refs={},ni(e);var o=t.contextType;typeof o=="object"&&o!==null?l.context=Ce(o):(o=pe(t)?Ct:oe.current,l.context=bt(e,o)),l.state=e.memoizedState,o=t.getDerivedStateFromProps,typeof o=="function"&&(go(e,t,o,n),l.state=e.memoizedState),typeof t.getDerivedStateFromProps=="function"||typeof l.getSnapshotBeforeUpdate=="function"||typeof l.UNSAFE_componentWillMount!="function"&&typeof l.componentWillMount!="function"||(t=l.state,typeof l.componentWillMount=="function"&&l.componentWillMount(),typeof l.UNSAFE_componentWillMount=="function"&&l.UNSAFE_componentWillMount(),t!==l.state&&rl.enqueueReplaceState(l,l.state,null),Wr(e,n,l,r),l.state=e.memoizedState),typeof l.componentDidMount=="function"&&(e.flags|=4194308)}function rn(e,t){try{var n="",r=t;do n+=Za(r),r=r.return;while(r);var l=n}catch(o){l=`
Error generating stack: `+o.message+`
`+o.stack}return{value:e,source:t,stack:l,digest:null}}function $l(e,t,n){return{value:e,source:null,stack:n??null,digest:t??null}}function wo(e,t){try{console.error(t.value)}catch(n){setTimeout(function(){throw n})}}var kd=typeof WeakMap=="function"?WeakMap:Map;function ia(e,t,n){n=Ge(-1,n),n.tag=3,n.payload={element:null};var r=t.value;return n.callback=function(){Yr||(Yr=!0,To=r),wo(e,t)},n}function ua(e,t,n){n=Ge(-1,n),n.tag=3;var r=e.type.getDerivedStateFromError;if(typeof r=="function"){var l=t.value;n.payload=function(){return r(l)},n.callback=function(){wo(e,t)}}var o=e.stateNode;return o!==null&&typeof o.componentDidCatch=="function"&&(n.callback=function(){wo(e,t),typeof r!="function"&&(st===null?st=new Set([this]):st.add(this));var i=t.stack;this.componentDidCatch(t.value,{componentStack:i!==null?i:""})}),n}function du(e,t,n){var r=e.pingCache;if(r===null){r=e.pingCache=new kd;var l=new Set;r.set(t,l)}else l=r.get(t),l===void 0&&(l=new Set,r.set(t,l));l.has(n)||(l.add(n),e=Od.bind(null,e,t,n),t.then(e,e))}function fu(e){do{var t;if((t=e.tag===13)&&(t=e.memoizedState,t=t!==null?t.dehydrated!==null:!0),t)return e;e=e.return}while(e!==null);return null}function pu(e,t,n,r,l){return e.mode&1?(e.flags|=65536,e.lanes=l,e):(e===t?e.flags|=65536:(e.flags|=128,n.flags|=131072,n.flags&=-52805,n.tag===1&&(n.alternate===null?n.tag=17:(t=Ge(-1,1),t.tag=2,ut(n,t,1))),n.lanes|=1),e)}var _d=Ze.ReactCurrentOwner,de=!1;function ue(e,t,n,r){t.child=e===null?Os(t,null,n,r):tn(t,e.child,n,r)}function mu(e,t,n,r,l){n=n.render;var o=t.ref;return Zt(t,l),r=ui(e,t,n,r,o,l),n=si(),e!==null&&!de?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~l,Qe(e,t,l)):(M&&n&&Zo(t),t.flags|=1,ue(e,t,r,l),t.child)}function hu(e,t,n,r,l){if(e===null){var o=n.type;return typeof o=="function"&&!yi(o)&&o.defaultProps===void 0&&n.compare===null&&n.defaultProps===void 0?(t.tag=15,t.type=o,sa(e,t,o,r,l)):(e=xr(n.type,null,r,t,t.mode,l),e.ref=t.ref,e.return=t,t.child=e)}if(o=e.child,!(e.lanes&l)){var i=o.memoizedProps;if(n=n.compare,n=n!==null?n:On,n(i,r)&&e.ref===t.ref)return Qe(e,t,l)}return t.flags|=1,e=ct(o,r),e.ref=t.ref,e.return=t,t.child=e}function sa(e,t,n,r,l){if(e!==null){var o=e.memoizedProps;if(On(o,r)&&e.ref===t.ref)if(de=!1,t.pendingProps=r=o,(e.lanes&l)!==0)e.flags&131072&&(de=!0);else return t.lanes=e.lanes,Qe(e,t,l)}return Eo(e,t,n,r,l)}function aa(e,t,n){var r=t.pendingProps,l=r.children,o=e!==null?e.memoizedState:null;if(r.mode==="hidden")if(!(t.mode&1))t.memoizedState={baseLanes:0,cachePool:null,transitions:null},$(Gt,he),he|=n;else{if(!(n&1073741824))return e=o!==null?o.baseLanes|n:n,t.lanes=t.childLanes=1073741824,t.memoizedState={baseLanes:e,cachePool:null,transitions:null},t.updateQueue=null,$(Gt,he),he|=e,null;t.memoizedState={baseLanes:0,cachePool:null,transitions:null},r=o!==null?o.baseLanes:n,$(Gt,he),he|=r}else o!==null?(r=o.baseLanes|n,t.memoizedState=null):r=n,$(Gt,he),he|=r;return ue(e,t,l,n),t.child}function ca(e,t){var n=t.ref;(e===null&&n!==null||e!==null&&e.ref!==n)&&(t.flags|=512,t.flags|=2097152)}function Eo(e,t,n,r,l){var o=pe(n)?Ct:oe.current;return o=bt(t,o),Zt(t,l),n=ui(e,t,n,r,o,l),r=si(),e!==null&&!de?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~l,Qe(e,t,l)):(M&&r&&Zo(t),t.flags|=1,ue(e,t,n,l),t.child)}function vu(e,t,n,r,l){if(pe(n)){var o=!0;$r(t)}else o=!1;if(Zt(t,l),t.stateNode===null)Sr(e,t),oa(t,n,r),yo(t,n,r,l),r=!0;else if(e===null){var i=t.stateNode,u=t.memoizedProps;i.props=u;var s=i.context,f=n.contextType;typeof f=="object"&&f!==null?f=Ce(f):(f=pe(n)?Ct:oe.current,f=bt(t,f));var h=n.getDerivedStateFromProps,m=typeof h=="function"||typeof i.getSnapshotBeforeUpdate=="function";m||typeof i.UNSAFE_componentWillReceiveProps!="function"&&typeof i.componentWillReceiveProps!="function"||(u!==r||s!==f)&&cu(t,i,r,f),qe=!1;var p=t.memoizedState;i.state=p,Wr(t,r,i,l),s=t.memoizedState,u!==r||p!==s||fe.current||qe?(typeof h=="function"&&(go(t,n,h,r),s=t.memoizedState),(u=qe||au(t,n,u,r,p,s,f))?(m||typeof i.UNSAFE_componentWillMount!="function"&&typeof i.componentWillMount!="function"||(typeof i.componentWillMount=="function"&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount=="function"&&i.UNSAFE_componentWillMount()),typeof i.componentDidMount=="function"&&(t.flags|=4194308)):(typeof i.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=r,t.memoizedState=s),i.props=r,i.state=s,i.context=f,r=u):(typeof i.componentDidMount=="function"&&(t.flags|=4194308),r=!1)}else{i=t.stateNode,Ms(e,t),u=t.memoizedProps,f=t.type===t.elementType?u:Te(t.type,u),i.props=f,m=t.pendingProps,p=i.context,s=n.contextType,typeof s=="object"&&s!==null?s=Ce(s):(s=pe(n)?Ct:oe.current,s=bt(t,s));var w=n.getDerivedStateFromProps;(h=typeof w=="function"||typeof i.getSnapshotBeforeUpdate=="function")||typeof i.UNSAFE_componentWillReceiveProps!="function"&&typeof i.componentWillReceiveProps!="function"||(u!==m||p!==s)&&cu(t,i,r,s),qe=!1,p=t.memoizedState,i.state=p,Wr(t,r,i,l);var E=t.memoizedState;u!==m||p!==E||fe.current||qe?(typeof w=="function"&&(go(t,n,w,r),E=t.memoizedState),(f=qe||au(t,n,f,r,p,E,s)||!1)?(h||typeof i.UNSAFE_componentWillUpdate!="function"&&typeof i.componentWillUpdate!="function"||(typeof i.componentWillUpdate=="function"&&i.componentWillUpdate(r,E,s),typeof i.UNSAFE_componentWillUpdate=="function"&&i.UNSAFE_componentWillUpdate(r,E,s)),typeof i.componentDidUpdate=="function"&&(t.flags|=4),typeof i.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof i.componentDidUpdate!="function"||u===e.memoizedProps&&p===e.memoizedState||(t.flags|=4),typeof i.getSnapshotBeforeUpdate!="function"||u===e.memoizedProps&&p===e.memoizedState||(t.flags|=1024),t.memoizedProps=r,t.memoizedState=E),i.props=r,i.state=E,i.context=s,r=f):(typeof i.componentDidUpdate!="function"||u===e.memoizedProps&&p===e.memoizedState||(t.flags|=4),typeof i.getSnapshotBeforeUpdate!="function"||u===e.memoizedProps&&p===e.memoizedState||(t.flags|=1024),r=!1)}return So(e,t,n,r,o,l)}function So(e,t,n,r,l,o){ca(e,t);var i=(t.flags&128)!==0;if(!r&&!i)return l&&tu(t,n,!1),Qe(e,t,o);r=t.stateNode,_d.current=t;var u=i&&typeof n.getDerivedStateFromError!="function"?null:r.render();return t.flags|=1,e!==null&&i?(t.child=tn(t,e.child,null,o),t.child=tn(t,null,u,o)):ue(e,t,u,o),t.memoizedState=r.state,l&&tu(t,n,!0),t.child}function da(e){var t=e.stateNode;t.pendingContext?eu(e,t.pendingContext,t.pendingContext!==t.context):t.context&&eu(e,t.context,!1),ri(e,t.containerInfo)}function gu(e,t,n,r,l){return en(),Jo(l),t.flags|=256,ue(e,t,n,r),t.child}var ko={dehydrated:null,treeContext:null,retryLane:0};function _o(e){return{baseLanes:e,cachePool:null,transitions:null}}function fa(e,t,n){var r=t.pendingProps,l=W.current,o=!1,i=(t.flags&128)!==0,u;if((u=i)||(u=e!==null&&e.memoizedState===null?!1:(l&2)!==0),u?(o=!0,t.flags&=-129):(e===null||e.memoizedState!==null)&&(l|=1),$(W,l&1),e===null)return ho(t),e=t.memoizedState,e!==null&&(e=e.dehydrated,e!==null)?(t.mode&1?e.data==="$!"?t.lanes=8:t.lanes=1073741824:t.lanes=1,null):(i=r.children,e=r.fallback,o?(r=t.mode,o=t.child,i={mode:"hidden",children:i},!(r&1)&&o!==null?(o.childLanes=0,o.pendingProps=i):o=il(i,r,0,null),e=xt(e,r,n,null),o.return=t,e.return=t,o.sibling=e,t.child=o,t.child.memoizedState=_o(n),t.memoizedState=ko,e):di(t,i));if(l=e.memoizedState,l!==null&&(u=l.dehydrated,u!==null))return xd(e,t,i,r,u,l,n);if(o){o=r.fallback,i=t.mode,l=e.child,u=l.sibling;var s={mode:"hidden",children:r.children};return!(i&1)&&t.child!==l?(r=t.child,r.childLanes=0,r.pendingProps=s,t.deletions=null):(r=ct(l,s),r.subtreeFlags=l.subtreeFlags&14680064),u!==null?o=ct(u,o):(o=xt(o,i,n,null),o.flags|=2),o.return=t,r.return=t,r.sibling=o,t.child=r,r=o,o=t.child,i=e.child.memoizedState,i=i===null?_o(n):{baseLanes:i.baseLanes|n,cachePool:null,transitions:i.transitions},o.memoizedState=i,o.childLanes=e.childLanes&~n,t.memoizedState=ko,r}return o=e.child,e=o.sibling,r=ct(o,{mode:"visible",children:r.children}),!(t.mode&1)&&(r.lanes=n),r.return=t,r.sibling=null,e!==null&&(n=t.deletions,n===null?(t.deletions=[e],t.flags|=16):n.push(e)),t.child=r,t.memoizedState=null,r}function di(e,t){return t=il({mode:"visible",children:t},e.mode,0,null),t.return=e,e.child=t}function dr(e,t,n,r){return r!==null&&Jo(r),tn(t,e.child,null,n),e=di(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function xd(e,t,n,r,l,o,i){if(n)return t.flags&256?(t.flags&=-257,r=$l(Error(g(422))),dr(e,t,i,r)):t.memoizedState!==null?(t.child=e.child,t.flags|=128,null):(o=r.fallback,l=t.mode,r=il({mode:"visible",children:r.children},l,0,null),o=xt(o,l,i,null),o.flags|=2,r.return=t,o.return=t,r.sibling=o,t.child=r,t.mode&1&&tn(t,e.child,null,i),t.child.memoizedState=_o(i),t.memoizedState=ko,o);if(!(t.mode&1))return dr(e,t,i,null);if(l.data==="$!"){if(r=l.nextSibling&&l.nextSibling.dataset,r)var u=r.dgst;return r=u,o=Error(g(419)),r=$l(o,r,void 0),dr(e,t,i,r)}if(u=(i&e.childLanes)!==0,de||u){if(r=q,r!==null){switch(i&-i){case 4:l=2;break;case 16:l=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:l=32;break;case 536870912:l=268435456;break;default:l=0}l=l&(r.suspendedLanes|i)?0:l,l!==0&&l!==o.retryLane&&(o.retryLane=l,Ve(e,l),je(r,e,l,-1))}return gi(),r=$l(Error(g(421))),dr(e,t,i,r)}return l.data==="$?"?(t.flags|=128,t.child=e.child,t=Ld.bind(null,e),l._reactRetry=t,null):(e=o.treeContext,ve=it(l.nextSibling),ge=t,M=!0,ze=null,e!==null&&(Se[ke++]=Be,Se[ke++]=He,Se[ke++]=Nt,Be=e.id,He=e.overflow,Nt=t),t=di(t,r.children),t.flags|=4096,t)}function yu(e,t,n){e.lanes|=t;var r=e.alternate;r!==null&&(r.lanes|=t),vo(e.return,t,n)}function Ol(e,t,n,r,l){var o=e.memoizedState;o===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:l}:(o.isBackwards=t,o.rendering=null,o.renderingStartTime=0,o.last=r,o.tail=n,o.tailMode=l)}function pa(e,t,n){var r=t.pendingProps,l=r.revealOrder,o=r.tail;if(ue(e,t,r.children,n),r=W.current,r&2)r=r&1|2,t.flags|=128;else{if(e!==null&&e.flags&128)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&yu(e,n,t);else if(e.tag===19)yu(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}r&=1}if($(W,r),!(t.mode&1))t.memoizedState=null;else switch(l){case"forwards":for(n=t.child,l=null;n!==null;)e=n.alternate,e!==null&&Fr(e)===null&&(l=n),n=n.sibling;n=l,n===null?(l=t.child,t.child=null):(l=n.sibling,n.sibling=null),Ol(t,!1,l,n,o);break;case"backwards":for(n=null,l=t.child,t.child=null;l!==null;){if(e=l.alternate,e!==null&&Fr(e)===null){t.child=l;break}e=l.sibling,l.sibling=n,n=l,l=e}Ol(t,!0,n,null,o);break;case"together":Ol(t,!1,null,null,void 0);break;default:t.memoizedState=null}return t.child}function Sr(e,t){!(t.mode&1)&&e!==null&&(e.alternate=null,t.alternate=null,t.flags|=2)}function Qe(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),Rt|=t.lanes,!(n&t.childLanes))return null;if(e!==null&&t.child!==e.child)throw Error(g(153));if(t.child!==null){for(e=t.child,n=ct(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=ct(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function Cd(e,t,n){switch(t.tag){case 3:da(t),en();break;case 5:Us(t);break;case 1:pe(t.type)&&$r(t);break;case 4:ri(t,t.stateNode.containerInfo);break;case 10:var r=t.type._context,l=t.memoizedProps.value;$(Mr,r._currentValue),r._currentValue=l;break;case 13:if(r=t.memoizedState,r!==null)return r.dehydrated!==null?($(W,W.current&1),t.flags|=128,null):n&t.child.childLanes?fa(e,t,n):($(W,W.current&1),e=Qe(e,t,n),e!==null?e.sibling:null);$(W,W.current&1);break;case 19:if(r=(n&t.childLanes)!==0,e.flags&128){if(r)return pa(e,t,n);t.flags|=128}if(l=t.memoizedState,l!==null&&(l.rendering=null,l.tail=null,l.lastEffect=null),$(W,W.current),r)break;return null;case 22:case 23:return t.lanes=0,aa(e,t,n)}return Qe(e,t,n)}var ma,xo,ha,va;ma=function(e,t){for(var n=t.child;n!==null;){if(n.tag===5||n.tag===6)e.appendChild(n.stateNode);else if(n.tag!==4&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return;n=n.return}n.sibling.return=n.return,n=n.sibling}};xo=function(){};ha=function(e,t,n,r){var l=e.memoizedProps;if(l!==r){e=t.stateNode,kt(Ue.current);var o=null;switch(n){case"input":l=Yl(e,l),r=Yl(e,r),o=[];break;case"select":l=B({},l,{value:void 0}),r=B({},r,{value:void 0}),o=[];break;case"textarea":l=Ql(e,l),r=Ql(e,r),o=[];break;default:typeof l.onClick!="function"&&typeof r.onClick=="function"&&(e.onclick=jr)}Xl(n,r);var i;n=null;for(f in l)if(!r.hasOwnProperty(f)&&l.hasOwnProperty(f)&&l[f]!=null)if(f==="style"){var u=l[f];for(i in u)u.hasOwnProperty(i)&&(n||(n={}),n[i]="")}else f!=="dangerouslySetInnerHTML"&&f!=="children"&&f!=="suppressContentEditableWarning"&&f!=="suppressHydrationWarning"&&f!=="autoFocus"&&(Tn.hasOwnProperty(f)?o||(o=[]):(o=o||[]).push(f,null));for(f in r){var s=r[f];if(u=l!=null?l[f]:void 0,r.hasOwnProperty(f)&&s!==u&&(s!=null||u!=null))if(f==="style")if(u){for(i in u)!u.hasOwnProperty(i)||s&&s.hasOwnProperty(i)||(n||(n={}),n[i]="");for(i in s)s.hasOwnProperty(i)&&u[i]!==s[i]&&(n||(n={}),n[i]=s[i])}else n||(o||(o=[]),o.push(f,n)),n=s;else f==="dangerouslySetInnerHTML"?(s=s?s.__html:void 0,u=u?u.__html:void 0,s!=null&&u!==s&&(o=o||[]).push(f,s)):f==="children"?typeof s!="string"&&typeof s!="number"||(o=o||[]).push(f,""+s):f!=="suppressContentEditableWarning"&&f!=="suppressHydrationWarning"&&(Tn.hasOwnProperty(f)?(s!=null&&f==="onScroll"&&O("scroll",e),o||u===s||(o=[])):(o=o||[]).push(f,s))}n&&(o=o||[]).push("style",n);var f=o;(t.updateQueue=f)&&(t.flags|=4)}};va=function(e,t,n,r){n!==r&&(t.flags|=4)};function mn(e,t){if(!M)switch(e.tailMode){case"hidden":t=e.tail;for(var n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null;break;case"collapsed":n=e.tail;for(var r=null;n!==null;)n.alternate!==null&&(r=n),n=n.sibling;r===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:r.sibling=null}}function re(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,r=0;if(t)for(var l=e.child;l!==null;)n|=l.lanes|l.childLanes,r|=l.subtreeFlags&14680064,r|=l.flags&14680064,l.return=e,l=l.sibling;else for(l=e.child;l!==null;)n|=l.lanes|l.childLanes,r|=l.subtreeFlags,r|=l.flags,l.return=e,l=l.sibling;return e.subtreeFlags|=r,e.childLanes=n,t}function Nd(e,t,n){var r=t.pendingProps;switch(Xo(t),t.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return re(t),null;case 1:return pe(t.type)&&Dr(),re(t),null;case 3:return r=t.stateNode,nn(),L(fe),L(oe),oi(),r.pendingContext&&(r.context=r.pendingContext,r.pendingContext=null),(e===null||e.child===null)&&(ar(t)?t.flags|=4:e===null||e.memoizedState.isDehydrated&&!(t.flags&256)||(t.flags|=1024,ze!==null&&(Io(ze),ze=null))),xo(e,t),re(t),null;case 5:li(t);var l=kt(Fn.current);if(n=t.type,e!==null&&t.stateNode!=null)ha(e,t,n,r,l),e.ref!==t.ref&&(t.flags|=512,t.flags|=2097152);else{if(!r){if(t.stateNode===null)throw Error(g(166));return re(t),null}if(e=kt(Ue.current),ar(t)){r=t.stateNode,n=t.type;var o=t.memoizedProps;switch(r[Le]=t,r[Un]=o,e=(t.mode&1)!==0,n){case"dialog":O("cancel",r),O("close",r);break;case"iframe":case"object":case"embed":O("load",r);break;case"video":case"audio":for(l=0;l<wn.length;l++)O(wn[l],r);break;case"source":O("error",r);break;case"img":case"image":case"link":O("error",r),O("load",r);break;case"details":O("toggle",r);break;case"input":Ai(r,o),O("invalid",r);break;case"select":r._wrapperState={wasMultiple:!!o.multiple},O("invalid",r);break;case"textarea":Ti(r,o),O("invalid",r)}Xl(n,o),l=null;for(var i in o)if(o.hasOwnProperty(i)){var u=o[i];i==="children"?typeof u=="string"?r.textContent!==u&&(o.suppressHydrationWarning!==!0&&sr(r.textContent,u,e),l=["children",u]):typeof u=="number"&&r.textContent!==""+u&&(o.suppressHydrationWarning!==!0&&sr(r.textContent,u,e),l=["children",""+u]):Tn.hasOwnProperty(i)&&u!=null&&i==="onScroll"&&O("scroll",r)}switch(n){case"input":er(r),Ri(r,o,!0);break;case"textarea":er(r),Pi(r);break;case"select":case"option":break;default:typeof o.onClick=="function"&&(r.onclick=jr)}r=l,t.updateQueue=r,r!==null&&(t.flags|=4)}else{i=l.nodeType===9?l:l.ownerDocument,e==="http://www.w3.org/1999/xhtml"&&(e=Gu(n)),e==="http://www.w3.org/1999/xhtml"?n==="script"?(e=i.createElement("div"),e.innerHTML="<script><\/script>",e=e.removeChild(e.firstChild)):typeof r.is=="string"?e=i.createElement(n,{is:r.is}):(e=i.createElement(n),n==="select"&&(i=e,r.multiple?i.multiple=!0:r.size&&(i.size=r.size))):e=i.createElementNS(e,n),e[Le]=t,e[Un]=r,ma(e,t,!1,!1),t.stateNode=e;e:{switch(i=Jl(n,r),n){case"dialog":O("cancel",e),O("close",e),l=r;break;case"iframe":case"object":case"embed":O("load",e),l=r;break;case"video":case"audio":for(l=0;l<wn.length;l++)O(wn[l],e);l=r;break;case"source":O("error",e),l=r;break;case"img":case"image":case"link":O("error",e),O("load",e),l=r;break;case"details":O("toggle",e),l=r;break;case"input":Ai(e,r),l=Yl(e,r),O("invalid",e);break;case"option":l=r;break;case"select":e._wrapperState={wasMultiple:!!r.multiple},l=B({},r,{value:void 0}),O("invalid",e);break;case"textarea":Ti(e,r),l=Ql(e,r),O("invalid",e);break;default:l=r}Xl(n,l),u=l;for(o in u)if(u.hasOwnProperty(o)){var s=u[o];o==="style"?Vu(e,s):o==="dangerouslySetInnerHTML"?(s=s?s.__html:void 0,s!=null&&Yu(e,s)):o==="children"?typeof s=="string"?(n!=="textarea"||s!=="")&&Pn(e,s):typeof s=="number"&&Pn(e,""+s):o!=="suppressContentEditableWarning"&&o!=="suppressHydrationWarning"&&o!=="autoFocus"&&(Tn.hasOwnProperty(o)?s!=null&&o==="onScroll"&&O("scroll",e):s!=null&&$o(e,o,s,i))}switch(n){case"input":er(e),Ri(e,r,!1);break;case"textarea":er(e),Pi(e);break;case"option":r.value!=null&&e.setAttribute("value",""+dt(r.value));break;case"select":e.multiple=!!r.multiple,o=r.value,o!=null?Yt(e,!!r.multiple,o,!1):r.defaultValue!=null&&Yt(e,!!r.multiple,r.defaultValue,!0);break;default:typeof l.onClick=="function"&&(e.onclick=jr)}switch(n){case"button":case"input":case"select":case"textarea":r=!!r.autoFocus;break e;case"img":r=!0;break e;default:r=!1}}r&&(t.flags|=4)}t.ref!==null&&(t.flags|=512,t.flags|=2097152)}return re(t),null;case 6:if(e&&t.stateNode!=null)va(e,t,e.memoizedProps,r);else{if(typeof r!="string"&&t.stateNode===null)throw Error(g(166));if(n=kt(Fn.current),kt(Ue.current),ar(t)){if(r=t.stateNode,n=t.memoizedProps,r[Le]=t,(o=r.nodeValue!==n)&&(e=ge,e!==null))switch(e.tag){case 3:sr(r.nodeValue,n,(e.mode&1)!==0);break;case 5:e.memoizedProps.suppressHydrationWarning!==!0&&sr(r.nodeValue,n,(e.mode&1)!==0)}o&&(t.flags|=4)}else r=(n.nodeType===9?n:n.ownerDocument).createTextNode(r),r[Le]=t,t.stateNode=r}return re(t),null;case 13:if(L(W),r=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(M&&ve!==null&&t.mode&1&&!(t.flags&128))Ds(),en(),t.flags|=98560,o=!1;else if(o=ar(t),r!==null&&r.dehydrated!==null){if(e===null){if(!o)throw Error(g(318));if(o=t.memoizedState,o=o!==null?o.dehydrated:null,!o)throw Error(g(317));o[Le]=t}else en(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;re(t),o=!1}else ze!==null&&(Io(ze),ze=null),o=!0;if(!o)return t.flags&65536?t:null}return t.flags&128?(t.lanes=n,t):(r=r!==null,r!==(e!==null&&e.memoizedState!==null)&&r&&(t.child.flags|=8192,t.mode&1&&(e===null||W.current&1?Z===0&&(Z=3):gi())),t.updateQueue!==null&&(t.flags|=4),re(t),null);case 4:return nn(),xo(e,t),e===null&&Ln(t.stateNode.containerInfo),re(t),null;case 10:return ei(t.type._context),re(t),null;case 17:return pe(t.type)&&Dr(),re(t),null;case 19:if(L(W),o=t.memoizedState,o===null)return re(t),null;if(r=(t.flags&128)!==0,i=o.rendering,i===null)if(r)mn(o,!1);else{if(Z!==0||e!==null&&e.flags&128)for(e=t.child;e!==null;){if(i=Fr(e),i!==null){for(t.flags|=128,mn(o,!1),r=i.updateQueue,r!==null&&(t.updateQueue=r,t.flags|=4),t.subtreeFlags=0,r=n,n=t.child;n!==null;)o=n,e=r,o.flags&=14680066,i=o.alternate,i===null?(o.childLanes=0,o.lanes=e,o.child=null,o.subtreeFlags=0,o.memoizedProps=null,o.memoizedState=null,o.updateQueue=null,o.dependencies=null,o.stateNode=null):(o.childLanes=i.childLanes,o.lanes=i.lanes,o.child=i.child,o.subtreeFlags=0,o.deletions=null,o.memoizedProps=i.memoizedProps,o.memoizedState=i.memoizedState,o.updateQueue=i.updateQueue,o.type=i.type,e=i.dependencies,o.dependencies=e===null?null:{lanes:e.lanes,firstContext:e.firstContext}),n=n.sibling;return $(W,W.current&1|2),t.child}e=e.sibling}o.tail!==null&&Y()>ln&&(t.flags|=128,r=!0,mn(o,!1),t.lanes=4194304)}else{if(!r)if(e=Fr(i),e!==null){if(t.flags|=128,r=!0,n=e.updateQueue,n!==null&&(t.updateQueue=n,t.flags|=4),mn(o,!0),o.tail===null&&o.tailMode==="hidden"&&!i.alternate&&!M)return re(t),null}else 2*Y()-o.renderingStartTime>ln&&n!==1073741824&&(t.flags|=128,r=!0,mn(o,!1),t.lanes=4194304);o.isBackwards?(i.sibling=t.child,t.child=i):(n=o.last,n!==null?n.sibling=i:t.child=i,o.last=i)}return o.tail!==null?(t=o.tail,o.rendering=t,o.tail=t.sibling,o.renderingStartTime=Y(),t.sibling=null,n=W.current,$(W,r?n&1|2:n&1),t):(re(t),null);case 22:case 23:return vi(),r=t.memoizedState!==null,e!==null&&e.memoizedState!==null!==r&&(t.flags|=8192),r&&t.mode&1?he&1073741824&&(re(t),t.subtreeFlags&6&&(t.flags|=8192)):re(t),null;case 24:return null;case 25:return null}throw Error(g(156,t.tag))}function Ad(e,t){switch(Xo(t),t.tag){case 1:return pe(t.type)&&Dr(),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return nn(),L(fe),L(oe),oi(),e=t.flags,e&65536&&!(e&128)?(t.flags=e&-65537|128,t):null;case 5:return li(t),null;case 13:if(L(W),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(g(340));en()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return L(W),null;case 4:return nn(),null;case 10:return ei(t.type._context),null;case 22:case 23:return vi(),null;case 24:return null;default:return null}}var fr=!1,le=!1,Rd=typeof WeakSet=="function"?WeakSet:Set,x=null;function Ht(e,t){var n=e.ref;if(n!==null)if(typeof n=="function")try{n(null)}catch(r){H(e,t,r)}else n.current=null}function Co(e,t,n){try{n()}catch(r){H(e,t,r)}}var wu=!1;function Td(e,t){if(uo=Pr,e=Ss(),Qo(e)){if("selectionStart"in e)var n={start:e.selectionStart,end:e.selectionEnd};else e:{n=(n=e.ownerDocument)&&n.defaultView||window;var r=n.getSelection&&n.getSelection();if(r&&r.rangeCount!==0){n=r.anchorNode;var l=r.anchorOffset,o=r.focusNode;r=r.focusOffset;try{n.nodeType,o.nodeType}catch{n=null;break e}var i=0,u=-1,s=-1,f=0,h=0,m=e,p=null;t:for(;;){for(var w;m!==n||l!==0&&m.nodeType!==3||(u=i+l),m!==o||r!==0&&m.nodeType!==3||(s=i+r),m.nodeType===3&&(i+=m.nodeValue.length),(w=m.firstChild)!==null;)p=m,m=w;for(;;){if(m===e)break t;if(p===n&&++f===l&&(u=i),p===o&&++h===r&&(s=i),(w=m.nextSibling)!==null)break;m=p,p=m.parentNode}m=w}n=u===-1||s===-1?null:{start:u,end:s}}else n=null}n=n||{start:0,end:0}}else n=null;for(so={focusedElem:e,selectionRange:n},Pr=!1,x=t;x!==null;)if(t=x,e=t.child,(t.subtreeFlags&1028)!==0&&e!==null)e.return=t,x=e;else for(;x!==null;){t=x;try{var E=t.alternate;if(t.flags&1024)switch(t.tag){case 0:case 11:case 15:break;case 1:if(E!==null){var S=E.memoizedProps,D=E.memoizedState,c=t.stateNode,a=c.getSnapshotBeforeUpdate(t.elementType===t.type?S:Te(t.type,S),D);c.__reactInternalSnapshotBeforeUpdate=a}break;case 3:var d=t.stateNode.containerInfo;d.nodeType===1?d.textContent="":d.nodeType===9&&d.documentElement&&d.removeChild(d.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(g(163))}}catch(v){H(t,t.return,v)}if(e=t.sibling,e!==null){e.return=t.return,x=e;break}x=t.return}return E=wu,wu=!1,E}function Nn(e,t,n){var r=t.updateQueue;if(r=r!==null?r.lastEffect:null,r!==null){var l=r=r.next;do{if((l.tag&e)===e){var o=l.destroy;l.destroy=void 0,o!==void 0&&Co(t,n,o)}l=l.next}while(l!==r)}}function ll(e,t){if(t=t.updateQueue,t=t!==null?t.lastEffect:null,t!==null){var n=t=t.next;do{if((n.tag&e)===e){var r=n.create;n.destroy=r()}n=n.next}while(n!==t)}}function No(e){var t=e.ref;if(t!==null){var n=e.stateNode;switch(e.tag){case 5:e=n;break;default:e=n}typeof t=="function"?t(e):t.current=e}}function ga(e){var t=e.alternate;t!==null&&(e.alternate=null,ga(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&(delete t[Le],delete t[Un],delete t[fo],delete t[dd],delete t[fd])),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}function ya(e){return e.tag===5||e.tag===3||e.tag===4}function Eu(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||ya(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Ao(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.nodeType===8?n.parentNode.insertBefore(e,t):n.insertBefore(e,t):(n.nodeType===8?(t=n.parentNode,t.insertBefore(e,n)):(t=n,t.appendChild(e)),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=jr));else if(r!==4&&(e=e.child,e!==null))for(Ao(e,t,n),e=e.sibling;e!==null;)Ao(e,t,n),e=e.sibling}function Ro(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.insertBefore(e,t):n.appendChild(e);else if(r!==4&&(e=e.child,e!==null))for(Ro(e,t,n),e=e.sibling;e!==null;)Ro(e,t,n),e=e.sibling}var b=null,Pe=!1;function Xe(e,t,n){for(n=n.child;n!==null;)wa(e,t,n),n=n.sibling}function wa(e,t,n){if(Me&&typeof Me.onCommitFiberUnmount=="function")try{Me.onCommitFiberUnmount(Xr,n)}catch{}switch(n.tag){case 5:le||Ht(n,t);case 6:var r=b,l=Pe;b=null,Xe(e,t,n),b=r,Pe=l,b!==null&&(Pe?(e=b,n=n.stateNode,e.nodeType===8?e.parentNode.removeChild(n):e.removeChild(n)):b.removeChild(n.stateNode));break;case 18:b!==null&&(Pe?(e=b,n=n.stateNode,e.nodeType===8?Tl(e.parentNode,n):e.nodeType===1&&Tl(e,n),Dn(e)):Tl(b,n.stateNode));break;case 4:r=b,l=Pe,b=n.stateNode.containerInfo,Pe=!0,Xe(e,t,n),b=r,Pe=l;break;case 0:case 11:case 14:case 15:if(!le&&(r=n.updateQueue,r!==null&&(r=r.lastEffect,r!==null))){l=r=r.next;do{var o=l,i=o.destroy;o=o.tag,i!==void 0&&(o&2||o&4)&&Co(n,t,i),l=l.next}while(l!==r)}Xe(e,t,n);break;case 1:if(!le&&(Ht(n,t),r=n.stateNode,typeof r.componentWillUnmount=="function"))try{r.props=n.memoizedProps,r.state=n.memoizedState,r.componentWillUnmount()}catch(u){H(n,t,u)}Xe(e,t,n);break;case 21:Xe(e,t,n);break;case 22:n.mode&1?(le=(r=le)||n.memoizedState!==null,Xe(e,t,n),le=r):Xe(e,t,n);break;default:Xe(e,t,n)}}function Su(e){var t=e.updateQueue;if(t!==null){e.updateQueue=null;var n=e.stateNode;n===null&&(n=e.stateNode=new Rd),t.forEach(function(r){var l=Md.bind(null,e,r);n.has(r)||(n.add(r),r.then(l,l))})}}function Re(e,t){var n=t.deletions;if(n!==null)for(var r=0;r<n.length;r++){var l=n[r];try{var o=e,i=t,u=i;e:for(;u!==null;){switch(u.tag){case 5:b=u.stateNode,Pe=!1;break e;case 3:b=u.stateNode.containerInfo,Pe=!0;break e;case 4:b=u.stateNode.containerInfo,Pe=!0;break e}u=u.return}if(b===null)throw Error(g(160));wa(o,i,l),b=null,Pe=!1;var s=l.alternate;s!==null&&(s.return=null),l.return=null}catch(f){H(l,t,f)}}if(t.subtreeFlags&12854)for(t=t.child;t!==null;)Ea(t,e),t=t.sibling}function Ea(e,t){var n=e.alternate,r=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(Re(t,e),$e(e),r&4){try{Nn(3,e,e.return),ll(3,e)}catch(S){H(e,e.return,S)}try{Nn(5,e,e.return)}catch(S){H(e,e.return,S)}}break;case 1:Re(t,e),$e(e),r&512&&n!==null&&Ht(n,n.return);break;case 5:if(Re(t,e),$e(e),r&512&&n!==null&&Ht(n,n.return),e.flags&32){var l=e.stateNode;try{Pn(l,"")}catch(S){H(e,e.return,S)}}if(r&4&&(l=e.stateNode,l!=null)){var o=e.memoizedProps,i=n!==null?n.memoizedProps:o,u=e.type,s=e.updateQueue;if(e.updateQueue=null,s!==null)try{u==="input"&&o.type==="radio"&&o.name!=null&&Bu(l,o),Jl(u,i);var f=Jl(u,o);for(i=0;i<s.length;i+=2){var h=s[i],m=s[i+1];h==="style"?Vu(l,m):h==="dangerouslySetInnerHTML"?Yu(l,m):h==="children"?Pn(l,m):$o(l,h,m,f)}switch(u){case"input":Kl(l,o);break;case"textarea":Hu(l,o);break;case"select":var p=l._wrapperState.wasMultiple;l._wrapperState.wasMultiple=!!o.multiple;var w=o.value;w!=null?Yt(l,!!o.multiple,w,!1):p!==!!o.multiple&&(o.defaultValue!=null?Yt(l,!!o.multiple,o.defaultValue,!0):Yt(l,!!o.multiple,o.multiple?[]:"",!1))}l[Un]=o}catch(S){H(e,e.return,S)}}break;case 6:if(Re(t,e),$e(e),r&4){if(e.stateNode===null)throw Error(g(162));l=e.stateNode,o=e.memoizedProps;try{l.nodeValue=o}catch(S){H(e,e.return,S)}}break;case 3:if(Re(t,e),$e(e),r&4&&n!==null&&n.memoizedState.isDehydrated)try{Dn(t.containerInfo)}catch(S){H(e,e.return,S)}break;case 4:Re(t,e),$e(e);break;case 13:Re(t,e),$e(e),l=e.child,l.flags&8192&&(o=l.memoizedState!==null,l.stateNode.isHidden=o,!o||l.alternate!==null&&l.alternate.memoizedState!==null||(mi=Y())),r&4&&Su(e);break;case 22:if(h=n!==null&&n.memoizedState!==null,e.mode&1?(le=(f=le)||h,Re(t,e),le=f):Re(t,e),$e(e),r&8192){if(f=e.memoizedState!==null,(e.stateNode.isHidden=f)&&!h&&e.mode&1)for(x=e,h=e.child;h!==null;){for(m=x=h;x!==null;){switch(p=x,w=p.child,p.tag){case 0:case 11:case 14:case 15:Nn(4,p,p.return);break;case 1:Ht(p,p.return);var E=p.stateNode;if(typeof E.componentWillUnmount=="function"){r=p,n=p.return;try{t=r,E.props=t.memoizedProps,E.state=t.memoizedState,E.componentWillUnmount()}catch(S){H(r,n,S)}}break;case 5:Ht(p,p.return);break;case 22:if(p.memoizedState!==null){_u(m);continue}}w!==null?(w.return=p,x=w):_u(m)}h=h.sibling}e:for(h=null,m=e;;){if(m.tag===5){if(h===null){h=m;try{l=m.stateNode,f?(o=l.style,typeof o.setProperty=="function"?o.setProperty("display","none","important"):o.display="none"):(u=m.stateNode,s=m.memoizedProps.style,i=s!=null&&s.hasOwnProperty("display")?s.display:null,u.style.display=Ku("display",i))}catch(S){H(e,e.return,S)}}}else if(m.tag===6){if(h===null)try{m.stateNode.nodeValue=f?"":m.memoizedProps}catch(S){H(e,e.return,S)}}else if((m.tag!==22&&m.tag!==23||m.memoizedState===null||m===e)&&m.child!==null){m.child.return=m,m=m.child;continue}if(m===e)break e;for(;m.sibling===null;){if(m.return===null||m.return===e)break e;h===m&&(h=null),m=m.return}h===m&&(h=null),m.sibling.return=m.return,m=m.sibling}}break;case 19:Re(t,e),$e(e),r&4&&Su(e);break;case 21:break;default:Re(t,e),$e(e)}}function $e(e){var t=e.flags;if(t&2){try{e:{for(var n=e.return;n!==null;){if(ya(n)){var r=n;break e}n=n.return}throw Error(g(160))}switch(r.tag){case 5:var l=r.stateNode;r.flags&32&&(Pn(l,""),r.flags&=-33);var o=Eu(e);Ro(e,o,l);break;case 3:case 4:var i=r.stateNode.containerInfo,u=Eu(e);Ao(e,u,i);break;default:throw Error(g(161))}}catch(s){H(e,e.return,s)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function Pd(e,t,n){x=e,Sa(e)}function Sa(e,t,n){for(var r=(e.mode&1)!==0;x!==null;){var l=x,o=l.child;if(l.tag===22&&r){var i=l.memoizedState!==null||fr;if(!i){var u=l.alternate,s=u!==null&&u.memoizedState!==null||le;u=fr;var f=le;if(fr=i,(le=s)&&!f)for(x=l;x!==null;)i=x,s=i.child,i.tag===22&&i.memoizedState!==null?xu(l):s!==null?(s.return=i,x=s):xu(l);for(;o!==null;)x=o,Sa(o),o=o.sibling;x=l,fr=u,le=f}ku(e)}else l.subtreeFlags&8772&&o!==null?(o.return=l,x=o):ku(e)}}function ku(e){for(;x!==null;){var t=x;if(t.flags&8772){var n=t.alternate;try{if(t.flags&8772)switch(t.tag){case 0:case 11:case 15:le||ll(5,t);break;case 1:var r=t.stateNode;if(t.flags&4&&!le)if(n===null)r.componentDidMount();else{var l=t.elementType===t.type?n.memoizedProps:Te(t.type,n.memoizedProps);r.componentDidUpdate(l,n.memoizedState,r.__reactInternalSnapshotBeforeUpdate)}var o=t.updateQueue;o!==null&&iu(t,o,r);break;case 3:var i=t.updateQueue;if(i!==null){if(n=null,t.child!==null)switch(t.child.tag){case 5:n=t.child.stateNode;break;case 1:n=t.child.stateNode}iu(t,i,n)}break;case 5:var u=t.stateNode;if(n===null&&t.flags&4){n=u;var s=t.memoizedProps;switch(t.type){case"button":case"input":case"select":case"textarea":s.autoFocus&&n.focus();break;case"img":s.src&&(n.src=s.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(t.memoizedState===null){var f=t.alternate;if(f!==null){var h=f.memoizedState;if(h!==null){var m=h.dehydrated;m!==null&&Dn(m)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(g(163))}le||t.flags&512&&No(t)}catch(p){H(t,t.return,p)}}if(t===e){x=null;break}if(n=t.sibling,n!==null){n.return=t.return,x=n;break}x=t.return}}function _u(e){for(;x!==null;){var t=x;if(t===e){x=null;break}var n=t.sibling;if(n!==null){n.return=t.return,x=n;break}x=t.return}}function xu(e){for(;x!==null;){var t=x;try{switch(t.tag){case 0:case 11:case 15:var n=t.return;try{ll(4,t)}catch(s){H(t,n,s)}break;case 1:var r=t.stateNode;if(typeof r.componentDidMount=="function"){var l=t.return;try{r.componentDidMount()}catch(s){H(t,l,s)}}var o=t.return;try{No(t)}catch(s){H(t,o,s)}break;case 5:var i=t.return;try{No(t)}catch(s){H(t,i,s)}}}catch(s){H(t,t.return,s)}if(t===e){x=null;break}var u=t.sibling;if(u!==null){u.return=t.return,x=u;break}x=t.return}}var zd=Math.ceil,Gr=Ze.ReactCurrentDispatcher,fi=Ze.ReactCurrentOwner,xe=Ze.ReactCurrentBatchConfig,I=0,q=null,K=null,ee=0,he=0,Gt=mt(0),Z=0,Yn=null,Rt=0,ol=0,pi=0,An=null,ce=null,mi=0,ln=1/0,We=null,Yr=!1,To=null,st=null,pr=!1,nt=null,Kr=0,Rn=0,Po=null,kr=-1,_r=0;function se(){return I&6?Y():kr!==-1?kr:kr=Y()}function at(e){return e.mode&1?I&2&&ee!==0?ee&-ee:md.transition!==null?(_r===0&&(_r=os()),_r):(e=j,e!==0||(e=window.event,e=e===void 0?16:fs(e.type)),e):1}function je(e,t,n,r){if(50<Rn)throw Rn=0,Po=null,Error(g(185));Kn(e,n,r),(!(I&2)||e!==q)&&(e===q&&(!(I&2)&&(ol|=n),Z===4&&et(e,ee)),me(e,r),n===1&&I===0&&!(t.mode&1)&&(ln=Y()+500,tl&&ht()))}function me(e,t){var n=e.callbackNode;mc(e,t);var r=Tr(e,e===q?ee:0);if(r===0)n!==null&&ji(n),e.callbackNode=null,e.callbackPriority=0;else if(t=r&-r,e.callbackPriority!==t){if(n!=null&&ji(n),t===1)e.tag===0?pd(Cu.bind(null,e)):zs(Cu.bind(null,e)),ad(function(){!(I&6)&&ht()}),n=null;else{switch(is(r)){case 1:n=Wo;break;case 4:n=rs;break;case 16:n=Rr;break;case 536870912:n=ls;break;default:n=Rr}n=Ta(n,ka.bind(null,e))}e.callbackPriority=t,e.callbackNode=n}}function ka(e,t){if(kr=-1,_r=0,I&6)throw Error(g(327));var n=e.callbackNode;if(Xt()&&e.callbackNode!==n)return null;var r=Tr(e,e===q?ee:0);if(r===0)return null;if(r&30||r&e.expiredLanes||t)t=Vr(e,r);else{t=r;var l=I;I|=2;var o=xa();(q!==e||ee!==t)&&(We=null,ln=Y()+500,_t(e,t));do try{Dd();break}catch(u){_a(e,u)}while(!0);bo(),Gr.current=o,I=l,K!==null?t=0:(q=null,ee=0,t=Z)}if(t!==0){if(t===2&&(l=no(e),l!==0&&(r=l,t=zo(e,l))),t===1)throw n=Yn,_t(e,0),et(e,r),me(e,Y()),n;if(t===6)et(e,r);else{if(l=e.current.alternate,!(r&30)&&!Id(l)&&(t=Vr(e,r),t===2&&(o=no(e),o!==0&&(r=o,t=zo(e,o))),t===1))throw n=Yn,_t(e,0),et(e,r),me(e,Y()),n;switch(e.finishedWork=l,e.finishedLanes=r,t){case 0:case 1:throw Error(g(345));case 2:wt(e,ce,We);break;case 3:if(et(e,r),(r&130023424)===r&&(t=mi+500-Y(),10<t)){if(Tr(e,0)!==0)break;if(l=e.suspendedLanes,(l&r)!==r){se(),e.pingedLanes|=e.suspendedLanes&l;break}e.timeoutHandle=co(wt.bind(null,e,ce,We),t);break}wt(e,ce,We);break;case 4:if(et(e,r),(r&4194240)===r)break;for(t=e.eventTimes,l=-1;0<r;){var i=31-Ie(r);o=1<<i,i=t[i],i>l&&(l=i),r&=~o}if(r=l,r=Y()-r,r=(120>r?120:480>r?480:1080>r?1080:1920>r?1920:3e3>r?3e3:4320>r?4320:1960*zd(r/1960))-r,10<r){e.timeoutHandle=co(wt.bind(null,e,ce,We),r);break}wt(e,ce,We);break;case 5:wt(e,ce,We);break;default:throw Error(g(329))}}}return me(e,Y()),e.callbackNode===n?ka.bind(null,e):null}function zo(e,t){var n=An;return e.current.memoizedState.isDehydrated&&(_t(e,t).flags|=256),e=Vr(e,t),e!==2&&(t=ce,ce=n,t!==null&&Io(t)),e}function Io(e){ce===null?ce=e:ce.push.apply(ce,e)}function Id(e){for(var t=e;;){if(t.flags&16384){var n=t.updateQueue;if(n!==null&&(n=n.stores,n!==null))for(var r=0;r<n.length;r++){var l=n[r],o=l.getSnapshot;l=l.value;try{if(!De(o(),l))return!1}catch{return!1}}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function et(e,t){for(t&=~pi,t&=~ol,e.suspendedLanes|=t,e.pingedLanes&=~t,e=e.expirationTimes;0<t;){var n=31-Ie(t),r=1<<n;e[n]=-1,t&=~r}}function Cu(e){if(I&6)throw Error(g(327));Xt();var t=Tr(e,0);if(!(t&1))return me(e,Y()),null;var n=Vr(e,t);if(e.tag!==0&&n===2){var r=no(e);r!==0&&(t=r,n=zo(e,r))}if(n===1)throw n=Yn,_t(e,0),et(e,t),me(e,Y()),n;if(n===6)throw Error(g(345));return e.finishedWork=e.current.alternate,e.finishedLanes=t,wt(e,ce,We),me(e,Y()),null}function hi(e,t){var n=I;I|=1;try{return e(t)}finally{I=n,I===0&&(ln=Y()+500,tl&&ht())}}function Tt(e){nt!==null&&nt.tag===0&&!(I&6)&&Xt();var t=I;I|=1;var n=xe.transition,r=j;try{if(xe.transition=null,j=1,e)return e()}finally{j=r,xe.transition=n,I=t,!(I&6)&&ht()}}function vi(){he=Gt.current,L(Gt)}function _t(e,t){e.finishedWork=null,e.finishedLanes=0;var n=e.timeoutHandle;if(n!==-1&&(e.timeoutHandle=-1,sd(n)),K!==null)for(n=K.return;n!==null;){var r=n;switch(Xo(r),r.tag){case 1:r=r.type.childContextTypes,r!=null&&Dr();break;case 3:nn(),L(fe),L(oe),oi();break;case 5:li(r);break;case 4:nn();break;case 13:L(W);break;case 19:L(W);break;case 10:ei(r.type._context);break;case 22:case 23:vi()}n=n.return}if(q=e,K=e=ct(e.current,null),ee=he=t,Z=0,Yn=null,pi=ol=Rt=0,ce=An=null,St!==null){for(t=0;t<St.length;t++)if(n=St[t],r=n.interleaved,r!==null){n.interleaved=null;var l=r.next,o=n.pending;if(o!==null){var i=o.next;o.next=l,r.next=i}n.pending=r}St=null}return e}function _a(e,t){do{var n=K;try{if(bo(),wr.current=Hr,Br){for(var r=F.memoizedState;r!==null;){var l=r.queue;l!==null&&(l.pending=null),r=r.next}Br=!1}if(At=0,J=Q=F=null,Cn=!1,Bn=0,fi.current=null,n===null||n.return===null){Z=1,Yn=t,K=null;break}e:{var o=e,i=n.return,u=n,s=t;if(t=ee,u.flags|=32768,s!==null&&typeof s=="object"&&typeof s.then=="function"){var f=s,h=u,m=h.tag;if(!(h.mode&1)&&(m===0||m===11||m===15)){var p=h.alternate;p?(h.updateQueue=p.updateQueue,h.memoizedState=p.memoizedState,h.lanes=p.lanes):(h.updateQueue=null,h.memoizedState=null)}var w=fu(i);if(w!==null){w.flags&=-257,pu(w,i,u,o,t),w.mode&1&&du(o,f,t),t=w,s=f;var E=t.updateQueue;if(E===null){var S=new Set;S.add(s),t.updateQueue=S}else E.add(s);break e}else{if(!(t&1)){du(o,f,t),gi();break e}s=Error(g(426))}}else if(M&&u.mode&1){var D=fu(i);if(D!==null){!(D.flags&65536)&&(D.flags|=256),pu(D,i,u,o,t),Jo(rn(s,u));break e}}o=s=rn(s,u),Z!==4&&(Z=2),An===null?An=[o]:An.push(o),o=i;do{switch(o.tag){case 3:o.flags|=65536,t&=-t,o.lanes|=t;var c=ia(o,s,t);ou(o,c);break e;case 1:u=s;var a=o.type,d=o.stateNode;if(!(o.flags&128)&&(typeof a.getDerivedStateFromError=="function"||d!==null&&typeof d.componentDidCatch=="function"&&(st===null||!st.has(d)))){o.flags|=65536,t&=-t,o.lanes|=t;var v=ua(o,u,t);ou(o,v);break e}}o=o.return}while(o!==null)}Na(n)}catch(_){t=_,K===n&&n!==null&&(K=n=n.return);continue}break}while(!0)}function xa(){var e=Gr.current;return Gr.current=Hr,e===null?Hr:e}function gi(){(Z===0||Z===3||Z===2)&&(Z=4),q===null||!(Rt&268435455)&&!(ol&268435455)||et(q,ee)}function Vr(e,t){var n=I;I|=2;var r=xa();(q!==e||ee!==t)&&(We=null,_t(e,t));do try{jd();break}catch(l){_a(e,l)}while(!0);if(bo(),I=n,Gr.current=r,K!==null)throw Error(g(261));return q=null,ee=0,Z}function jd(){for(;K!==null;)Ca(K)}function Dd(){for(;K!==null&&!oc();)Ca(K)}function Ca(e){var t=Ra(e.alternate,e,he);e.memoizedProps=e.pendingProps,t===null?Na(e):K=t,fi.current=null}function Na(e){var t=e;do{var n=t.alternate;if(e=t.return,t.flags&32768){if(n=Ad(n,t),n!==null){n.flags&=32767,K=n;return}if(e!==null)e.flags|=32768,e.subtreeFlags=0,e.deletions=null;else{Z=6,K=null;return}}else if(n=Nd(n,t,he),n!==null){K=n;return}if(t=t.sibling,t!==null){K=t;return}K=t=e}while(t!==null);Z===0&&(Z=5)}function wt(e,t,n){var r=j,l=xe.transition;try{xe.transition=null,j=1,$d(e,t,n,r)}finally{xe.transition=l,j=r}return null}function $d(e,t,n,r){do Xt();while(nt!==null);if(I&6)throw Error(g(327));n=e.finishedWork;var l=e.finishedLanes;if(n===null)return null;if(e.finishedWork=null,e.finishedLanes=0,n===e.current)throw Error(g(177));e.callbackNode=null,e.callbackPriority=0;var o=n.lanes|n.childLanes;if(hc(e,o),e===q&&(K=q=null,ee=0),!(n.subtreeFlags&2064)&&!(n.flags&2064)||pr||(pr=!0,Ta(Rr,function(){return Xt(),null})),o=(n.flags&15990)!==0,n.subtreeFlags&15990||o){o=xe.transition,xe.transition=null;var i=j;j=1;var u=I;I|=4,fi.current=null,Td(e,n),Ea(n,e),td(so),Pr=!!uo,so=uo=null,e.current=n,Pd(n),ic(),I=u,j=i,xe.transition=o}else e.current=n;if(pr&&(pr=!1,nt=e,Kr=l),o=e.pendingLanes,o===0&&(st=null),ac(n.stateNode),me(e,Y()),t!==null)for(r=e.onRecoverableError,n=0;n<t.length;n++)l=t[n],r(l.value,{componentStack:l.stack,digest:l.digest});if(Yr)throw Yr=!1,e=To,To=null,e;return Kr&1&&e.tag!==0&&Xt(),o=e.pendingLanes,o&1?e===Po?Rn++:(Rn=0,Po=e):Rn=0,ht(),null}function Xt(){if(nt!==null){var e=is(Kr),t=xe.transition,n=j;try{if(xe.transition=null,j=16>e?16:e,nt===null)var r=!1;else{if(e=nt,nt=null,Kr=0,I&6)throw Error(g(331));var l=I;for(I|=4,x=e.current;x!==null;){var o=x,i=o.child;if(x.flags&16){var u=o.deletions;if(u!==null){for(var s=0;s<u.length;s++){var f=u[s];for(x=f;x!==null;){var h=x;switch(h.tag){case 0:case 11:case 15:Nn(8,h,o)}var m=h.child;if(m!==null)m.return=h,x=m;else for(;x!==null;){h=x;var p=h.sibling,w=h.return;if(ga(h),h===f){x=null;break}if(p!==null){p.return=w,x=p;break}x=w}}}var E=o.alternate;if(E!==null){var S=E.child;if(S!==null){E.child=null;do{var D=S.sibling;S.sibling=null,S=D}while(S!==null)}}x=o}}if(o.subtreeFlags&2064&&i!==null)i.return=o,x=i;else e:for(;x!==null;){if(o=x,o.flags&2048)switch(o.tag){case 0:case 11:case 15:Nn(9,o,o.return)}var c=o.sibling;if(c!==null){c.return=o.return,x=c;break e}x=o.return}}var a=e.current;for(x=a;x!==null;){i=x;var d=i.child;if(i.subtreeFlags&2064&&d!==null)d.return=i,x=d;else e:for(i=a;x!==null;){if(u=x,u.flags&2048)try{switch(u.tag){case 0:case 11:case 15:ll(9,u)}}catch(_){H(u,u.return,_)}if(u===i){x=null;break e}var v=u.sibling;if(v!==null){v.return=u.return,x=v;break e}x=u.return}}if(I=l,ht(),Me&&typeof Me.onPostCommitFiberRoot=="function")try{Me.onPostCommitFiberRoot(Xr,e)}catch{}r=!0}return r}finally{j=n,xe.transition=t}}return!1}function Nu(e,t,n){t=rn(n,t),t=ia(e,t,1),e=ut(e,t,1),t=se(),e!==null&&(Kn(e,1,t),me(e,t))}function H(e,t,n){if(e.tag===3)Nu(e,e,n);else for(;t!==null;){if(t.tag===3){Nu(t,e,n);break}else if(t.tag===1){var r=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof r.componentDidCatch=="function"&&(st===null||!st.has(r))){e=rn(n,e),e=ua(t,e,1),t=ut(t,e,1),e=se(),t!==null&&(Kn(t,1,e),me(t,e));break}}t=t.return}}function Od(e,t,n){var r=e.pingCache;r!==null&&r.delete(t),t=se(),e.pingedLanes|=e.suspendedLanes&n,q===e&&(ee&n)===n&&(Z===4||Z===3&&(ee&130023424)===ee&&500>Y()-mi?_t(e,0):pi|=n),me(e,t)}function Aa(e,t){t===0&&(e.mode&1?(t=rr,rr<<=1,!(rr&130023424)&&(rr=4194304)):t=1);var n=se();e=Ve(e,t),e!==null&&(Kn(e,t,n),me(e,n))}function Ld(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),Aa(e,n)}function Md(e,t){var n=0;switch(e.tag){case 13:var r=e.stateNode,l=e.memoizedState;l!==null&&(n=l.retryLane);break;case 19:r=e.stateNode;break;default:throw Error(g(314))}r!==null&&r.delete(t),Aa(e,n)}var Ra;Ra=function(e,t,n){if(e!==null)if(e.memoizedProps!==t.pendingProps||fe.current)de=!0;else{if(!(e.lanes&n)&&!(t.flags&128))return de=!1,Cd(e,t,n);de=!!(e.flags&131072)}else de=!1,M&&t.flags&1048576&&Is(t,Lr,t.index);switch(t.lanes=0,t.tag){case 2:var r=t.type;Sr(e,t),e=t.pendingProps;var l=bt(t,oe.current);Zt(t,n),l=ui(null,t,r,e,l,n);var o=si();return t.flags|=1,typeof l=="object"&&l!==null&&typeof l.render=="function"&&l.$$typeof===void 0?(t.tag=1,t.memoizedState=null,t.updateQueue=null,pe(r)?(o=!0,$r(t)):o=!1,t.memoizedState=l.state!==null&&l.state!==void 0?l.state:null,ni(t),l.updater=rl,t.stateNode=l,l._reactInternals=t,yo(t,r,e,n),t=So(null,t,r,!0,o,n)):(t.tag=0,M&&o&&Zo(t),ue(null,t,l,n),t=t.child),t;case 16:r=t.elementType;e:{switch(Sr(e,t),e=t.pendingProps,l=r._init,r=l(r._payload),t.type=r,l=t.tag=Wd(r),e=Te(r,e),l){case 0:t=Eo(null,t,r,e,n);break e;case 1:t=vu(null,t,r,e,n);break e;case 11:t=mu(null,t,r,e,n);break e;case 14:t=hu(null,t,r,Te(r.type,e),n);break e}throw Error(g(306,r,""))}return t;case 0:return r=t.type,l=t.pendingProps,l=t.elementType===r?l:Te(r,l),Eo(e,t,r,l,n);case 1:return r=t.type,l=t.pendingProps,l=t.elementType===r?l:Te(r,l),vu(e,t,r,l,n);case 3:e:{if(da(t),e===null)throw Error(g(387));r=t.pendingProps,o=t.memoizedState,l=o.element,Ms(e,t),Wr(t,r,null,n);var i=t.memoizedState;if(r=i.element,o.isDehydrated)if(o={element:r,isDehydrated:!1,cache:i.cache,pendingSuspenseBoundaries:i.pendingSuspenseBoundaries,transitions:i.transitions},t.updateQueue.baseState=o,t.memoizedState=o,t.flags&256){l=rn(Error(g(423)),t),t=gu(e,t,r,n,l);break e}else if(r!==l){l=rn(Error(g(424)),t),t=gu(e,t,r,n,l);break e}else for(ve=it(t.stateNode.containerInfo.firstChild),ge=t,M=!0,ze=null,n=Os(t,null,r,n),t.child=n;n;)n.flags=n.flags&-3|4096,n=n.sibling;else{if(en(),r===l){t=Qe(e,t,n);break e}ue(e,t,r,n)}t=t.child}return t;case 5:return Us(t),e===null&&ho(t),r=t.type,l=t.pendingProps,o=e!==null?e.memoizedProps:null,i=l.children,ao(r,l)?i=null:o!==null&&ao(r,o)&&(t.flags|=32),ca(e,t),ue(e,t,i,n),t.child;case 6:return e===null&&ho(t),null;case 13:return fa(e,t,n);case 4:return ri(t,t.stateNode.containerInfo),r=t.pendingProps,e===null?t.child=tn(t,null,r,n):ue(e,t,r,n),t.child;case 11:return r=t.type,l=t.pendingProps,l=t.elementType===r?l:Te(r,l),mu(e,t,r,l,n);case 7:return ue(e,t,t.pendingProps,n),t.child;case 8:return ue(e,t,t.pendingProps.children,n),t.child;case 12:return ue(e,t,t.pendingProps.children,n),t.child;case 10:e:{if(r=t.type._context,l=t.pendingProps,o=t.memoizedProps,i=l.value,$(Mr,r._currentValue),r._currentValue=i,o!==null)if(De(o.value,i)){if(o.children===l.children&&!fe.current){t=Qe(e,t,n);break e}}else for(o=t.child,o!==null&&(o.return=t);o!==null;){var u=o.dependencies;if(u!==null){i=o.child;for(var s=u.firstContext;s!==null;){if(s.context===r){if(o.tag===1){s=Ge(-1,n&-n),s.tag=2;var f=o.updateQueue;if(f!==null){f=f.shared;var h=f.pending;h===null?s.next=s:(s.next=h.next,h.next=s),f.pending=s}}o.lanes|=n,s=o.alternate,s!==null&&(s.lanes|=n),vo(o.return,n,t),u.lanes|=n;break}s=s.next}}else if(o.tag===10)i=o.type===t.type?null:o.child;else if(o.tag===18){if(i=o.return,i===null)throw Error(g(341));i.lanes|=n,u=i.alternate,u!==null&&(u.lanes|=n),vo(i,n,t),i=o.sibling}else i=o.child;if(i!==null)i.return=o;else for(i=o;i!==null;){if(i===t){i=null;break}if(o=i.sibling,o!==null){o.return=i.return,i=o;break}i=i.return}o=i}ue(e,t,l.children,n),t=t.child}return t;case 9:return l=t.type,r=t.pendingProps.children,Zt(t,n),l=Ce(l),r=r(l),t.flags|=1,ue(e,t,r,n),t.child;case 14:return r=t.type,l=Te(r,t.pendingProps),l=Te(r.type,l),hu(e,t,r,l,n);case 15:return sa(e,t,t.type,t.pendingProps,n);case 17:return r=t.type,l=t.pendingProps,l=t.elementType===r?l:Te(r,l),Sr(e,t),t.tag=1,pe(r)?(e=!0,$r(t)):e=!1,Zt(t,n),oa(t,r,l),yo(t,r,l,n),So(null,t,r,!0,e,n);case 19:return pa(e,t,n);case 22:return aa(e,t,n)}throw Error(g(156,t.tag))};function Ta(e,t){return ns(e,t)}function Ud(e,t,n,r){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function _e(e,t,n,r){return new Ud(e,t,n,r)}function yi(e){return e=e.prototype,!(!e||!e.isReactComponent)}function Wd(e){if(typeof e=="function")return yi(e)?1:0;if(e!=null){if(e=e.$$typeof,e===Lo)return 11;if(e===Mo)return 14}return 2}function ct(e,t){var n=e.alternate;return n===null?(n=_e(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&14680064,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n}function xr(e,t,n,r,l,o){var i=2;if(r=e,typeof e=="function")yi(e)&&(i=1);else if(typeof e=="string")i=5;else e:switch(e){case Dt:return xt(n.children,l,o,t);case Oo:i=8,l|=8;break;case Fl:return e=_e(12,n,t,l|2),e.elementType=Fl,e.lanes=o,e;case Bl:return e=_e(13,n,t,l),e.elementType=Bl,e.lanes=o,e;case Hl:return e=_e(19,n,t,l),e.elementType=Hl,e.lanes=o,e;case Uu:return il(n,l,o,t);default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case Lu:i=10;break e;case Mu:i=9;break e;case Lo:i=11;break e;case Mo:i=14;break e;case Je:i=16,r=null;break e}throw Error(g(130,e==null?e:typeof e,""))}return t=_e(i,n,t,l),t.elementType=e,t.type=r,t.lanes=o,t}function xt(e,t,n,r){return e=_e(7,e,r,t),e.lanes=n,e}function il(e,t,n,r){return e=_e(22,e,r,t),e.elementType=Uu,e.lanes=n,e.stateNode={isHidden:!1},e}function Ll(e,t,n){return e=_e(6,e,null,t),e.lanes=n,e}function Ml(e,t,n){return t=_e(4,e.children!==null?e.children:[],e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}function Fd(e,t,n,r,l){this.tag=t,this.containerInfo=e,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=yl(0),this.expirationTimes=yl(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=yl(0),this.identifierPrefix=r,this.onRecoverableError=l,this.mutableSourceEagerHydrationData=null}function wi(e,t,n,r,l,o,i,u,s){return e=new Fd(e,t,n,u,s),t===1?(t=1,o===!0&&(t|=8)):t=0,o=_e(3,null,null,t),e.current=o,o.stateNode=e,o.memoizedState={element:r,isDehydrated:n,cache:null,transitions:null,pendingSuspenseBoundaries:null},ni(o),e}function Bd(e,t,n){var r=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:jt,key:r==null?null:""+r,children:e,containerInfo:t,implementation:n}}function Pa(e){if(!e)return ft;e=e._reactInternals;e:{if(zt(e)!==e||e.tag!==1)throw Error(g(170));var t=e;do{switch(t.tag){case 3:t=t.stateNode.context;break e;case 1:if(pe(t.type)){t=t.stateNode.__reactInternalMemoizedMergedChildContext;break e}}t=t.return}while(t!==null);throw Error(g(171))}if(e.tag===1){var n=e.type;if(pe(n))return Ps(e,n,t)}return t}function za(e,t,n,r,l,o,i,u,s){return e=wi(n,r,!0,e,l,o,i,u,s),e.context=Pa(null),n=e.current,r=se(),l=at(n),o=Ge(r,l),o.callback=t??null,ut(n,o,l),e.current.lanes=l,Kn(e,l,r),me(e,r),e}function ul(e,t,n,r){var l=t.current,o=se(),i=at(l);return n=Pa(n),t.context===null?t.context=n:t.pendingContext=n,t=Ge(o,i),t.payload={element:e},r=r===void 0?null:r,r!==null&&(t.callback=r),e=ut(l,t,i),e!==null&&(je(e,l,i,o),yr(e,l,i)),i}function Qr(e){if(e=e.current,!e.child)return null;switch(e.child.tag){case 5:return e.child.stateNode;default:return e.child.stateNode}}function Au(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function Ei(e,t){Au(e,t),(e=e.alternate)&&Au(e,t)}function Hd(){return null}var Ia=typeof reportError=="function"?reportError:function(e){console.error(e)};function Si(e){this._internalRoot=e}sl.prototype.render=Si.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(g(409));ul(e,t,null,null)};sl.prototype.unmount=Si.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;Tt(function(){ul(null,e,null,null)}),t[Ke]=null}};function sl(e){this._internalRoot=e}sl.prototype.unstable_scheduleHydration=function(e){if(e){var t=as();e={blockedOn:null,target:e,priority:t};for(var n=0;n<be.length&&t!==0&&t<be[n].priority;n++);be.splice(n,0,e),n===0&&ds(e)}};function ki(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function al(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11&&(e.nodeType!==8||e.nodeValue!==" react-mount-point-unstable "))}function Ru(){}function Gd(e,t,n,r,l){if(l){if(typeof r=="function"){var o=r;r=function(){var f=Qr(i);o.call(f)}}var i=za(t,r,e,0,null,!1,!1,"",Ru);return e._reactRootContainer=i,e[Ke]=i.current,Ln(e.nodeType===8?e.parentNode:e),Tt(),i}for(;l=e.lastChild;)e.removeChild(l);if(typeof r=="function"){var u=r;r=function(){var f=Qr(s);u.call(f)}}var s=wi(e,0,!1,null,null,!1,!1,"",Ru);return e._reactRootContainer=s,e[Ke]=s.current,Ln(e.nodeType===8?e.parentNode:e),Tt(function(){ul(t,s,n,r)}),s}function cl(e,t,n,r,l){var o=n._reactRootContainer;if(o){var i=o;if(typeof l=="function"){var u=l;l=function(){var s=Qr(i);u.call(s)}}ul(t,i,e,l)}else i=Gd(n,t,e,l,r);return Qr(i)}us=function(e){switch(e.tag){case 3:var t=e.stateNode;if(t.current.memoizedState.isDehydrated){var n=yn(t.pendingLanes);n!==0&&(Fo(t,n|1),me(t,Y()),!(I&6)&&(ln=Y()+500,ht()))}break;case 13:Tt(function(){var r=Ve(e,1);if(r!==null){var l=se();je(r,e,1,l)}}),Ei(e,1)}};Bo=function(e){if(e.tag===13){var t=Ve(e,134217728);if(t!==null){var n=se();je(t,e,134217728,n)}Ei(e,134217728)}};ss=function(e){if(e.tag===13){var t=at(e),n=Ve(e,t);if(n!==null){var r=se();je(n,e,t,r)}Ei(e,t)}};as=function(){return j};cs=function(e,t){var n=j;try{return j=e,t()}finally{j=n}};bl=function(e,t,n){switch(t){case"input":if(Kl(e,n),t=n.name,n.type==="radio"&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll("input[name="+JSON.stringify(""+t)+'][type="radio"]'),t=0;t<n.length;t++){var r=n[t];if(r!==e&&r.form===e.form){var l=el(r);if(!l)throw Error(g(90));Fu(r),Kl(r,l)}}}break;case"textarea":Hu(e,n);break;case"select":t=n.value,t!=null&&Yt(e,!!n.multiple,t,!1)}};Xu=hi;Ju=Tt;var Yd={usingClientEntryPoint:!1,Events:[Qn,Mt,el,Qu,Zu,hi]},hn={findFiberByHostInstance:Et,bundleType:0,version:"18.3.1",rendererPackageName:"react-dom"},Kd={bundleType:hn.bundleType,version:hn.version,rendererPackageName:hn.rendererPackageName,rendererConfig:hn.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:Ze.ReactCurrentDispatcher,findHostInstanceByFiber:function(e){return e=es(e),e===null?null:e.stateNode},findFiberByHostInstance:hn.findFiberByHostInstance||Hd,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.3.1-next-f1338f8080-20240426"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var mr=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!mr.isDisabled&&mr.supportsFiber)try{Xr=mr.inject(Kd),Me=mr}catch{}}we.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=Yd;we.createPortal=function(e,t){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!ki(t))throw Error(g(200));return Bd(e,t,null,n)};we.createRoot=function(e,t){if(!ki(e))throw Error(g(299));var n=!1,r="",l=Ia;return t!=null&&(t.unstable_strictMode===!0&&(n=!0),t.identifierPrefix!==void 0&&(r=t.identifierPrefix),t.onRecoverableError!==void 0&&(l=t.onRecoverableError)),t=wi(e,1,!1,null,null,n,!1,r,l),e[Ke]=t.current,Ln(e.nodeType===8?e.parentNode:e),new Si(t)};we.findDOMNode=function(e){if(e==null)return null;if(e.nodeType===1)return e;var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(g(188)):(e=Object.keys(e).join(","),Error(g(268,e)));return e=es(t),e=e===null?null:e.stateNode,e};we.flushSync=function(e){return Tt(e)};we.hydrate=function(e,t,n){if(!al(t))throw Error(g(200));return cl(null,e,t,!0,n)};we.hydrateRoot=function(e,t,n){if(!ki(e))throw Error(g(405));var r=n!=null&&n.hydratedSources||null,l=!1,o="",i=Ia;if(n!=null&&(n.unstable_strictMode===!0&&(l=!0),n.identifierPrefix!==void 0&&(o=n.identifierPrefix),n.onRecoverableError!==void 0&&(i=n.onRecoverableError)),t=za(t,null,e,1,n??null,l,!1,o,i),e[Ke]=t.current,Ln(e),r)for(e=0;e<r.length;e++)n=r[e],l=n._getVersion,l=l(n._source),t.mutableSourceEagerHydrationData==null?t.mutableSourceEagerHydrationData=[n,l]:t.mutableSourceEagerHydrationData.push(n,l);return new sl(t)};we.render=function(e,t,n){if(!al(t))throw Error(g(200));return cl(null,e,t,!1,n)};we.unmountComponentAtNode=function(e){if(!al(e))throw Error(g(40));return e._reactRootContainer?(Tt(function(){cl(null,null,e,!1,function(){e._reactRootContainer=null,e[Ke]=null})}),!0):!1};we.unstable_batchedUpdates=hi;we.unstable_renderSubtreeIntoContainer=function(e,t,n,r){if(!al(n))throw Error(g(200));if(e==null||e._reactInternals===void 0)throw Error(g(38));return cl(e,t,n,!1,r)};we.version="18.3.1-next-f1338f8080-20240426";function ja(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(ja)}catch(e){console.error(e)}}ja(),ju.exports=we;var Vd=ju.exports,Tu=Vd;Ul.createRoot=Tu.createRoot,Ul.hydrateRoot=Tu.hydrateRoot;const Qd={azure:{flask:e=>`name: Deploy Flask to Azure Web App

on:
  push:
    branches: [main]
  workflow_dispatch:

env:
  AZURE_WEBAPP_NAME: 'your-app-name'
  PYTHON_VERSION: '3.10'
  STARTUP_COMMAND: 'gunicorn --bind=0.0.0.0:8000 --timeout 600 --workers 4 app:app'

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      id-token: write
    environment:
      name: 'Production'

    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: \${{ env.PYTHON_VERSION }}${e.cache?`
          cache: 'pip'`:""}
      ${e.cache?`
      - name: Cache dependencies
        uses: actions/cache@v3
        with:
          path: |
            ~/.cache/pip
            ~/.local/lib/python\${{ env.PYTHON_VERSION }}/site-packages
          key: \${{ runner.os }}-pip-\${{ hashFiles('**/requirements.txt') }}`:""}

      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip setuptools wheel
          pip install ${e.optimize?"--prefer-binary ":""}-r requirements.txt
      ${e.tests?`
      - name: Run tests
        run: |
          pip install pytest
          pytest`:""}
      ${e.optimize?`
      - name: Cleanup for production
        run: |
          find . -type d -name "__pycache__" -exec rm -rf {} + 2>/dev/null || true
          find . -type f -name "*.pyc" -delete
          find . -type f -name "*.pyo" -delete`:""}

      - name: Login to Azure
        uses: azure/login@v2
        with:
          client-id: \${{ secrets.AZURE_CLIENT_ID }}
          tenant-id: \${{ secrets.AZURE_TENANT_ID }}
          subscription-id: \${{ secrets.AZURE_SUBSCRIPTION_ID }}

      - name: Configure Azure App Service
        uses: azure/appservice-settings@v1
        with:
          app-name: \${{ env.AZURE_WEBAPP_NAME }}
          mask-inputs: false
          general-settings-json: '{"linuxFxVersion": "PYTHON|\${{ env.PYTHON_VERSION }}"}'

      - name: Deploy to Azure Web App
        uses: azure/webapps-deploy@v3
        with:
          app-name: \${{ env.AZURE_WEBAPP_NAME }}
          package: '.'
          startup-command: \${{ env.STARTUP_COMMAND }}

      - name: Azure Logout
        if: always()
        run: az logout`,django:e=>`name: Deploy Django to Azure Web App

on:
  push:
    branches: [main]
  workflow_dispatch:

env:
  AZURE_WEBAPP_NAME: 'your-app-name'
  PYTHON_VERSION: '3.10'
  STARTUP_COMMAND: 'gunicorn --bind=0.0.0.0:8000 project.wsgi:application'

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      id-token: write

    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: \${{ env.PYTHON_VERSION }}${e.cache?`
          cache: 'pip'`:""}

      - name: Install dependencies
        run: pip install -r requirements.txt
      ${e.tests?`
      - name: Run tests
        run: |
          python manage.py test`:""}
      ${e.optimize?`
      - name: Collect static files
        run: python manage.py collectstatic --noinput

      - name: Run migrations
        run: python manage.py migrate --noinput`:""}

      - name: Login to Azure
        uses: azure/login@v2
        with:
          client-id: \${{ secrets.AZURE_CLIENT_ID }}
          tenant-id: \${{ secrets.AZURE_TENANT_ID }}
          subscription-id: \${{ secrets.AZURE_SUBSCRIPTION_ID }}

      - name: Deploy to Azure
        uses: azure/webapps-deploy@v3
        with:
          app-name: \${{ env.AZURE_WEBAPP_NAME }}
          package: '.'
          startup-command: \${{ env.STARTUP_COMMAND }}`,fastapi:e=>`name: Deploy FastAPI to Azure Web App

on:
  push:
    branches: [main]

env:
  AZURE_WEBAPP_NAME: 'your-app-name'
  PYTHON_VERSION: '3.10'
  STARTUP_COMMAND: 'uvicorn main:app --host 0.0.0.0 --port 8000'

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: \${{ env.PYTHON_VERSION }}${e.cache?`
          cache: 'pip'`:""}

      - name: Install dependencies
        run: pip install -r requirements.txt
      ${e.tests?`
      - name: Run tests
        run: |
          pip install pytest httpx
          pytest`:""}

      - name: Login to Azure
        uses: azure/login@v2
        with:
          client-id: \${{ secrets.AZURE_CLIENT_ID }}
          tenant-id: \${{ secrets.AZURE_TENANT_ID }}
          subscription-id: \${{ secrets.AZURE_SUBSCRIPTION_ID }}

      - name: Deploy to Azure
        uses: azure/webapps-deploy@v3
        with:
          app-name: \${{ env.AZURE_WEBAPP_NAME }}
          package: '.'
          startup-command: \${{ env.STARTUP_COMMAND }}`},aws:{flask:e=>`name: Deploy Flask to AWS Elastic Beanstalk

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.10'

      - name: Install dependencies
        run: pip install -r requirements.txt
      ${e.tests?`
      - name: Run tests
        run: pytest`:""}

      - name: Generate deployment package
        run: zip -r deploy.zip . -x '*.git*'

      - name: Deploy to EB
        uses: einaregilsson/beanstalk-deploy@v21
        with:
          aws_access_key: \${{ secrets.AWS_ACCESS_KEY_ID }}
          aws_secret_key: \${{ secrets.AWS_SECRET_ACCESS_KEY }}
          application_name: your-app
          environment_name: your-app-env
          version_label: \${{ github.sha }}
          region: us-east-1
          deployment_package: deploy.zip`,django:e=>`name: Deploy Django to AWS

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.10'
      - name: Install dependencies
        run: pip install -r requirements.txt
      - name: Generate deployment package
        run: zip -r deploy.zip .
      - name: Deploy to AWS
        uses: einaregilsson/beanstalk-deploy@v21
        with:
          aws_access_key: \${{ secrets.AWS_ACCESS_KEY_ID }}
          aws_secret_key: \${{ secrets.AWS_SECRET_ACCESS_KEY }}
          application_name: your-django-app
          environment_name: your-django-env
          version_label: \${{ github.sha }}
          region: us-east-1
          deployment_package: deploy.zip`,fastapi:e=>`name: Deploy FastAPI to AWS

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.10'
      - name: Install dependencies
        run: pip install -r requirements.txt
      - name: Create deployment package
        run: zip -r deploy.zip .
      - name: Deploy to AWS Lambda
        run: |
          aws lambda update-function-code \\
            --function-name your-fastapi-function \\
            --zip-file fileb://deploy.zip
        env:
          AWS_ACCESS_KEY_ID: \${{ secrets.AWS_ACCESS_KEY_ID }}
          AWS_SECRET_ACCESS_KEY: \${{ secrets.AWS_SECRET_ACCESS_KEY }}
          AWS_DEFAULT_REGION: us-east-1`},heroku:{flask:e=>`name: Deploy Flask to Heroku

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4
      ${e.tests?`
      - name: Set up Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.10'

      - name: Install dependencies
        run: pip install -r requirements.txt

      - name: Run tests
        run: pytest`:""}

      - name: Deploy to Heroku
        uses: akhileshns/heroku-deploy@v3.13.15
        with:
          heroku_api_key: \${{ secrets.HEROKU_API_KEY }}
          heroku_app_name: your-app-name
          heroku_email: your-email@example.com`,django:e=>`name: Deploy Django to Heroku

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Deploy to Heroku
        uses: akhileshns/heroku-deploy@v3.13.15
        with:
          heroku_api_key: \${{ secrets.HEROKU_API_KEY }}
          heroku_app_name: your-django-app
          heroku_email: your-email@example.com`,fastapi:e=>`name: Deploy FastAPI to Heroku

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Deploy to Heroku
        uses: akhileshns/heroku-deploy@v3.13.15
        with:
          heroku_api_key: \${{ secrets.HEROKU_API_KEY }}
          heroku_app_name: your-fastapi-app
          heroku_email: your-email@example.com`}},Zd={azure:{express:e=>`name: Deploy Express.js to Azure Web App

on:
  push:
    branches: [main]
  workflow_dispatch:

env:
  AZURE_WEBAPP_NAME: 'your-app-name'
  NODE_VERSION: '18.x'

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Set up Node.js
        uses: actions/setup-node@v4
        with:
          node-version: \${{ env.NODE_VERSION }}${e.cache?`
          cache: 'npm'`:""}
      ${e.cache?`
      - name: Cache node modules
        uses: actions/cache@v3
        with:
          path: ~/.npm
          key: \${{ runner.os }}-node-\${{ hashFiles('**/package-lock.json') }}`:""}

      - name: Install dependencies
        run: npm ci
      ${e.tests?`
      - name: Run tests
        run: npm test`:""}
      ${e.optimize?`
      - name: Build for production
        run: npm run build --if-present`:""}

      - name: Login to Azure
        uses: azure/login@v2
        with:
          client-id: \${{ secrets.AZURE_CLIENT_ID }}
          tenant-id: \${{ secrets.AZURE_TENANT_ID }}
          subscription-id: \${{ secrets.AZURE_SUBSCRIPTION_ID }}

      - name: Deploy to Azure Web App
        uses: azure/webapps-deploy@v3
        with:
          app-name: \${{ env.AZURE_WEBAPP_NAME }}
          package: .

      - name: Azure Logout
        if: always()
        run: az logout`,nextjs:e=>`name: Deploy Next.js to Azure Static Web Apps

on:
  push:
    branches: [main]
  workflow_dispatch:

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Set up Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '18.x'${e.cache?`
          cache: 'npm'`:""}

      - name: Install dependencies
        run: npm ci

      - name: Build application
        run: npm run build
      ${e.tests?`
      - name: Run tests
        run: npm test`:""}

      - name: Deploy to Azure Static Web Apps
        uses: Azure/static-web-apps-deploy@v1
        with:
          azure_static_web_apps_api_token: \${{ secrets.AZURE_STATIC_WEB_APPS_API_TOKEN }}
          repo_token: \${{ secrets.GITHUB_TOKEN }}
          action: "upload"
          app_location: "/"
          api_location: ""
          output_location: "out"`,react:e=>`name: Deploy React to Azure Static Web Apps

on:
  push:
    branches: [main]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Set up Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '18.x'${e.cache?`
          cache: 'npm'`:""}

      - name: Install and Build
        run: |
          npm ci
          npm run build
      ${e.tests?`
      - name: Run tests
        run: npm test -- --passWithNoTests`:""}

      - name: Deploy to Azure
        uses: Azure/static-web-apps-deploy@v1
        with:
          azure_static_web_apps_api_token: \${{ secrets.AZURE_STATIC_WEB_APPS_API_TOKEN }}
          repo_token: \${{ secrets.GITHUB_TOKEN }}
          action: "upload"
          app_location: "/"
          output_location: "build"`},aws:{express:e=>`name: Deploy Express to AWS Elastic Beanstalk

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Set up Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '18.x'

      - name: Install dependencies
        run: npm ci
      ${e.tests?`
      - name: Run tests
        run: npm test`:""}

      - name: Generate deployment package
        run: zip -r deploy.zip . -x '*.git*' 'node_modules/*'

      - name: Deploy to AWS
        uses: einaregilsson/beanstalk-deploy@v21
        with:
          aws_access_key: \${{ secrets.AWS_ACCESS_KEY_ID }}
          aws_secret_key: \${{ secrets.AWS_SECRET_ACCESS_KEY }}
          application_name: your-express-app
          environment_name: your-express-env
          version_label: \${{ github.sha }}
          region: us-east-1
          deployment_package: deploy.zip`,nextjs:e=>`name: Deploy Next.js to AWS

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Set up Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '18.x'

      - name: Install and build
        run: |
          npm ci
          npm run build
      ${e.tests?`
      - name: Run tests
        run: npm test`:""}

      - name: Deploy to S3
        run: |
          aws s3 sync ./out s3://\${{ secrets.AWS_S3_BUCKET }} --delete
        env:
          AWS_ACCESS_KEY_ID: \${{ secrets.AWS_ACCESS_KEY_ID }}
          AWS_SECRET_ACCESS_KEY: \${{ secrets.AWS_SECRET_ACCESS_KEY }}
          AWS_DEFAULT_REGION: us-east-1`,react:e=>`name: Deploy React to AWS S3

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Set up Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '18.x'

      - name: Install and build
        run: |
          npm ci
          npm run build

      - name: Deploy to S3
        run: aws s3 sync ./build s3://\${{ secrets.AWS_S3_BUCKET }} --delete
        env:
          AWS_ACCESS_KEY_ID: \${{ secrets.AWS_ACCESS_KEY_ID }}
          AWS_SECRET_ACCESS_KEY: \${{ secrets.AWS_SECRET_ACCESS_KEY }}`},heroku:{express:e=>`name: Deploy Express to Heroku

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4
      ${e.tests?`
      - name: Set up Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '18.x'

      - name: Install dependencies
        run: npm ci

      - name: Run tests
        run: npm test`:""}

      - name: Deploy to Heroku
        uses: akhileshns/heroku-deploy@v3.13.15
        with:
          heroku_api_key: \${{ secrets.HEROKU_API_KEY }}
          heroku_app_name: your-express-app
          heroku_email: your-email@example.com`,nextjs:e=>`name: Deploy Next.js to Heroku

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Deploy to Heroku
        uses: akhileshns/heroku-deploy@v3.13.15
        with:
          heroku_api_key: \${{ secrets.HEROKU_API_KEY }}
          heroku_app_name: your-nextjs-app
          heroku_email: your-email@example.com`,react:e=>`name: Deploy React to Heroku

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Deploy to Heroku
        uses: akhileshns/heroku-deploy@v3.13.15
        with:
          heroku_api_key: \${{ secrets.HEROKU_API_KEY }}
          heroku_app_name: your-react-app
          heroku_email: your-email@example.com
          buildpack: https://github.com/mars/create-react-app-buildpack.git`}},Xd={azure:{springboot:e=>`name: Deploy Spring Boot to Azure

on:
  push:
    branches: [main]
  workflow_dispatch:

env:
  AZURE_WEBAPP_NAME: 'your-app-name'
  JAVA_VERSION: '17'

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Set up JDK
        uses: actions/setup-java@v4
        with:
          java-version: \${{ env.JAVA_VERSION }}
          distribution: 'temurin'${e.cache?`
          cache: 'maven'`:""}

      - name: Build with Maven
        run: mvn clean package -DskipTests=${!e.tests}
      ${e.tests?`
      - name: Run tests
        run: mvn test`:""}

      - name: Login to Azure
        uses: azure/login@v2
        with:
          client-id: \${{ secrets.AZURE_CLIENT_ID }}
          tenant-id: \${{ secrets.AZURE_TENANT_ID }}
          subscription-id: \${{ secrets.AZURE_SUBSCRIPTION_ID }}

      - name: Deploy to Azure Web App
        uses: azure/webapps-deploy@v3
        with:
          app-name: \${{ env.AZURE_WEBAPP_NAME }}
          package: '\${{ github.workspace }}/target/*.jar'

      - name: Azure Logout
        if: always()
        run: az logout`,maven:e=>`name: Build and Deploy Java Maven to Azure

on:
  push:
    branches: [main]

env:
  AZURE_WEBAPP_NAME: 'your-app-name'

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'${e.cache?`
          cache: 'maven'`:""}

      - name: Build with Maven
        run: mvn clean install
      ${e.tests?`
      - name: Run tests
        run: mvn test`:""}

      - name: Login to Azure
        uses: azure/login@v2
        with:
          client-id: \${{ secrets.AZURE_CLIENT_ID }}
          tenant-id: \${{ secrets.AZURE_TENANT_ID }}
          subscription-id: \${{ secrets.AZURE_SUBSCRIPTION_ID }}

      - name: Deploy to Azure
        uses: azure/webapps-deploy@v3
        with:
          app-name: \${{ env.AZURE_WEBAPP_NAME }}
          package: target/*.jar`,gradle:e=>`name: Build and Deploy Java Gradle to Azure

on:
  push:
    branches: [main]

env:
  AZURE_WEBAPP_NAME: 'your-app-name'

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'${e.cache?`
          cache: 'gradle'`:""}

      - name: Build with Gradle
        run: ./gradlew build
      ${e.tests?`
      - name: Run tests
        run: ./gradlew test`:""}

      - name: Login to Azure
        uses: azure/login@v2
        with:
          client-id: \${{ secrets.AZURE_CLIENT_ID }}
          tenant-id: \${{ secrets.AZURE_TENANT_ID }}
          subscription-id: \${{ secrets.AZURE_SUBSCRIPTION_ID }}

      - name: Deploy to Azure
        uses: azure/webapps-deploy@v3
        with:
          app-name: \${{ env.AZURE_WEBAPP_NAME }}
          package: build/libs/*.jar`},aws:{springboot:e=>`name: Deploy Spring Boot to AWS

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Build with Maven
        run: mvn clean package
      ${e.tests?`
      - name: Run tests
        run: mvn test`:""}

      - name: Deploy to AWS Elastic Beanstalk
        uses: einaregilsson/beanstalk-deploy@v21
        with:
          aws_access_key: \${{ secrets.AWS_ACCESS_KEY_ID }}
          aws_secret_key: \${{ secrets.AWS_SECRET_ACCESS_KEY }}
          application_name: your-springboot-app
          environment_name: your-springboot-env
          version_label: \${{ github.sha }}
          region: us-east-1
          deployment_package: target/*.jar`,maven:e=>`name: Deploy Java Maven to AWS

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Build with Maven
        run: mvn clean package

      - name: Deploy to AWS
        uses: einaregilsson/beanstalk-deploy@v21
        with:
          aws_access_key: \${{ secrets.AWS_ACCESS_KEY_ID }}
          aws_secret_key: \${{ secrets.AWS_SECRET_ACCESS_KEY }}
          application_name: your-java-app
          environment_name: your-java-env
          version_label: \${{ github.sha }}
          region: us-east-1
          deployment_package: target/*.jar`,gradle:e=>`name: Deploy Java Gradle to AWS

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Build with Gradle
        run: ./gradlew build

      - name: Deploy to AWS
        uses: einaregilsson/beanstalk-deploy@v21
        with:
          aws_access_key: \${{ secrets.AWS_ACCESS_KEY_ID }}
          aws_secret_key: \${{ secrets.AWS_SECRET_ACCESS_KEY }}
          application_name: your-gradle-app
          environment_name: your-gradle-env
          version_label: \${{ github.sha }}
          region: us-east-1
          deployment_package: build/libs/*.jar`},heroku:{springboot:e=>`name: Deploy Spring Boot to Heroku

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Deploy to Heroku
        uses: akhileshns/heroku-deploy@v3.13.15
        with:
          heroku_api_key: \${{ secrets.HEROKU_API_KEY }}
          heroku_app_name: your-springboot-app
          heroku_email: your-email@example.com`,maven:e=>`name: Deploy Java Maven to Heroku

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Deploy to Heroku
        uses: akhileshns/heroku-deploy@v3.13.15
        with:
          heroku_api_key: \${{ secrets.HEROKU_API_KEY }}
          heroku_app_name: your-java-app
          heroku_email: your-email@example.com`,gradle:e=>`name: Deploy Java Gradle to Heroku

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Deploy to Heroku
        uses: akhileshns/heroku-deploy@v3.13.15
        with:
          heroku_api_key: \${{ secrets.HEROKU_API_KEY }}
          heroku_app_name: your-gradle-app
          heroku_email: your-email@example.com`}},Jd={azure:{webapp:e=>`name: Deploy Go to Azure Web App

on:
  push:
    branches: [main]
  workflow_dispatch:

env:
  AZURE_WEBAPP_NAME: 'your-app-name'
  GO_VERSION: '1.21'

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Set up Go
        uses: actions/setup-go@v5
        with:
          go-version: \${{ env.GO_VERSION }}${e.cache?`
          cache: true`:""}

      - name: Build application
        run: |
          go mod download
          go build -o app .
      ${e.tests?`
      - name: Run tests
        run: go test ./...`:""}

      - name: Login to Azure
        uses: azure/login@v2
        with:
          client-id: \${{ secrets.AZURE_CLIENT_ID }}
          tenant-id: \${{ secrets.AZURE_TENANT_ID }}
          subscription-id: \${{ secrets.AZURE_SUBSCRIPTION_ID }}

      - name: Deploy to Azure Web App
        uses: azure/webapps-deploy@v3
        with:
          app-name: \${{ env.AZURE_WEBAPP_NAME }}
          package: .

      - name: Azure Logout
        if: always()
        run: az logout`,containerapp:e=>`name: Deploy Go to Azure Container Apps

on:
  push:
    branches: [main]

env:
  AZURE_CONTAINER_APP_NAME: 'your-app'
  AZURE_RESOURCE_GROUP: 'your-rg'

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Set up Go
        uses: actions/setup-go@v5
        with:
          go-version: '1.21'${e.cache?`
          cache: true`:""}

      - name: Build
        run: |
          go mod download
          go build -o app .
      ${e.tests?`
      - name: Test
        run: go test ./...`:""}

      - name: Login to Azure
        uses: azure/login@v2
        with:
          client-id: \${{ secrets.AZURE_CLIENT_ID }}
          tenant-id: \${{ secrets.AZURE_TENANT_ID }}
          subscription-id: \${{ secrets.AZURE_SUBSCRIPTION_ID }}

      - name: Build and push container
        run: |
          az acr build --registry \${{ secrets.ACR_NAME }} \\
            --image \${{ env.AZURE_CONTAINER_APP_NAME }}:\${{ github.sha }} .

      - name: Deploy to Container App
        run: |
          az containerapp update \\
            --name \${{ env.AZURE_CONTAINER_APP_NAME }} \\
            --resource-group \${{ env.AZURE_RESOURCE_GROUP }} \\
            --image \${{ secrets.ACR_NAME }}.azurecr.io/\${{ env.AZURE_CONTAINER_APP_NAME }}:\${{ github.sha }}`},aws:{lambda:e=>`name: Deploy Go to AWS Lambda

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Set up Go
        uses: actions/setup-go@v5
        with:
          go-version: '1.21'

      - name: Build
        run: |
          GOOS=linux GOARCH=amd64 go build -o bootstrap main.go
          zip deployment.zip bootstrap
      ${e.tests?`
      - name: Run tests
        run: go test ./...`:""}

      - name: Deploy to Lambda
        run: |
          aws lambda update-function-code \\
            --function-name your-function-name \\
            --zip-file fileb://deployment.zip
        env:
          AWS_ACCESS_KEY_ID: \${{ secrets.AWS_ACCESS_KEY_ID }}
          AWS_SECRET_ACCESS_KEY: \${{ secrets.AWS_SECRET_ACCESS_KEY }}
          AWS_DEFAULT_REGION: us-east-1`,ec2:e=>`name: Deploy Go to AWS EC2

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Set up Go
        uses: actions/setup-go@v5
        with:
          go-version: '1.21'

      - name: Build
        run: |
          go mod download
          GOOS=linux GOARCH=amd64 go build -o app
      ${e.tests?`
      - name: Test
        run: go test ./...`:""}

      - name: Deploy to EC2
        run: |
          echo "\${{ secrets.EC2_SSH_KEY }}" > private_key.pem
          chmod 600 private_key.pem
          scp -i private_key.pem -o StrictHostKeyChecking=no app \${{ secrets.EC2_USER }}@\${{ secrets.EC2_HOST }}:/home/\${{ secrets.EC2_USER }}/
          ssh -i private_key.pem -o StrictHostKeyChecking=no \${{ secrets.EC2_USER }}@\${{ secrets.EC2_HOST }} 'sudo systemctl restart your-app'`},heroku:{webapp:e=>`name: Deploy Go to Heroku

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4
      ${e.tests?`
      - name: Set up Go
        uses: actions/setup-go@v5
        with:
          go-version: '1.21'

      - name: Run tests
        run: go test ./...`:""}

      - name: Deploy to Heroku
        uses: akhileshns/heroku-deploy@v3.13.15
        with:
          heroku_api_key: \${{ secrets.HEROKU_API_KEY }}
          heroku_app_name: your-go-app
          heroku_email: your-email@example.com`}},qd={azure:{acr:e=>`name: Build and Push to Azure Container Registry

on:
  push:
    branches: [main]
  workflow_dispatch:

env:
  REGISTRY_NAME: 'your-registry'
  IMAGE_NAME: 'your-image'

jobs:
  build-and-push:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Login to Azure
        uses: azure/login@v2
        with:
          client-id: \${{ secrets.AZURE_CLIENT_ID }}
          tenant-id: \${{ secrets.AZURE_TENANT_ID }}
          subscription-id: \${{ secrets.AZURE_SUBSCRIPTION_ID }}

      - name: Login to ACR
        run: az acr login --name \${{ env.REGISTRY_NAME }}
      ${e.tests?`
      - name: Run tests
        run: docker build --target test -t test-image .`:""}

      - name: Build and push image
        run: |
          docker build -t \${{ env.REGISTRY_NAME }}.azurecr.io/\${{ env.IMAGE_NAME }}:\${{ github.sha }} .
          docker push \${{ env.REGISTRY_NAME }}.azurecr.io/\${{ env.IMAGE_NAME }}:\${{ github.sha }}
          docker tag \${{ env.REGISTRY_NAME }}.azurecr.io/\${{ env.IMAGE_NAME }}:\${{ github.sha }} \\
            \${{ env.REGISTRY_NAME }}.azurecr.io/\${{ env.IMAGE_NAME }}:latest
          docker push \${{ env.REGISTRY_NAME }}.azurecr.io/\${{ env.IMAGE_NAME }}:latest

      - name: Azure Logout
        if: always()
        run: az logout`,containerapp:e=>`name: Deploy to Azure Container Apps

on:
  push:
    branches: [main]

env:
  CONTAINER_APP_NAME: 'your-app'
  RESOURCE_GROUP: 'your-rg'
  REGISTRY_NAME: 'your-registry'
  IMAGE_NAME: 'your-image'

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Login to Azure
        uses: azure/login@v2
        with:
          client-id: \${{ secrets.AZURE_CLIENT_ID }}
          tenant-id: \${{ secrets.AZURE_TENANT_ID }}
          subscription-id: \${{ secrets.AZURE_SUBSCRIPTION_ID }}

      - name: Build and push to ACR
        run: |
          az acr build --registry \${{ env.REGISTRY_NAME }} \\
            --image \${{ env.IMAGE_NAME }}:\${{ github.sha }} .

      - name: Deploy to Container App
        run: |
          az containerapp update \\
            --name \${{ env.CONTAINER_APP_NAME }} \\
            --resource-group \${{ env.RESOURCE_GROUP }} \\
            --image \${{ env.REGISTRY_NAME }}.azurecr.io/\${{ env.IMAGE_NAME }}:\${{ github.sha }}`},aws:{ecr:e=>`name: Build and Push to AWS ECR

on:
  push:
    branches: [main]

env:
  AWS_REGION: us-east-1
  ECR_REPOSITORY: your-repo
  IMAGE_TAG: \${{ github.sha }}

jobs:
  build-and-push:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          aws-access-key-id: \${{ secrets.AWS_ACCESS_KEY_ID }}
          aws-secret-access-key: \${{ secrets.AWS_SECRET_ACCESS_KEY }}
          aws-region: \${{ env.AWS_REGION }}

      - name: Login to Amazon ECR
        id: login-ecr
        uses: aws-actions/amazon-ecr-login@v2
      ${e.tests?`
      - name: Run tests
        run: docker build --target test -t test-image .`:""}

      - name: Build, tag, and push image to Amazon ECR
        env:
          ECR_REGISTRY: \${{ steps.login-ecr.outputs.registry }}
        run: |
          docker build -t $ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG .
          docker push $ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG
          docker tag $ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG $ECR_REGISTRY/$ECR_REPOSITORY:latest
          docker push $ECR_REGISTRY/$ECR_REPOSITORY:latest`,ecs:e=>`name: Deploy to AWS ECS

on:
  push:
    branches: [main]

env:
  AWS_REGION: us-east-1
  ECR_REPOSITORY: your-repo
  ECS_SERVICE: your-service
  ECS_CLUSTER: your-cluster
  CONTAINER_NAME: your-container

jobs:
  deploy:
    runs-on: ubuntu-latest

    steps:
      - uses: actions/checkout@v4

      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          aws-access-key-id: \${{ secrets.AWS_ACCESS_KEY_ID }}
          aws-secret-access-key: \${{ secrets.AWS_SECRET_ACCESS_KEY }}
          aws-region: \${{ env.AWS_REGION }}

      - name: Login to Amazon ECR
        id: login-ecr
        uses: aws-actions/amazon-ecr-login@v2

      - name: Build and push image
        id: build-image
        env:
          ECR_REGISTRY: \${{ steps.login-ecr.outputs.registry }}
          IMAGE_TAG: \${{ github.sha }}
        run: |
          docker build -t $ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG .
          docker push $ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG
          echo "image=$ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG" >> $GITHUB_OUTPUT

      - name: Deploy to ECS
        run: |
          aws ecs update-service \\
            --cluster \${{ env.ECS_CLUSTER }} \\
            --service \${{ env.ECS_SERVICE }} \\
            --force-new-deployment`},dockerhub:{build:e=>`name: Build and Push to Docker Hub

on:
  push:
    branches: [main]

env:
  IMAGE_NAME: your-username/your-image

jobs:
  build-and-push:
    runs-on: ubuntu-latest

    steps:
      - name: Checkout code
        uses: actions/checkout@v4

      - name: Set up Docker Buildx
        uses: docker/setup-buildx-action@v3

      - name: Login to Docker Hub
        uses: docker/login-action@v3
        with:
          username: \${{ secrets.DOCKERHUB_USERNAME }}
          password: \${{ secrets.DOCKERHUB_TOKEN }}
      ${e.tests?`
      - name: Run tests
        run: docker build --target test -t test-image .`:""}

      - name: Build and push
        uses: docker/build-push-action@v5
        with:
          context: .
          push: true
          tags: |
            \${{ env.IMAGE_NAME }}:\${{ github.sha }}
            \${{ env.IMAGE_NAME }}:latest${e.cache?`
          cache-from: type=gha
          cache-to: type=gha,mode=max`:""}`}},bd={python:Qd,nodejs:Zd,java:Xd,go:Jd,docker:qd},ef=({configs:e,onLoad:t,onDelete:n})=>{const r=o=>new Date(o).toLocaleString("en-US",{month:"short",day:"numeric",year:"numeric",hour:"2-digit",minute:"2-digit"}),l=o=>`${o.language} - ${o.framework} - ${o.platform}`;return e.length===0?y.jsxs("div",{className:"bg-white rounded-xl shadow-xl p-8 text-center",children:[y.jsx("div",{className:"text-gray-400 mb-2",children:y.jsx("svg",{className:"w-16 h-16 mx-auto",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24",children:y.jsx("path",{strokeLinecap:"round",strokeLinejoin:"round",strokeWidth:2,d:"M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"})})}),y.jsx("h3",{className:"text-lg font-semibold text-gray-700 mb-2",children:"No Saved Configurations"}),y.jsx("p",{className:"text-gray-500",children:"Your saved workflow configurations will appear here"})]}):y.jsxs("div",{className:"bg-white rounded-xl shadow-xl p-6",children:[y.jsxs("div",{className:"flex items-center justify-between mb-6",children:[y.jsx("h2",{className:"text-2xl font-bold text-gray-800",children:"Configuration History"}),y.jsxs("span",{className:"text-sm text-gray-500",children:[e.length," saved configuration",e.length!==1?"s":""]})]}),y.jsx("div",{className:"space-y-4",children:e.map(o=>{var i,u,s;return y.jsx("div",{className:"border border-gray-200 rounded-lg p-4 hover:border-primary hover:shadow-md transition-all duration-200",children:y.jsxs("div",{className:"flex items-start justify-between",children:[y.jsxs("div",{className:"flex-1",children:[y.jsx("h3",{className:"font-semibold text-gray-800 mb-1",children:l(o)}),y.jsxs("p",{className:"text-sm text-gray-500 mb-3",children:["Saved on ",r(o.timestamp)]}),y.jsxs("div",{className:"flex flex-wrap gap-2",children:[y.jsx("span",{className:"inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-purple-100 text-purple-800",children:o.language}),y.jsx("span",{className:"inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800",children:o.framework}),y.jsx("span",{className:"inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800",children:o.platform}),((i=o.options)==null?void 0:i.cache)&&y.jsx("span",{className:"inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800",children:"Cache"}),((u=o.options)==null?void 0:u.tests)&&y.jsx("span",{className:"inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800",children:"Tests"}),((s=o.options)==null?void 0:s.optimize)&&y.jsx("span",{className:"inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800",children:"Optimize"})]})]}),y.jsxs("div",{className:"flex flex-col space-y-2 ml-4",children:[y.jsx("button",{onClick:()=>t(o.id),className:"px-4 py-2 bg-gradient-to-r from-primary to-secondary text-white text-sm rounded-lg hover:shadow-lg transition-all duration-200 whitespace-nowrap",children:"Load"}),y.jsx("button",{onClick:()=>{window.confirm("Are you sure you want to delete this configuration?")&&n(o.id)},className:"px-4 py-2 bg-red-500 hover:bg-red-600 text-white text-sm rounded-lg transition-colors duration-200 whitespace-nowrap",children:"Delete"})]})]})},o.id)})})]})},_i="workflow_configs",tf=10,nf=e=>{try{const t=Jt(),n={...e,id:Date.now(),timestamp:new Date().toISOString()};t.unshift(n);const r=t.slice(0,tf);return localStorage.setItem(_i,JSON.stringify(r)),n}catch(t){return console.error("Error saving configuration:",t),null}},Jt=()=>{try{const e=localStorage.getItem(_i);return e?JSON.parse(e):[]}catch(e){return console.error("Error loading configurations:",e),[]}},rf=e=>{try{const n=Jt().filter(r=>r.id!==e);return localStorage.setItem(_i,JSON.stringify(n)),!0}catch(t){return console.error("Error deleting configuration:",t),!1}},lf=e=>{try{return Jt().find(n=>n.id===e)||null}catch(t){return console.error("Error loading configuration:",t),null}},of=e=>{try{const t=JSON.stringify(e);return btoa(encodeURIComponent(t))}catch(t){return console.error("Error encoding configuration:",t),null}},uf=e=>{try{const t=decodeURIComponent(atob(e));return JSON.parse(t)}catch(t){return console.error("Error decoding configuration:",t),null}},sf=e=>{const t=of(e);return t?`${window.location.origin+window.location.pathname}?config=${t}`:null},Pu=async e=>{try{if(navigator.clipboard&&navigator.clipboard.writeText)return await navigator.clipboard.writeText(e),!0;{const t=document.createElement("textarea");t.value=e,t.style.position="fixed",t.style.left="-999999px",document.body.appendChild(t),t.focus(),t.select();try{return document.execCommand("copy"),t.remove(),!0}catch(n){return console.error("Fallback: Oops, unable to copy",n),t.remove(),!1}}}catch(t){return console.error("Error copying to clipboard:",t),!1}},af=()=>{try{const t=new URLSearchParams(window.location.search).get("config");return t?uf(t):null}catch(e){return console.error("Error loading configuration from URL:",e),null}},cf=(e,t="workflow.yml")=>{try{const n=new Blob([e],{type:"text/yaml;charset=utf-8"}),r=URL.createObjectURL(n),l=document.createElement("a");return l.href=r,l.download=t,document.body.appendChild(l),l.click(),document.body.removeChild(l),URL.revokeObjectURL(r),!0}catch(n){return console.error("Error downloading workflow:",n),!1}};function df(){var P;const[e,t]=ie.useState("python"),[n,r]=ie.useState("flask"),[l,o]=ie.useState("azure"),[i,u]=ie.useState({cache:!0,tests:!0,optimize:!0}),[s,f]=ie.useState(""),[h,m]=ie.useState(!1),[p,w]=ie.useState([]),[E,S]=ie.useState({show:!1,message:"",type:"success"}),D={python:["flask","django","fastapi"],nodejs:["express","nextjs","react"],java:["springboot","maven","gradle"],go:e==="go"&&l==="aws"?["lambda","ec2"]:["webapp","containerapp"],docker:l==="dockerhub"?["build"]:["acr","ecr","ecs","containerapp"]};ie.useEffect(()=>{const k=D[e];k&&!k.includes(n)&&r(k[0])},[e,l]),ie.useEffect(()=>{w(Jt())},[]),ie.useEffect(()=>{const k=af();k&&(_(k),c("Configuration loaded from URL","success"),window.history.replaceState({},document.title,window.location.pathname))},[]);const c=(k,V="success")=>{S({show:!0,message:k,type:V}),setTimeout(()=>S({show:!1,message:"",type:"success"}),3e3)},a=ie.useCallback(()=>{var k,V;try{const Ae=(V=(k=bd[e])==null?void 0:k[l])==null?void 0:V[n];if(!Ae){c("Template not available for this configuration","error");return}const Xn=Ae(i);f(Xn),c("Workflow generated successfully!","success")}catch(Ae){console.error("Error generating workflow:",Ae),c("Error generating workflow","error")}},[e,l,n,i]);ie.useEffect(()=>{a()},[a]);const d=()=>{nf({language:e,framework:n,platform:l,options:i,workflow:s})?(w(Jt()),c("Configuration saved!","success")):c("Error saving configuration","error")},v=k=>{rf(k)?(w(Jt()),c("Configuration deleted","success")):c("Error deleting configuration","error")},_=k=>{t(k.language),r(k.framework),o(k.platform),u(k.options),k.workflow&&f(k.workflow)},N=k=>{const V=lf(k);V?(_(V),m(!1),c("Configuration loaded!","success")):c("Error loading configuration","error")},A=async()=>{const V=sf({language:e,framework:n,platform:l,options:i});V?await Pu(V)?c("Shareable link copied to clipboard!","success"):c("Error copying link to clipboard","error"):c("Error generating shareable link","error")},R=()=>{cf(s,`${e}-${n}-${l}.yml`)?c("Workflow downloaded!","success"):c("Error downloading workflow","error")},U=async()=>{await Pu(s)?c("Workflow copied to clipboard!","success"):c("Error copying workflow","error")};return y.jsxs("div",{className:"min-h-screen bg-gradient-to-br from-primary via-purple-600 to-secondary",children:[E.show&&y.jsx("div",{className:`fixed top-4 right-4 z-50 px-6 py-3 rounded-lg shadow-lg animate-slideUp ${E.type==="success"?"bg-green-500":"bg-red-500"} text-white font-medium`,children:E.message}),y.jsx("header",{className:"bg-white bg-opacity-10 backdrop-blur-md shadow-lg",children:y.jsx("div",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6",children:y.jsxs("div",{className:"flex items-center justify-between",children:[y.jsxs("div",{children:[y.jsx("h1",{className:"text-3xl font-bold text-white",children:"CI/CD Workflow Generator"}),y.jsx("p",{className:"text-gray-100 mt-1",children:"Generate GitHub Actions workflows in seconds"})]}),y.jsxs("button",{onClick:()=>m(!h),className:"px-4 py-2 bg-white bg-opacity-20 hover:bg-opacity-30 text-white rounded-lg transition-all duration-200 backdrop-blur-sm border border-white border-opacity-20",children:[h?"Hide":"Show"," History (",p.length,")"]})]})})}),y.jsxs("main",{className:"max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8",children:[y.jsxs("div",{className:"grid grid-cols-1 lg:grid-cols-3 gap-6",children:[y.jsxs("div",{className:"lg:col-span-1 space-y-6",children:[y.jsxs("div",{className:"bg-white rounded-xl shadow-xl p-6 animate-fadeIn",children:[y.jsx("h2",{className:"text-xl font-semibold text-gray-800 mb-4",children:"Language"}),y.jsx("div",{className:"grid grid-cols-2 gap-3",children:["python","nodejs","java","go","docker"].map(k=>y.jsx("button",{onClick:()=>t(k),className:`p-3 rounded-lg font-medium transition-all duration-200 ${e===k?"bg-gradient-to-r from-primary to-secondary text-white shadow-lg transform scale-105":"bg-gray-100 text-gray-700 hover:bg-gray-200"}`,children:k.charAt(0).toUpperCase()+k.slice(1)},k))})]}),y.jsxs("div",{className:"bg-white rounded-xl shadow-xl p-6 animate-fadeIn",children:[y.jsx("h2",{className:"text-xl font-semibold text-gray-800 mb-4",children:"Platform"}),y.jsx("div",{className:"grid grid-cols-1 gap-3",children:e==="docker"?["azure","aws","dockerhub"].map(k=>y.jsx("button",{onClick:()=>o(k),className:`p-3 rounded-lg font-medium transition-all duration-200 ${l===k?"bg-gradient-to-r from-primary to-secondary text-white shadow-lg":"bg-gray-100 text-gray-700 hover:bg-gray-200"}`,children:k==="dockerhub"?"Docker Hub":k.toUpperCase()},k)):["azure","aws","heroku"].map(k=>y.jsx("button",{onClick:()=>o(k),className:`p-3 rounded-lg font-medium transition-all duration-200 ${l===k?"bg-gradient-to-r from-primary to-secondary text-white shadow-lg":"bg-gray-100 text-gray-700 hover:bg-gray-200"}`,children:k==="aws"?"AWS":k.charAt(0).toUpperCase()+k.slice(1)},k))})]}),y.jsxs("div",{className:"bg-white rounded-xl shadow-xl p-6 animate-fadeIn",children:[y.jsx("h2",{className:"text-xl font-semibold text-gray-800 mb-4",children:"Framework"}),y.jsx("div",{className:"grid grid-cols-1 gap-3",children:(P=D[e])==null?void 0:P.map(k=>y.jsx("button",{onClick:()=>r(k),className:`p-3 rounded-lg font-medium transition-all duration-200 ${n===k?"bg-gradient-to-r from-primary to-secondary text-white shadow-lg":"bg-gray-100 text-gray-700 hover:bg-gray-200"}`,children:k.charAt(0).toUpperCase()+k.slice(1)},k))})]}),y.jsxs("div",{className:"bg-white rounded-xl shadow-xl p-6 animate-fadeIn",children:[y.jsx("h2",{className:"text-xl font-semibold text-gray-800 mb-4",children:"Options"}),y.jsx("div",{className:"space-y-3",children:[{key:"cache",label:"Enable Caching",description:"Cache dependencies for faster builds"},{key:"tests",label:"Run Tests",description:"Include test execution step"},{key:"optimize",label:"Optimize",description:"Add optimization steps"}].map(k=>y.jsxs("label",{className:"flex items-start space-x-3 cursor-pointer group",children:[y.jsx("input",{type:"checkbox",checked:i[k.key],onChange:V=>u({...i,[k.key]:V.target.checked}),className:"mt-1 h-5 w-5 text-primary rounded focus:ring-primary cursor-pointer"}),y.jsxs("div",{className:"flex-1",children:[y.jsx("div",{className:"font-medium text-gray-800 group-hover:text-primary transition-colors",children:k.label}),y.jsx("div",{className:"text-sm text-gray-500",children:k.description})]})]},k.key))})]}),y.jsxs("div",{className:"bg-white rounded-xl shadow-xl p-6 animate-fadeIn space-y-3",children:[y.jsx("button",{onClick:d,className:"w-full px-4 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg font-medium hover:from-green-600 hover:to-green-700 transition-all duration-200 shadow-lg hover:shadow-xl",children:"Save Configuration"}),y.jsx("button",{onClick:A,className:"w-full px-4 py-3 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-lg font-medium hover:from-blue-600 hover:to-blue-700 transition-all duration-200 shadow-lg hover:shadow-xl",children:"Share Configuration"})]})]}),y.jsxs("div",{className:"lg:col-span-2 space-y-6",children:[y.jsxs("div",{className:"bg-white rounded-xl shadow-xl overflow-hidden animate-fadeIn",children:[y.jsxs("div",{className:"bg-gray-800 px-6 py-4 flex items-center justify-between",children:[y.jsx("h2",{className:"text-lg font-semibold text-white",children:"Generated Workflow"}),y.jsxs("div",{className:"flex space-x-2",children:[y.jsx("button",{onClick:U,className:"px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-sm rounded-lg transition-colors duration-200",children:"Copy"}),y.jsx("button",{onClick:R,className:"px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm rounded-lg transition-colors duration-200",children:"Download"})]})]}),y.jsx($a,{height:"600px",defaultLanguage:"yaml",value:s,onChange:k=>f(k||""),theme:"vs-dark",options:{minimap:{enabled:!1},fontSize:14,lineNumbers:"on",roundedSelection:!1,scrollBeyondLastLine:!1,readOnly:!1,automaticLayout:!0}})]}),y.jsxs("div",{className:"bg-white rounded-xl shadow-xl p-6 animate-fadeIn",children:[y.jsx("h2",{className:"text-xl font-semibold text-gray-800 mb-4",children:"How to Use"}),y.jsxs("ol",{className:"list-decimal list-inside space-y-2 text-gray-700",children:[y.jsx("li",{children:"Select your programming language, deployment platform, and framework"}),y.jsx("li",{children:"Configure options like caching, tests, and optimization"}),y.jsx("li",{children:"The workflow will be generated automatically"}),y.jsx("li",{children:"Copy or download the workflow file"}),y.jsxs("li",{children:["Create ",y.jsx("code",{className:"bg-gray-100 px-2 py-1 rounded",children:".github/workflows/"})," directory in your repository"]}),y.jsxs("li",{children:["Save the workflow as ",y.jsx("code",{className:"bg-gray-100 px-2 py-1 rounded",children:"deploy.yml"})," in that directory"]}),y.jsx("li",{children:"Configure required secrets in your GitHub repository settings"}),y.jsx("li",{children:"Push to your repository and watch the magic happen!"})]})]})]})]}),h&&y.jsx("div",{className:"mt-6 animate-slideUp",children:y.jsx(ef,{configs:p,onLoad:N,onDelete:v})})]}),y.jsxs("footer",{className:"mt-12 py-6 text-center text-white text-sm bg-white bg-opacity-10 backdrop-blur-md",children:[y.jsx("p",{children:"Built with React, Vite, and Tailwind CSS"}),y.jsx("p",{className:"mt-2",children:"Open source CI/CD workflow generator for GitHub Actions"})]})]})}Ul.createRoot(document.getElementById("root")).render(y.jsx(Oa.StrictMode,{children:y.jsx(df,{})}));
